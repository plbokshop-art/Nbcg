import test from 'node:test';
import assert from 'node:assert/strict';
import {makeCasing,makeImpact,stepEffects,pushLimited,MAX_CASINGS,MAX_PARTICLES} from '../client/effects.mjs';
import {WEAPON_AUDIO,createAudioSystem} from '../client/audio.mjs';
test('weapon audio profiles cover all weapons',()=>assert.deepEqual(Object.keys(WEAPON_AUDIO).sort(),['pistol','rifle','shotgun','smg']));
test('casing has deterministic physical state shape',()=>{const c=makeCasing({x:1,y:2,z:3,vx:1,vy:2,vz:3});assert.equal(c.x,1);assert.equal(c.life,1.2);assert.ok(c.size>0)});
test('particles advance and expire',()=>{const p=makeImpact({x:0,y:0,z:0,count:2,life:.1});stepEffects(p,.2);assert.equal(p.length,0)});
test('limited buffers enforce effect caps',()=>{const a=[];for(let i=0;i<MAX_CASINGS+5;i++)pushLimited(a,i,MAX_CASINGS);assert.equal(a.length,MAX_CASINGS);const b=[];for(let i=0;i<MAX_PARTICLES+5;i++)pushLimited(b,i,MAX_PARTICLES);assert.equal(b.length,MAX_PARTICLES)});
test('audio system is safe in non-browser environment',()=>{const a=createAudioSystem({});assert.equal(a.ensure(),false);a.shot('rifle');a.reloadStart();a.reloadFinish();});
