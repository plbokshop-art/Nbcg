import test from 'node:test'; import assert from 'node:assert/strict';
import {makePlayer,applyMovement,tryFire,WEAPONS,buyWeapon,buyGrenade,detonateGrenade,equipWeapon as equipWeaponForTest,segmentSmokeBlocked} from '../shared/game.mjs';
import {walletTransactions,walletCredit} from '../shared/economy.mjs';
test('player moves forward',()=>{const p=makePlayer('1',0,-4);const before=p.z;applyMovement(p,{forward:true,yaw:0,pitch:0},1/60);assert.ok(p.z<before)});
test('player cannot leave world bounds',()=>{const p=makePlayer('1',23.0,0);for(let i=0;i<100;i++)applyMovement(p,{forward:false,right:true,yaw:0,pitch:0},1/60);assert.ok(p.x<=23.65)});
test('weapon damages target in front',()=>{const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');a.yaw=0;a.pitch=-0.13;const map=new Map([[a.id,a],[b.id,b]]);const e=tryFire(a,map,0);assert.equal(e.target,'b');assert.equal(b.hp,100-WEAPONS.pistol.damage)});
test('weapon respects fire rate',()=>{const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');a.yaw=0;a.pitch=-0.13;const map=new Map([[a.id,a],[b.id,b]]);tryFire(a,map,0);assert.equal(tryFire(a,map,.01),null)});
test('buy rifle spends money and equips it',()=>{const p=makePlayer('1',0,0);p.money=3000;assert.equal(buyWeapon(p,'rifle'),true);assert.equal(p.weapon,'rifle');assert.equal(p.money,300);assert.equal(p.ammo,30)});
test('owned weapons can switch without free reloads',()=>{const p=makePlayer('switch',0,0);p.money=5000;assert.equal(buyWeapon(p,'rifle','tx-rifle'),true);p.ammo=7;p.reserve=21;p.weaponState.rifle={ammo:7,reserve:21};assert.equal(equipWeaponForTest(p,'pistol'),true);assert.equal(equipWeaponForTest(p,'rifle'),true);assert.equal(p.ammo,7);assert.equal(p.reserve,21);});
test('cannot buy duplicate weapon',()=>{const p=makePlayer('1',0,0);p.money=10000;assert.equal(buyWeapon(p,'rifle'),true);assert.equal(buyWeapon(p,'rifle'),false);assert.equal(p.money,7300)});
test('grenade purchase is limited by money and capacity',()=>{const p=makePlayer('1',0,0);p.money=1000;assert.equal(buyGrenade(p,'frag'),true);assert.equal(buyGrenade(p,'flash'),true);assert.equal(buyGrenade(p,'frag'),true);assert.equal(p.money,200);assert.equal(buyGrenade(p,'frag'),false)});
test('frag grenade damages enemy but not teammate',()=>{const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',2,-4,'red'),c=makePlayer('c',2,-4,'blue');const map=new Map([[a.id,a],[b.id,b],[c.id,c]]);const events=detonateGrenade(a,'frag',map,{x:0,y:1,z:-4});assert.ok(b.hp<100);assert.equal(c.hp,100);assert.ok(events.length>0)});
import {pointBlocked,segmentBlocked,MAP_WALLS,MAP,zoneAt,spawnPoints,isSpawnSafe} from '../shared/map.mjs';
test('map has protected cover and boundaries',()=>{assert.ok(MAP_WALLS.length>=10);assert.ok(pointBlocked(0,0));assert.equal(pointBlocked(20,10),null)});
test('player cannot walk through central wall',()=>{const p=makePlayer('wall',-3,0,'blue');for(let i=0;i<120;i++)applyMovement(p,{right:true,yaw:0,pitch:0},1/60);assert.ok(p.x< -2.5)});
test('line of sight is blocked by central cover',()=>{assert.equal(segmentBlocked(-8,0,8,0),true);assert.equal(segmentBlocked(-8,-10,8,-10),false)});
test('shot is stopped by map cover',()=>{const a=makePlayer('a',-8,0,'blue'),b=makePlayer('b',8,0,'red');a.yaw=-Math.PI/2;const map=new Map([[a.id,a],[b.id,b]]);const e=tryFire(a,map,0);assert.equal(e.target,undefined);assert.equal(b.hp,100)});


test('all team spawns are valid and outside collision geometry',()=>{
  for(const team of ['blue','red']) for(const s of spawnPoints(team)) assert.equal(isSpawnSafe(s.x,s.z),true);
});
test('objective zones are addressable by world position',()=>{
  assert.equal(zoneAt(-12,-8)?.id,'site_a');
  assert.equal(zoneAt(12,8)?.id,'site_b');
  assert.equal(zoneAt(0,0)?.id,'mid');
  assert.equal(zoneAt(0,15),null);
});
test('map has tactical doors and protected lanes',()=>{
  assert.equal(MAP.doors.length,2);
  assert.equal(MAP.doors.every(d=>d.open===false),true);
  assert.equal(pointBlocked(-7,-1),MAP.doors[0]);
});
test('closed door blocks line of sight',()=>{
  assert.equal(segmentBlocked(-12,-1,-2,-1),true);
});

test('movement exposes animation state and speed for remote interpolation',()=>{
  const p=makePlayer('anim',0,-4,'blue');
  applyMovement(p,{forward:true,yaw:0,pitch:0},1/60);
  assert.equal(p.anim,'walk');
  assert.ok(p.speed>0);
  applyMovement(p,{forward:true,sprint:true,yaw:0,pitch:0},1/60);
  assert.equal(p.anim,'run');
  applyMovement(p,{crouch:true,yaw:0,pitch:0},1/60);
  assert.ok(['crouch','crouch_walk'].includes(p.anim));
});

test('head hitbox produces a real headshot multiplier',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');
  a.yaw=0;
  a.pitch=0;
  const map=new Map([[a.id,a],[b.id,b]]);
  const e=tryFire(a,map,0);
  assert.equal(e.target,'b');
  assert.equal(e.part,'head');
  assert.equal(e.headshot,true);
  assert.equal(b.hp,100-WEAPONS.pistol.damage*2);
});

import {MATERIALS,getMaterial} from '../shared/materials.mjs';
test('material library defines physically meaningful surface parameters',()=>{ for(const [id,m] of Object.entries(MATERIALS)){ assert.equal(m.baseColor.length,4); assert.ok(m.roughness>=0&&m.roughness<=1); assert.ok(m.metallic>=0&&m.metallic<=1); assert.ok(Array.isArray(m.emissive)); } assert.equal(getMaterial('missing'),MATERIALS.concrete); });

test('rewound shot resolves against historical target position',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');
  a.yaw=0;a.pitch=-0.13;
  const map=new Map([[a.id,a],[b.id,b]]);
  const historical=new Map([
    [a.id,{id:'a',team:'blue',x:0,y:0,z:-4,yaw:0,pitch:-0.13,crouched:false,alive:true}],
    [b.id,{id:'b',team:'red',x:0,y:0,z:-9,yaw:0,pitch:0,crouched:false,alive:true}]
  ]);
  b.x=8;
  const e=tryFire(a,map,1,{rewoundPlayers:historical});
  assert.equal(e.target,'b');
  assert.equal(b.hp,100-WEAPONS.pistol.damage);
});

test('rewound shot does not trust historical dead target state',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');
  a.yaw=0;a.pitch=-0.13;
  b.alive=false;
  const map=new Map([[a.id,a],[b.id,b]]);
  const historical=new Map([[a.id,{id:'a',team:'blue',x:0,y:0,z:-4,yaw:0,pitch:-0.13,crouched:false,alive:true}],[b.id,{id:'b',team:'red',x:0,y:0,z:-9,yaw:0,pitch:0,crouched:false,alive:true}]]);
  const e=tryFire(a,map,1,{rewoundPlayers:historical});
  assert.equal(e.type,'shot');
});

test('grenade explosion uses distance falloff and line of sight',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',2,-4,'red');
  const map=new Map([[a.id,a],[b.id,b]]);
  const near=detonateGrenade(a,'frag',map,{x:0,y:1,z:-4});
  assert.ok(near.some(e=>e.type==='grenadeDamage'));
  assert.ok(b.hp<100);
  b.hp=100;b.alive=true;
  b.x=8;b.z=0;
  const blocked=detonateGrenade(a,'frag',map,{x:0,y:1,z:0});
  assert.equal(blocked.length,0);
});




test('flash grenade affects visible players based on distance and facing',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-6,'red'),c=makePlayer('c',0,-6,'red');
  b.yaw=Math.PI; c.yaw=0;
  const map=new Map([[a.id,a],[b.id,b],[c.id,c]]);
  const events=detonateGrenade(a,'flash',map,{x:0,y:1,z:-4});
  const eb=events.find(e=>e.target==='b'),ec=events.find(e=>e.target==='c');
  assert.ok(eb); assert.ok(ec); assert.ok(eb.intensity>ec.intensity);
  assert.ok(eb.duration>ec.duration);
});

test('flash grenade is blocked by cover',()=>{
  const a=makePlayer('a',-8,0,'blue'),b=makePlayer('b',8,0,'red');
  const map=new Map([[a.id,a],[b.id,b]]);
  const events=detonateGrenade(a,'flash',map,{x:-8,y:1,z:0});
  assert.equal(events.some(e=>e.target==='b'),false);
});

test('wallet ledger records idempotent authoritative purchases',()=>{const p=makePlayer('wallet',0,0);p.money=3000;p.wallet.balance=3000;assert.equal(buyWeapon(p,'rifle','tx-rifle-1'),true);assert.equal(p.money,300);assert.equal(buyWeapon(p,'smg','tx-smg-1'),false);const tx=walletTransactions(p);assert.equal(tx.length,1);assert.equal(tx[0].id,'tx-rifle-1');assert.equal(tx[0].type,'DEBIT');});
test('wallet rejects overspending and caps ledger growth',()=>{const p=makePlayer('wallet2',0,0);assert.equal(buyWeapon(p,'rifle','too-poor'),false);for(let i=0;i<140;i++)walletCredit(p,1,{id:`credit-${i}`,reason:'TEST'});assert.equal(walletTransactions(p).length,128);assert.equal(p.money,940);});
import {ensureInventory,grantWeapon,addGrenade,consumeGrenade,grenadeCount,inventorySnapshot} from '../shared/inventory.mjs';
test('inventory normalizes ownership and preserves starter weapon',()=>{const p=makePlayer('inv',0,0);p.inventory={weapons:['rifle','rifle','bad id'],grenades:['frag']};const inv=ensureInventory(p);assert.deepEqual(inv.weapons,['pistol','rifle']);assert.equal(grenadeCount(p,'frag'),1)});
test('inventory weapon grants are unique and grenade consumption is exact',()=>{const p=makePlayer('inv2',0,0);assert.equal(grantWeapon(p,'smg'),true);assert.equal(grantWeapon(p,'smg'),false);assert.equal(addGrenade(p,'frag',2),true);assert.equal(grenadeCount(p,'frag'),2);assert.equal(consumeGrenade(p,'frag'),true);assert.equal(grenadeCount(p,'frag'),1);assert.equal(consumeGrenade(p,'flash'),false);assert.deepEqual(inventorySnapshot(p).weapons,['pistol','smg'])});

test('smoke blocks line of sight through its radius',()=>{const smoke=[{x:0,z:-6,radius:4.2}];assert.equal(segmentSmokeBlocked(0,-4,0,-9,smoke),true);assert.equal(segmentSmokeBlocked(10,-4,10,-9,smoke),false);});

test('smoke blocks an otherwise valid shot',()=>{const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');a.yaw=0;a.pitch=-0.13;const map=new Map([[a.id,a],[b.id,b]]);const smoke=[{x:0,z:-6,radius:4.2}];const e=tryFire(a,map,0,{smokeZones:smoke});assert.equal(e.type,'shot');assert.equal(b.hp,100);});

test('smoke blocks flash but not frag damage',()=>{const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-6,'red');b.yaw=Math.PI;const map=new Map([[a.id,a],[b.id,b]]);const smoke=[{x:0,z:-5,radius:4.2}];const flash=detonateGrenade(a,'flash',map,{x:0,y:1,z:-4},{smokeZones:smoke});assert.equal(flash.some(e=>e.target==='b'),false);b.hp=100;b.alive=true;const frag=detonateGrenade(a,'frag',map,{x:0,y:1,z:-5},{smokeZones:smoke});assert.ok(frag.some(e=>e.target==='b'));});
