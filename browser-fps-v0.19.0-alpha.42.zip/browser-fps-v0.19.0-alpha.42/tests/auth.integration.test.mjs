import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';

const root=path.resolve(new URL('..',import.meta.url).pathname);
const port=19900+Math.floor(Math.random()*300);
const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-auth-'));
let server;
function mask(payload){const p=Buffer.from(payload),k=crypto.randomBytes(4);for(let i=0;i<p.length;i++)p[i]^=k[i%4];return Buffer.concat([Buffer.from([0x81,0x80|p.length]),k,p]);}
function parseFrame(buffer){if(buffer.length<2)return null;let len=buffer[1]&127,offset=2;if(len===126){if(buffer.length<4)return null;len=buffer.readUInt16BE(2);offset=4;}if(buffer.length<offset+len)return null;return {msg:JSON.parse(buffer.subarray(offset,offset+len).toString()),next:offset+len};}
async function connect(){return new Promise((resolve,reject)=>{const key=crypto.randomBytes(16).toString('base64'),socket=net.connect(port,'127.0.0.1');let buf=Buffer.alloc(0),handshake=false,welcome=null,timer=setTimeout(()=>{socket.destroy();reject(new Error('welcome timeout'));},3000);socket.on('connect',()=>socket.write(`GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`));socket.on('data',chunk=>{buf=Buffer.concat([buf,chunk]);if(!handshake){const i=buf.indexOf('\r\n\r\n');if(i<0)return;handshake=true;buf=buf.subarray(i+4);}while(true){const f=parseFrame(buf);if(!f)break;buf=buf.subarray(f.next);if(f.msg.type==='welcome'){welcome=f.msg;clearTimeout(timer);resolve({socket,welcome});return;}}});socket.on('error',reject);});}
function nextMessage(socket){return new Promise((resolve,reject)=>{let buf=Buffer.alloc(0),timer=setTimeout(()=>reject(new Error('message timeout')),3000);const onData=chunk=>{buf=Buffer.concat([buf,chunk]);while(true){const f=parseFrame(buf);if(!f)break;buf=buf.subarray(f.next);if(f.msg.type==='ping'||f.msg.type==='join'||f.msg.type==='state')continue;if(f.msg.type!=='auth')continue;clearTimeout(timer);socket.off('data',onData);resolve(f.msg);return;}};socket.on('data',onData);});}

test.before(async()=>{server=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:String(port),VANGUARD_DATA_DIR:dataDir},stdio:'ignore'});const deadline=Date.now()+5000;while(Date.now()<deadline){try{if((await fetch(`http://127.0.0.1:${port}/ready`)).ok)return;}catch{}await new Promise(r=>setTimeout(r,50));}throw new Error('server start timeout');});
test.after(async()=>{if(server&&server.exitCode===null){await new Promise(resolve=>{server.once('exit',resolve);server.kill('SIGTERM');});}fs.rmSync(dataDir,{recursive:true,force:true});});

test('account auth survives reconnect and never requires account token in URL',async()=>{
  const first=await connect();
  assert.equal(first.welcome.authRequired,true);
  first.socket.write(mask(JSON.stringify({authAccountToken:null})));
  const created=await nextMessage(first.socket);
  assert.equal(created.type,'auth');assert.equal(created.ok,true);assert.equal(created.newAccount,true);
  const accountId=created.account.id,token=created.accountToken;
  first.socket.destroy();await new Promise(r=>setTimeout(r,150));
  const second=await connect();
  second.socket.write(mask(JSON.stringify({authAccountToken:token})));
  const restored=await nextMessage(second.socket);
  assert.equal(restored.type,'auth');assert.equal(restored.ok,true);assert.equal(restored.account.id,accountId);assert.equal(restored.accountToken,undefined);
  second.socket.destroy();
});
