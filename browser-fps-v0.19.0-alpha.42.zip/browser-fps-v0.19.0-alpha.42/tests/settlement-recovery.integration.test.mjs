import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {makeAccount} from '../shared/account.mjs';
import {hashToken} from '../shared/auth.mjs';
import {settlementKey,settlementRecord} from '../shared/settlement.mjs';
import {recoveryRecord} from '../shared/recovery.mjs';

function wait(ms){return new Promise(r=>setTimeout(r,ms));}
async function waitReady(port,child){
  const deadline=Date.now()+5000;
  while(Date.now()<deadline){
    if(child.exitCode!==null)throw new Error(`server exited ${child.exitCode}`);
    try{const r=await fetch(`http://127.0.0.1:${port}/ready`);if(r.ok)return;}catch{}
    await wait(50);
  }
  throw new Error('server readiness timeout');
}
function stop(child){return new Promise(resolve=>{if(child.exitCode!==null)return resolve();child.once('exit',resolve);child.kill('SIGTERM');setTimeout(()=>{if(child.exitCode===null)child.kill('SIGKILL');},3000).unref();});}

test('prepared settlement is completed automatically after crash recovery',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-settlement-recovery-'));
  const port=19000+Math.floor(Math.random()*1000);
  const matchId='match_recovery_settlement_1';
  const result={winner:'blue',score:{blue:13,red:7},round:20};
  const settlement=settlementKey(matchId,result);
  const accounts=[];
  const players=[];
  const slots=[];
  for(let i=0;i<10;i++){
    const id=`acct_${i}`;const a=makeAccount(id,`Player-${i}`);a.tokenHash=hashToken(`session-token-${i}-long-enough`);a.rating=1000;accounts.push(a);
    const team=i<5?'blue':'red';
    slots.push({playerId:String(i+1),accountId:id,team});
    players.push({id:String(i+1),accountId:id,team,x:i,y:0,z:i,yaw:0,pitch:0,vy:0,hp:100,alive:true,status:'ALIVE',crouched:false,money:800,inventory:{weapons:['pistol'],grenades:[]},wallet:{balance:800,version:0,ledger:[]},weapon:'pistol',ammo:12,reserve:36,reloading:false,reloadAt:0,nextShot:0,score:0,deaths:0,shotCount:0,fireSeq:0,moveX:0,moveZ:0,speed:0,matchId,round:20,abandoned:false,preDisconnectAlive:true,preDisconnectStatus:'ALIVE',sessionToken:`session-token-${i}-long-enough`});
  }
  const targetRatings=players.map((p,i)=>({accountId:p.accountId,ratingBefore:1000,ratingAfter:i<5?1016:984,ratingK:32,integrityScore:0,integrityReasons:[],opponents:slots.filter(s=>s.team!==p.team).map(s=>s.accountId)}));
  const journal=settlementRecord(settlement,{matchId,result,status:'PREPARED',participants:targetRatings});
  fs.writeFileSync(path.join(dir,'accounts.json'),JSON.stringify(accounts));
  fs.writeFileSync(path.join(dir,'settlements.json'),JSON.stringify([journal]));
  const activeMatch={id:matchId,status:'COMPLETED',targetScore:13,teamSize:5,players:slots,score:{blue:13,red:7},result,settlementId:settlement};
  const snapshot={version:1,savedAt:Date.now(),gameTime:10,phase:'POST',phaseEnds:20,round:20,score:{blue:13,red:7},activeMatch,players,grenades:[]};
  const rr=recoveryRecord(snapshot); fs.writeFileSync(path.join(dir,'active-match.json'),JSON.stringify([rr]));
  const child=spawn(process.execPath,['server/index.mjs'],{cwd:path.dirname(new URL(import.meta.url).pathname).replace(/\/tests$/,''),env:{...process.env,PORT:String(port),VANGUARD_DATA_DIR:dir,VANGUARD_BUY_SECONDS:'60'},stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',d=>stderr+=d.toString());
  try{
    await waitReady(port,child);await wait(250);
    const saved=JSON.parse(fs.readFileSync(path.join(dir,'accounts.json'),'utf8'));
    assert.equal(saved.every(a=>a.matchHistory.some(m=>m.settlementId===settlement)),true);
    assert.equal(saved.filter(a=>a.rating===1016).length,5);
    assert.equal(saved.filter(a=>a.rating===984).length,5);
    const settlements=JSON.parse(fs.readFileSync(path.join(dir,'settlements.json'),'utf8'));
    assert.equal(settlements.find(r=>r.id===settlement)?.status,'COMPLETED');
    assert.equal(fs.existsSync(path.join(dir,'active-match.json')),false);
  } finally {
    await stop(child);
    fs.rmSync(dir,{recursive:true,force:true});
    if(child.exitCode!==0)assert.fail(`server failed: ${stderr}`);
  }
});

test('orphan PREPARED settlement is reconciled exactly once after restart',async()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-settlement-orphan-'));
  const port=20000+Math.floor(Math.random()*1000);
  const matchId='match_orphan_settlement_1';
  const result={winner:'blue',score:{blue:13,red:9},round:18};
  const settlement=settlementKey(matchId,result);
  const accounts=[];
  const participants=[];
  for(let i=0;i<10;i++){
    const id=`acct_${i}`;const a=makeAccount(id,`Player-${i}`);a.tokenHash=hashToken(`session-token-${i}-long-enough`);a.rating=1000;accounts.push(a);
    participants.push({accountId:id,team:i<5?'blue':'red',ratingBefore:1000,ratingAfter:i<5?1016:984,ratingK:32,abandoned:false,integrityScore:0,integrityReasons:[],opponents:[]});
  }
  const journal=settlementRecord(settlement,{matchId,result,status:'PREPARED',participants});
  fs.writeFileSync(path.join(dir,'accounts.json'),JSON.stringify(accounts));
  fs.writeFileSync(path.join(dir,'settlements.json'),JSON.stringify([journal]));
  const env={...process.env,PORT:String(port),VANGUARD_DATA_DIR:dir,VANGUARD_BUY_SECONDS:'60'};
  const child=spawn(process.execPath,['server/index.mjs'],{cwd:path.resolve(new URL('.',import.meta.url).pathname,'..'),env,stdio:['ignore','pipe','pipe']});
  let stderr='';child.stderr.on('data',d=>stderr+=d.toString());
  try{
    await waitReady(port,child);await wait(250);
    let saved=JSON.parse(fs.readFileSync(path.join(dir,'accounts.json'),'utf8'));
    assert.equal(saved.every(a=>a.matchHistory.some(m=>m.settlementId===settlement)),true);
    assert.equal(saved.filter(a=>a.rating===1016).length,5);
    assert.equal(saved.filter(a=>a.rating===984).length,5);
    let settlements=JSON.parse(fs.readFileSync(path.join(dir,'settlements.json'),'utf8'));
    assert.equal(settlements.find(r=>r.id===settlement)?.status,'COMPLETED');
    await stop(child);
    const child2=spawn(process.execPath,['server/index.mjs'],{cwd:path.resolve(new URL('.',import.meta.url).pathname,'..'),env,stdio:['ignore','pipe','pipe']});
    let stderr2='';child2.stderr.on('data',d=>stderr2+=d.toString());
    try{
      await waitReady(port,child2);await wait(200);
      saved=JSON.parse(fs.readFileSync(path.join(dir,'accounts.json'),'utf8'));
      assert.equal(saved.every(a=>a.matchHistory.filter(m=>m.settlementId===settlement).length===1),true);
      assert.equal(saved.every(a=>a.history.filter(e=>e?.meta?.settlementId===settlement&&e.type==='matchPlayed').length===1),true);
    }finally{await stop(child2);if(child2.exitCode!==0)assert.fail(`second server failed: ${stderr2}`);}
    if(child.exitCode!==0)assert.fail(`server failed: ${stderr}`);
  }finally{if(child.exitCode===null)await stop(child);fs.rmSync(dir,{recursive:true,force:true});}
});
