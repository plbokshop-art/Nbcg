import test from 'node:test';
import assert from 'node:assert/strict';
import {settlementKey,createSettlementGuard,settlementRecord,validateSettlementRecord} from '../shared/settlement.mjs';

test('settlement key is deterministic for the same match result',()=>{
  const a=settlementKey('match_1',{winner:'blue',score:{blue:13,red:9},round:22});
  const b=settlementKey('match_1',{winner:'blue',score:{blue:13,red:9},round:22});
  assert.equal(a,b);
  assert.match(a,/^[a-f0-9]{64}$/);
});

test('different results cannot share a settlement key',()=>{
  const a=settlementKey('match_1',{winner:'blue',score:{blue:13,red:9},round:22});
  const b=settlementKey('match_1',{winner:'red',score:{blue:12,red:13},round:25});
  assert.notEqual(a,b);
});

test('settlement guard applies a result at most once',()=>{
  const guard=createSettlementGuard();
  const key=settlementKey('match_1',{winner:'blue',score:{blue:13,red:9},round:22});
  assert.equal(guard.mark(key),true);
  assert.equal(guard.mark(key),false);
  assert.equal(guard.has(key),true);
  assert.equal(guard.size(),1);
});

test('settlement guard accepts independent matches',()=>{
  const guard=createSettlementGuard();
  const a=settlementKey('match_1',{winner:'blue',score:{blue:13,red:9},round:22});
  const b=settlementKey('match_2',{winner:'red',score:{blue:7,red:13},round:20});
  assert.equal(guard.mark(a),true);
  assert.equal(guard.mark(b),true);
  assert.equal(guard.size(),2);
});

test('persistent settlement records distinguish prepared from completed state',()=>{
  const key=settlementKey('match_journal',{winner:'blue',score:{blue:13,red:8},round:21});
  const prepared=settlementRecord(key,{matchId:'match_journal',result:{winner:'blue',score:{blue:13,red:8},round:21},status:'PREPARED',participants:[{accountId:'a',ratingBefore:1000,ratingAfter:1016}]});
  assert.equal(validateSettlementRecord(prepared),true);
  prepared.status='COMPLETED';
  assert.equal(validateSettlementRecord(prepared),true);
});
