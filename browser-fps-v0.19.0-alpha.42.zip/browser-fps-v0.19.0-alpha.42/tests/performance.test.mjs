import test from 'node:test';
import assert from 'node:assert/strict';
import {makePlayer, applyMovement} from '../shared/game.mjs';
import {makeSnapshot} from '../shared/net.mjs';
import {createPerformanceMetrics, recordTick, recordSnapshot, recordOutbound, performanceSnapshot} from '../shared/performance.mjs';

test('performance metrics aggregate bounded tick and snapshot telemetry',()=>{
  const m=createPerformanceMetrics();
  recordTick(m,1.5); recordTick(m,30); recordSnapshot(m,.4,1200); recordOutbound(m,1200);
  const s=performanceSnapshot(m,Date.now()+1000);
  assert.equal(s.ticks,2);
  assert.equal(s.tick.overruns,1);
  assert.equal(s.snapshots.totalBytes,1200);
  assert.equal(s.outbound.bytes,1200);
});

test('authoritative 10-player movement and snapshot workload completes within performance budget',()=>{
  const players=Array.from({length:10},(_,i)=>makePlayer(String(i+1),i-5,0,i%2?'red':'blue'));
  const started=process.hrtime.bigint();
  let bytes=0;
  for(let tick=0;tick<600;tick++){
    for(const [i,p] of players.entries()){
      applyMovement(p,{seq:tick+1,forward:i%3!==0,back:false,left:i%4===0,right:i%4===1,sprint:i%5===0,crouch:false,yaw:(tick+i)*.002,pitch:0},1/60,tick/60);
    }
    if(tick%3===0){
      const payload=JSON.stringify({type:'state',time:tick/60,players:players.map(p=>makeSnapshot(p,tick+1)),grenades:[]});
      bytes+=Buffer.byteLength(payload);
    }
  }
  const elapsedMs=Number(process.hrtime.bigint()-started)/1e6;
  assert.ok(elapsedMs<2000,`10-player 600-tick workload took ${elapsedMs.toFixed(1)}ms`);
  assert.ok(bytes>100000);
  assert.ok(players.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.z)));
});
