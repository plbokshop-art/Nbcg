import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const client=fs.readFileSync(new URL('../client/main.mjs',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../client/index.html',import.meta.url),'utf8');

test('client exposes authoritative death overlay and teammate spectator flow',()=>{
  assert.match(html,/id="deathOverlay"/);
  assert.match(html,/id="deathInfo"/);
  assert.match(html,/id="spectateInfo"/);
  assert.match(client,/cycleSpectator\(1\)/);
  assert.match(client,/m\.victim===me\?\.id/);
  assert.match(client,/setDeathOverlay\(true\)/);
  assert.match(client,/cycleSpectator\(1\)/);
});


test('client exposes selectable grenade loadout controls',()=>{
  assert.match(html,/id="grenade"/);
  assert.match(client,/selectedGrenade='frag'/);
  assert.match(client,/selectedGrenade=available/);
  assert.match(client,/throwGrenade:selectedGrenade/);
});


test('client exposes explicit objective cancellation actions',()=>{assert.match(client,/objective:'cancelPlant'/);assert.match(client,/objective:'cancelDefuse'/);});
