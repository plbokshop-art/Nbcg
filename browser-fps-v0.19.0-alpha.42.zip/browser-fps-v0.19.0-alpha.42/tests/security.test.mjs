import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=fs.readFileSync(path.join(root,'server/index.mjs'),'utf8');
const game=fs.readFileSync(path.join(root,'shared/game.mjs'),'utf8');

test('server enforces bounded WebSocket payloads and message rate',()=>{
  assert.match(server,/MAX_WS_MESSAGE_BYTES/);
  assert.match(server,/MAX_MESSAGES_PER_SECOND/);
  assert.match(server,/buf\.length>MAX_WS_BUFFER/);
  assert.match(server,/!masked/);
});

test('action packets use monotonically increasing sequence validation',()=>{
  assert.match(server,/freshActionSeq/);
  assert.match(server,/seq<=p\._lastActionSeq/);
  assert.match(server,/actionFresh&&msg\.fire===true/);
  assert.match(server,/actionFresh&&msg\.reload===true/);
});

test('rewind is bounded and derived from server-observed RTT',()=>{
  assert.match(server,/NET\.MAX_REWIND_SECONDS/);
  assert.match(server,/p\._rttMs/);
  assert.match(server,/Date\.now\(\)-p\._pingSentAt/);
  assert.match(server,/gameTime-rewind/);
});

test('damage and ammo remain server-side',()=>{
  assert.match(game,/shooter\.ammo--/);
  assert.match(game,/best\.liveTarget\.hp=Math\.max/);
  assert.match(game,/shooter\.score\+\+/);
});

import { makePlayer } from '../shared/game.mjs';
import { AC, inspectInput, recordActionViolation } from '../shared/anticheat.mjs';

test('anti-cheat detects impossible sequence jumps and extreme pitch',()=>{
  const p=makePlayer('ac1',0,0,'blue');
  assert.equal(inspectInput(p,{seq:1,yaw:0,pitch:0},0).ok,true);
  const jump=inspectInput(p,{seq:AC.MAX_SEQ_JUMP+2,yaw:0,pitch:0},.01);
  assert.equal(jump.ok,false);
  const pitch=inspectInput(p,{seq:AC.MAX_SEQ_JUMP+3,yaw:0,pitch:2},.02);
  assert.equal(pitch.ok,false);
  assert.ok(p._ac.score>0);
});

test('anti-cheat records replay/illegal action strikes and quarantines only after repeated violations',()=>{
  const p=makePlayer('ac2',0,0,'blue');
  let result;
  for(let i=0;i<6;i++) result=recordActionViolation(p,'ACTION_REPLAY',i*0.01,2);
  assert.equal(result.quarantine,true);
  assert.ok(p._ac.events.length<=64);
});
