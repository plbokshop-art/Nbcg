import test from 'node:test';
import assert from 'node:assert/strict';
import {RATING,expectedScore,updateRating,applyMatchRatings} from '../shared/rating.mjs';

test('rating uses bounded Elo-style updates',()=>{
 assert.equal(expectedScore(1000,1000),0.5);
 assert.ok(updateRating(1000,1200)>1000);
 assert.ok(updateRating(1200,1000)<1200);
 assert.equal(updateRating(1000,1000,.5),1000);
 assert.ok(updateRating(RATING.MIN,5000,0)>=RATING.MIN);
 assert.ok(updateRating(RATING.MAX,100,1)<=RATING.MAX);
});
test('match ratings reward upset wins more than expected wins',()=>{
 const upset=updateRating(1000,1400,1)-1000;
 const expected=updateRating(1400,1000,1)-1400;
 assert.ok(upset>expected);
});
test('team match rating changes are server-side and zero-sum within rounding',()=>{
 const players=[...Array(5)].map((_,i)=>({accountId:`b${i}`,team:'blue',rating:1000})).concat([...Array(5)].map((_,i)=>({accountId:`r${i}`,team:'red',rating:1000})));
 applyMatchRatings(players,'blue');
 assert.ok(players.filter(p=>p.team==='blue').every(p=>p.rating>1000));
 assert.ok(players.filter(p=>p.team==='red').every(p=>p.rating<1000));
});
