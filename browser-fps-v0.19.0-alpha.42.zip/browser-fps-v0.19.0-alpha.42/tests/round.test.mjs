import test from 'node:test';
import assert from 'node:assert/strict';
import {createRoundState,ROUND_PHASES,aliveTeams,resolveRoundWinner,nextPhase} from '../shared/round.mjs';
import {makePlayer,tryFire,WEAPONS,detonateGrenade} from '../shared/game.mjs';

test('round state transitions are deterministic and one-way',()=>{
  const s=createRoundState();
  assert.equal(s.phase,ROUND_PHASES.BUY);
  const live=nextPhase(s,12);
  assert.equal(live.phase,ROUND_PHASES.LIVE);
  assert.equal(live.phaseEnds,132);
  const post=nextPhase(live,132,'blue');
  assert.equal(post.phase,ROUND_PHASES.POST);
  assert.equal(post.winner,'blue');
  const next=nextPhase(post,136);
  assert.equal(next.phase,ROUND_PHASES.BUY);
  assert.equal(next.round,2);
  assert.equal(next.winner,null);
});

test('spectators do not count toward round elimination',()=>{
  const a=makePlayer('a',0,0,'blue'),b=makePlayer('b',5,0,'red');
  b.alive=false;b.status='DEAD';
  const s=makePlayer('s',0,5,'red');s.alive=false;s.status='SPECTATOR';
  const map=new Map([[a.id,a],[b.id,b],[s.id,s]]);
  assert.deepEqual(aliveTeams(map),{blue:1,red:0});
  assert.equal(resolveRoundWinner(map),'blue');
});

test('lethal shot creates authoritative death state and attribution',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-5,'red');
  a.yaw=0;a.pitch=0;b.hp=1;
  const e=tryFire(a,new Map([[a.id,a],[b.id,b]]),0);
  assert.equal(e.killed,true);
  assert.equal(b.alive,false);
  assert.equal(b.status,'DEAD');
  assert.equal(b.lastKillerId,'a');
  assert.equal(b.deaths,1);
  assert.equal(a.score,1);
});

test('lethal grenade creates authoritative death state and attribution',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',1,-4,'red');
  b.hp=1;
  const events=detonateGrenade(a,'frag',new Map([[a.id,a],[b.id,b]]),{x:0,y:1,z:-4});
  assert.ok(events.some(e=>e.type==='grenadeKill'&&e.target==='b'));
  assert.equal(b.alive,false);
  assert.equal(b.status,'DEAD');
  assert.equal(b.lastKillerId,'a');
});

test('disconnected player is protected by reconnect grace in match resolution',()=>{
  const a=makePlayer('a',0,0,'blue'),b=makePlayer('b',5,0,'red');
  a.alive=true;a.status='ALIVE';b.alive=false;b.status='DISCONNECTED';
  const map=new Map([[a.id,a],[b.id,b]]);
  assert.equal(resolveRoundWinner(map), 'blue');
  assert.equal(resolveRoundWinner(map,{includeDisconnected:true}), null);
  b.status='DEAD';
  assert.equal(resolveRoundWinner(map,{includeDisconnected:true}), 'blue');
});
