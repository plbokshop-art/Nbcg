import test from 'node:test';
import assert from 'node:assert/strict';
import {buildRecoverySnapshot,validateRecoverySnapshot,recoveryRecord,verifyRecoveryRecord,recoveryDigest} from '../shared/recovery.mjs';

test('recovery snapshot captures active match and only match players',()=>{
  const snapshot=buildRecoverySnapshot({activeMatch:{id:'m1',players:[{playerId:'1',accountId:'a',team:'blue'}],targetScore:13},phase:'LIVE',phaseEnds:12,round:3,score:{blue:2,red:1},gameTime:10,players:new Map([
    ['1',{id:'1',accountId:'a',team:'blue',matchId:'m1',x:2,y:0,z:3,hp:75,money:800,inventory:{weapons:['pistol'],grenades:[]},wallet:{balance:800,version:2,ledger:[]},weapon:'pistol',ammo:9,reserve:30,sessionToken:'session-test-123456789'}],
    ['2',{id:'2',accountId:'spectator',team:'red',matchId:null}]
  ]),smokeZones:new Map([['s1',{id:'s1',x:2,y:.2,z:2,radius:4.2,expiresAt:20}]]),grenades:new Map([['g1',{id:'g1',owner:'1',type:'frag',x:1,y:.2,z:2,vx:1,vy:2,vz:3,detonateAt:14}]])});
  assert.equal(snapshot.players.length,1);assert.equal(snapshot.players[0].accountId,'a');assert.equal(snapshot.grenades.length,1);assert.equal(snapshot.smokeZones.length,1);assert.equal(validateRecoverySnapshot(snapshot),true);
});

test('recovery record detects tampering',()=>{
  const s={version:1,savedAt:1,gameTime:1,phase:'LIVE',phaseEnds:2,round:1,score:{blue:0,red:0},activeMatch:{id:'m',players:[{playerId:'1',accountId:'a',team:'blue'}]},players:[{id:'1',accountId:'a',team:'blue',sessionToken:'session-test-123456789'}],grenades:[],smokeZones:[]};
  const r=recoveryRecord(s);assert.equal(verifyRecoveryRecord(r),true);r.score={blue:99,red:0};assert.equal(verifyRecoveryRecord(r),false);assert.notEqual(recoveryDigest({...s,score:{blue:99,red:0}}),r.digest);
});
