import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const port = 18000 + (process.pid % 1000);
let child;

async function waitForServer() {
  child = spawn(process.execPath, ['server/index.mjs'], {
    cwd: root,
    env: {...process.env, PORT: String(port)},
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let output = '';
  child.stdout.on('data', b => { output += b.toString(); });
  child.stderr.on('data', b => { output += b.toString(); });
  const deadline = Date.now() + 5000;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/health`);
      if (r.ok) return;
    } catch {}
    await new Promise(r => setTimeout(r, 50));
  }
  throw new Error(`server did not start: ${output}`);
}

test.before(async () => waitForServer());
test.after(() => child?.kill('SIGTERM'));

test('server serves browser entrypoint as JavaScript-compatible modules', async () => {
  const r = await fetch(`http://127.0.0.1:${port}/main.mjs`);
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-type') ?? '', /^text\/javascript/);
  const source = await r.text();
  assert.match(source, /from ['"]\.\.\/shared\/map\.mjs['"]/);
});

test('server exposes shared browser modules from the project root', async () => {
  const r = await fetch(`http://127.0.0.1:${port}/shared/map.mjs`);
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-type') ?? '', /^text\/javascript/);
  assert.match(await r.text(), /Vanguard District/);
});

test('server serves weapon GLB with glTF binary MIME type', async () => {
  const r = await fetch(`http://127.0.0.1:${port}/assets/weapons/vanguard_rifle.glb`);
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('content-type'), 'model/gltf-binary');
  const bytes = new Uint8Array(await r.arrayBuffer());
  assert.equal(String.fromCharCode(...bytes.slice(0, 4)), 'glTF');
});

test('static server rejects traversal outside allowed roots', async () => {
  for (const p of ['/../server/index.mjs', '/shared/../server/index.mjs', '/%2e%2e/server/index.mjs']) {
    const r = await fetch(`http://127.0.0.1:${port}${p}`);
    assert.ok(r.status === 400 || r.status === 404, `${p} returned ${r.status}`);
  }
});
