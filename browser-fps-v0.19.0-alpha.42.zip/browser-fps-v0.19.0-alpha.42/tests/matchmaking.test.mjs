import test from 'node:test';
import assert from 'node:assert/strict';
import {createMatchmaker,validateTeamBalance} from '../shared/matchmaking.mjs';

test('matchmaker queues unique accounts and rejects duplicates',()=>{
 const mm=createMatchmaker({teamSize:1});
 assert.equal(mm.enqueue('a').ok,true); assert.equal(mm.enqueue('a').error,'ALREADY_QUEUED'); assert.equal(mm.queueSize,1);
});
test('matchmaker does not create undersized match',()=>{const mm=createMatchmaker({teamSize:2});mm.enqueue('a');mm.enqueue('b');assert.equal(mm.popReady(),null);assert.equal(mm.queueSize,2);});
test('matchmaker creates balanced 2v2 match',()=>{const mm=createMatchmaker({teamSize:2});for(const id of ['a','b','c','d'])assert.equal(mm.enqueue(id).ok,true);const m=mm.popReady(123);assert.equal(m.id,'match_000001');assert.equal(m.createdAt,123);assert.equal(validateTeamBalance(m.players,2),true);assert.deepEqual(m.players.map(p=>p.team),['blue','blue','red','red']);assert.equal(mm.queueSize,0);});
test('party remains intact during match formation',()=>{const mm=createMatchmaker({teamSize:2});mm.enqueue('a','party1');mm.enqueue('b','party1');mm.enqueue('c','party2');mm.enqueue('d','party2');const m=mm.popReady();assert.equal(m.players.filter(p=>p.partyId==='party1').length,2);assert.equal(m.players.filter(p=>p.partyId==='party2').length,2);});
test('queue capacity is enforced',()=>{const mm=createMatchmaker({teamSize:1,maxQueue:2});assert.equal(mm.enqueue('a').ok,true);assert.equal(mm.enqueue('b').ok,true);assert.equal(mm.enqueue('c').error,'QUEUE_FULL');});
test('remove safely cancels queued player',()=>{const mm=createMatchmaker({teamSize:1});mm.enqueue('a');assert.equal(mm.remove('a'),true);assert.equal(mm.remove('a'),false);assert.equal(mm.queueSize,0);});

test('active match reserves all players and blocks duplicate queueing',()=>{const mm=createMatchmaker({teamSize:2});for(const id of ['a','b','c','d'])assert.equal(mm.enqueue(id).ok,true);const m=mm.popReady();assert.ok(m);assert.equal(mm.enqueue('a').error,'IN_MATCH');assert.equal(mm.snapshot().active,4);assert.equal(mm.completeMatch(m.id),true);assert.equal(mm.enqueue('a').ok,true);});
test('party size is bounded before match formation',()=>{const mm=createMatchmaker({teamSize:2});for(const id of ['a','b','c','d','e','f']){const r=mm.enqueue(id,'party');if(id==='f')assert.equal(r.error,'PARTY_FULL');}assert.equal(mm.queueSize,5);});
test('skill matchmaking prefers close ratings and balances team averages',()=>{
 const mm=createMatchmaker({teamSize:2});
 for(const [id,r] of [['a',1000],['b',1010],['c',1020],['d',1030]]) assert.equal(mm.enqueue(id,id,0,r).ok,true);
 const m=mm.popReady(0);assert.ok(m);
 const blue=m.players.filter(p=>p.team==='blue'),red=m.players.filter(p=>p.team==='red');
 const avg=x=>x.reduce((n,p)=>n+p.rating,0)/x.length;
 assert.ok(Math.abs(avg(blue)-avg(red))<=10);
});
test('skill search expands with queue wait',()=>{
 const mm=createMatchmaker({teamSize:1});
 assert.equal(mm.enqueue('a','a',0,1000).ok,true);assert.equal(mm.enqueue('b','b',0,1800).ok,true);
 assert.equal(mm.popReady(0),null);
 assert.ok(mm.popReady(20_000));
});

test('mixed-skill party uses stronger-member effective skill for queue matching',()=>{
 const mm=createMatchmaker({teamSize:1});
 mm.enqueue('low','party',0,1000);
 mm.enqueue('high','party',0,1800);
 mm.enqueue('mid','mid',0,1050);
 mm.enqueue('opp','opp',0,1800);
 assert.equal(mm.popReady(0),null);
 const m=mm.popReady(20_000);
 assert.ok(m);
 assert.equal(m.players.length,2);
});
