import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';

const port=19300+Math.floor(Math.random()*400);
let server;

function readFrame(buffer){
  if(buffer.length<2)return null;
  const opcode=buffer[0]&15;
  let len=buffer[1]&127,offset=2;
  if(len===126){if(buffer.length<4)return null;len=buffer.readUInt16BE(2);offset=4;}
  else if(len===127){if(buffer.length<10)return null;const n=buffer.readBigUInt64BE(2);if(n>BigInt(16384))return null;len=Number(n);offset=10;}
  if(buffer.length<offset+len)return null;
  return {opcode,payload:buffer.subarray(offset,offset+len),next:offset+len};
}

function connect(resume=''){
  return new Promise((resolve,reject)=>{
    const key=crypto.randomBytes(16).toString('base64');
    const query=resume?`?resume=${encodeURIComponent(resume)}`:'';
    const socket=net.connect(port,'127.0.0.1',()=>socket.write(
      `GET /${query} HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`
    ));
    let buffer=Buffer.alloc(0),handshake=false;
    const timer=setTimeout(()=>{socket.destroy();reject(new Error('websocket welcome timeout'));},2500);
    socket.on('data',chunk=>{
      buffer=Buffer.concat([buffer,chunk]);
      if(!handshake){const i=buffer.indexOf('\r\n\r\n');if(i<0)return;handshake=true;buffer=buffer.subarray(i+4);}
      while(true){
        const frame=readFrame(buffer);if(!frame)break;buffer=buffer.subarray(frame.next);
        if(frame.opcode!==1)continue;
        try{const msg=JSON.parse(frame.payload.toString());if(msg.type==='welcome'){clearTimeout(timer);resolve({socket,msg});return;}}
        catch{}
      }
    });
    socket.on('error',err=>{clearTimeout(timer);reject(err);});
  });
}

test.before(async()=>{
  server=spawn(process.execPath,['server/index.mjs'],{env:{...process.env,PORT:String(port),VANGUARD_RECONNECT_GRACE_SECONDS:'2'},stdio:'ignore'});
  await new Promise(r=>setTimeout(r,350));
});

test.after(async()=>{server?.kill('SIGTERM');await new Promise(r=>setTimeout(r,100));});

test('reconnect restores the same authoritative player session',async()=>{
  const first=await connect();
  const id=first.msg.id,token=first.msg.sessionToken;
  assert.equal(typeof token,'string');
  first.socket.destroy();
  await new Promise(r=>setTimeout(r,150));
  const resumed=await connect(token);
  assert.equal(resumed.msg.id,id);
  assert.equal(resumed.msg.sessionToken,token);
  assert.equal(resumed.msg.resumed,true);
  resumed.socket.destroy();
});

test('active session token cannot create a duplicate connection',async()=>{
  const first=await connect();
  const token=first.msg.sessionToken;
  const duplicate=await new Promise(resolve=>{
    const key=crypto.randomBytes(16).toString('base64'),socket=net.connect(port,'127.0.0.1',()=>socket.write(
      `GET /?resume=${encodeURIComponent(token)} HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`
    ));
    const timer=setTimeout(()=>{socket.destroy();resolve(true)},500);
    socket.on('close',()=>{clearTimeout(timer);resolve(true);});
    socket.on('error',()=>{clearTimeout(timer);resolve(true);});
  });
  assert.equal(duplicate,true);
  first.socket.destroy();
});

test('expired reconnect token creates a fresh session',async()=>{
  const first=await connect();
  const token=first.msg.sessionToken,id=first.msg.id;
  first.socket.destroy();
  await new Promise(r=>setTimeout(r,2500));
  const fresh=await connect(token);
  assert.notEqual(fresh.msg.id,id);
  assert.equal(fresh.msg.resumed,false);
  fresh.socket.destroy();
});
