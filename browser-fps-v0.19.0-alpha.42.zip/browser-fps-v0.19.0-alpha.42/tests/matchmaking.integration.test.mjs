import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';

const root=path.resolve(new URL('..',import.meta.url).pathname);
const port=20200+Math.floor(Math.random()*300);
const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-mm-')); let server;
function mask(payload){const p=Buffer.from(payload),k=crypto.randomBytes(4);for(let i=0;i<p.length;i++)p[i]^=k[i%4];return Buffer.concat([Buffer.from([0x81,0x80|p.length]),k,p]);}
function parseFrame(buffer){if(buffer.length<2)return null;let len=buffer[1]&127,offset=2;if(len===126){if(buffer.length<4)return null;len=buffer.readUInt16BE(2);offset=4;}if(buffer.length<offset+len)return null;return {msg:JSON.parse(buffer.subarray(offset,offset+len).toString()),next:offset+len};}
async function connect(){return new Promise((resolve,reject)=>{const key=crypto.randomBytes(16).toString('base64'),socket=net.connect(port,'127.0.0.1');let buf=Buffer.alloc(0),handshake=false,timer=setTimeout(()=>{socket.destroy();reject(new Error('welcome timeout'));},4000);socket.on('connect',()=>socket.write(`GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`));socket.on('data',chunk=>{buf=Buffer.concat([buf,chunk]);if(!handshake){const i=buf.indexOf('\r\n\r\n');if(i<0)return;handshake=true;buf=buf.subarray(i+4);}while(true){const f=parseFrame(buf);if(!f)break;buf=buf.subarray(f.next);if(f.msg.type==='welcome'){clearTimeout(timer);resolve({socket,welcome:f.msg});return;}}});socket.on('error',reject);});}
function waitFor(socket,pred,timeout=5000){return new Promise((resolve,reject)=>{let buf=Buffer.alloc(0);const timer=setTimeout(()=>{socket.off('data',on);reject(new Error('message timeout'));},timeout);const on=chunk=>{buf=Buffer.concat([buf,chunk]);while(true){const f=parseFrame(buf);if(!f)break;buf=buf.subarray(f.next);if(pred(f.msg)){clearTimeout(timer);socket.off('data',on);resolve(f.msg);return;}}};const onData=chunk=>on(chunk);socket.on('data',onData);});}
test.before(async()=>{server=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:String(port),VANGUARD_DATA_DIR:dataDir,VANGUARD_BUY_SECONDS:'60'},stdio:'ignore'});const deadline=Date.now()+5000;while(Date.now()<deadline){try{if((await fetch(`http://127.0.0.1:${port}/ready`)).ok)return;}catch{}await new Promise(r=>setTimeout(r,50));}throw new Error('server start timeout');});
test.after(async()=>{server?.kill('SIGTERM');await new Promise(r=>setTimeout(r,400));fs.rmSync(dataDir,{recursive:true,force:true});});

test('ten authenticated clients form one server-authoritative 5v5 match',async()=>{
 const clients=[];
 try{
  for(let i=0;i<10;i++){const c=await connect();clients.push(c);c.socket.write(mask(JSON.stringify({authAccountToken:null,seq:i+1})));const auth=await waitFor(c.socket,m=>m.type==='auth');assert.equal(auth.ok,true);c.socket.write(mask(JSON.stringify({seq:100+i,joinMatchmaking:true})));}
  const found=await Promise.race(clients.map(c=>waitFor(c.socket,m=>m.type==='matchFound',7000)));
  assert.equal(found.teams.blue.length,5);assert.equal(found.teams.red.length,5);assert.equal(found.teams.blue.length+found.teams.red.length,10);
  const ids=new Set([...found.teams.blue,...found.teams.red]);assert.equal(ids.size,10);
 } finally {for(const c of clients)c.socket.destroy();}
});

test('active match survives hard process restart through recovery snapshot',async()=>{
 const clients=[]; let restarted;
 try{
  await new Promise(r=>setTimeout(r,1500));
  const recoveryFile=path.join(dataDir,'active-match.json');assert.equal(fs.existsSync(recoveryFile),true);
  const persistedRaw=JSON.parse(fs.readFileSync(recoveryFile,'utf8'));const persisted=Array.isArray(persistedRaw)?persistedRaw.find(x=>x.id==='active'):persistedRaw;assert.equal(persisted.id,'active');assert.equal(persisted.activeMatch.players.length,10);
  server.kill('SIGKILL');await new Promise(r=>setTimeout(r,250));
  restarted=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,PORT:String(port),VANGUARD_DATA_DIR:dataDir,VANGUARD_BUY_SECONDS:'60'},stdio:'ignore'});
  const deadline=Date.now()+5000;let health;
  while(Date.now()<deadline){try{const r=await fetch(`http://127.0.0.1:${port}/health`);if(r.ok){health=await r.json();break;}}catch{}await new Promise(r=>setTimeout(r,50));}
  assert.ok(health);assert.equal(health.players,10);assert.equal(health.phase,'BUY');assert.deepEqual(health.score,{blue:0,red:0});
 } finally {for(const c of clients)c.socket.destroy();restarted?.kill('SIGTERM');server?.kill('SIGTERM');}
});
