import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {acquireInstanceLock} from '../shared/instance-lock.mjs';

test('instance lock blocks a live owner and releases cleanly',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-lock-'));
  const first=acquireInstanceLock(dir,{pid:process.pid});
  assert.throws(()=>acquireInstanceLock(dir,{pid:process.pid+1}),/already locked/);
  first.release();
  const second=acquireInstanceLock(dir,{pid:process.pid});
  second.release();
  assert.equal(fs.existsSync(path.join(dir,'.server.lock')),false);
  fs.rmSync(dir,{recursive:true,force:true});
});

test('instance lock recovers an orphaned owner record',()=>{
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-lock-orphan-'));
  fs.writeFileSync(path.join(dir,'.server.lock'),JSON.stringify({pid:99999999,startedAt:new Date().toISOString()}));
  const lock=acquireInstanceLock(dir,{pid:process.pid});
  assert.ok(lock.file.endsWith('.server.lock'));
  lock.release();
  fs.rmSync(dir,{recursive:true,force:true});
});
