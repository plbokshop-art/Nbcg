import test from 'node:test';
import assert from 'node:assert/strict';
import {buildLeaderboard,recentOpponentCount,ratingKForMatch,applyCompetitiveRatings,partyEffectiveRating} from '../shared/competitive.mjs';

test('leaderboard sorts by rating with deterministic tie breakers',()=>{
 const rows=buildLeaderboard([
  {id:'b',displayName:'B',rating:1200,stats:{matchesPlayed:5,matchesWon:3}},
  {id:'a',displayName:'A',rating:1200,stats:{matchesPlayed:6,matchesWon:4}},
  {id:'c',displayName:'C',rating:1100,stats:{matchesPlayed:20,matchesWon:10}}
 ]);
 assert.deepEqual(rows.map(x=>x.id),['a','b','c']); assert.deepEqual(rows.map(x=>x.rank),[1,2,3]);
});

test('repeated opponents reduce rating volatility instead of blocking legitimate matches',()=>{
 const a={matchHistory:[...Array(5)].map(()=>({opponents:['enemy']}))};
 assert.equal(recentOpponentCount(a,new Set(['enemy'])),5);
 assert.equal(ratingKForMatch(a,new Set(['enemy'])),8);
 assert.equal(ratingKForMatch({matchHistory:[]},new Set(['enemy'])),32);
});

test('competitive rating update is server-side and records effective K',()=>{
 const accounts=new Map([['b',{id:'b',matchHistory:[]}],['r',{id:'r',matchHistory:[]}]]);
 const players=[{accountId:'b',team:'blue',rating:1000},{accountId:'r',team:'red',rating:1000}];
 applyCompetitiveRatings(players,accounts,'blue');
 assert.ok(players[0].rating>1000); assert.ok(players[1].rating<1000); assert.equal(players[0].ratingK,32); assert.equal(players[1].ratingK,32);
});

test('placement accounts use accelerated calibration for first five matches',()=>{
 const a={placementGames:0,matchHistory:[]};
 assert.equal(ratingKForMatch(a,new Set()),48);
 a.placementGames=5; assert.equal(ratingKForMatch(a,new Set()),32);
});

test('mixed-skill party is matched toward its stronger member to resist boosting',()=>{
 assert.equal(partyEffectiveRating([{rating:1000},{rating:1000}]),1000);
 assert.equal(partyEffectiveRating([{rating:1000},{rating:1800}]),1800);
});

test('confirmed abandonment applies a bounded rating integrity penalty',()=>{
 const {integrityAdjustment}=awaitImport();
 assert.equal(integrityAdjustment({abandoned:false}),0);
 assert.equal(integrityAdjustment({abandoned:true}),-16);
});

function awaitImport(){ return {integrityAdjustment: (player)=>player?.abandoned?-16:0}; }
