import test from 'node:test';
import assert from 'node:assert/strict';
import {OBJECTIVE,objectiveState,siteAt,startPlant,cancelPlant,completePlant,startDefuse,cancelDefuse,resolveObjective,objectiveWinner,objectiveTimeWinner,dropDevice,pickupDevice,interruptPlant} from '../shared/objective.mjs';
function p(id,team,x,z){return {id,team,x,z,alive:true,status:'ALIVE'};}
test('attacker can start and complete plant on objective site',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});assert.equal(siteAt(a.x,a.z).id,'site_a');assert.equal(startPlant(o,a,10),true);assert.equal(o.status,'PLANTING');assert.equal(completePlant(o,13),true);assert.equal(o.status,'PLANTED');assert.equal(o.detonateAt,48);});
test('plant cannot start outside site or for defender',()=>{const o=objectiveState({round:1,carrierId:'a'});assert.equal(startPlant(o,p('a','blue',0,0),0),false);assert.equal(startPlant(o,p('r','red',-12,-8),0),false);});
test('defender can start defuse and defuse wins the round',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});startPlant(o,a,0);completePlant(o,3);const d=p('d','red',-12,-8);assert.equal(startDefuse(o,d,4),true);o.defuseAt=9;const players=new Map([[d.id,d],[a.id,a]]);assert.equal(resolveObjective(o,players,9),'defuse');assert.equal(objectiveWinner(o),'red');});
test('bomb detonation wins for attacker',()=>{const o=objectiveState({round:1});o.status='PLANTED';o.detonateAt=10;o.attacker='blue';const players=new Map();assert.equal(resolveObjective(o,players,10),'detonation');assert.equal(objectiveWinner(o),'blue');});

test('objective alternates attacking side by round',()=>{assert.equal(objectiveState({round:1}).attacker,'blue');assert.equal(objectiveState({round:2}).attacker,'red');});


test('planter can explicitly cancel an active plant',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});assert.equal(startPlant(o,a,10),true);assert.equal(cancelPlant(o,a),true);assert.equal(o.status,'NONE');assert.equal(o.plantBy,null);assert.equal(o.site,null);});

test('wrong player cannot cancel another players plant',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});const b=p('b','blue',-12,-8);startPlant(o,a,10);assert.equal(cancelPlant(o,b),false);assert.equal(o.status,'PLANTING');});

test('defuser can cancel an active defuse',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});startPlant(o,a,0);completePlant(o,3);const d=p('d','red',-12,-8);assert.equal(startDefuse(o,d,4),true);assert.equal(cancelDefuse(o,d),true);assert.equal(o.defuseBy,null);assert.equal(o.defuseAt,0);assert.equal(o.status,'PLANTED');});

test('objective cannot resolve while defuse is cancelled',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});startPlant(o,a,0);completePlant(o,3);const d=p('d','red',-12,-8);startDefuse(o,d,4);cancelDefuse(o,d);const players=new Map([[d.id,d]]);assert.equal(resolveObjective(o,players,9),null);assert.equal(o.status,'PLANTED');});

test('only the device carrier can plant',()=>{const a=p('a','blue',-12,-8);const b=p('b','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});assert.equal(startPlant(o,b,1),false);assert.equal(startPlant(o,a,1),true);});

test('carrier death drops the device and teammate can pick it up',()=>{const a=p('a','blue',-12,-8);const b=p('b','blue',-10.8,-8);const o=objectiveState({round:1,carrierId:a.id});a.x=-10;a.z=-8;assert.equal(dropDevice(o,a),true);assert.equal(o.dropped,true);assert.equal(o.carrierId,null);assert.equal(pickupDevice(o,b),true);assert.equal(o.carrierId,'b');assert.equal(o.dropped,false);});

test('defender cannot pick up a dropped device',()=>{const a=p('a','blue',-12,-8);const d=p('d','red',-12,-8);const o=objectiveState({round:1,carrierId:a.id});assert.equal(dropDevice(o,a),true);assert.equal(pickupDevice(o,d),false);assert.equal(o.dropped,true);});

test('round timer awards the defender when attackers fail to plant',()=>{assert.equal(objectiveTimeWinner(objectiveState({round:1})), 'red');assert.equal(objectiveTimeWinner(objectiveState({round:2})), 'blue');});
test('planted objective timeout keeps attacker as winner',()=>{const o=objectiveState({round:1});o.status='PLANTED';assert.equal(objectiveTimeWinner(o),'blue');});


test('interrupted plant drops the device for teammate recovery',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});assert.equal(startPlant(o,a,10),true);a.x=-10.5;a.z=-8;assert.equal(interruptPlant(o,a),true);assert.equal(o.status,'NONE');assert.equal(o.plantBy,null);assert.equal(o.carrierId,null);assert.equal(o.dropped,true);assert.equal(o.dropX,a.x);assert.equal(o.dropZ,a.z);const b=p('b','blue',-10.5,-8);assert.equal(pickupDevice(o,b),true);assert.equal(o.carrierId,'b');});

test('explicit plant cancellation keeps the device with the planter',()=>{const a=p('a','blue',-12,-8);const o=objectiveState({round:1,carrierId:a.id});startPlant(o,a,1);assert.equal(cancelPlant(o,a),true);assert.equal(o.dropped,false);assert.equal(o.carrierId,'a');});
