import test from 'node:test';
import assert from 'node:assert/strict';
import {makePlayer,applyMovement,updateReload,tryFire} from '../shared/game.mjs';
import {ANIMATION,locomotionFor,advanceAnimation,triggerAction,updateAction} from '../shared/animation.mjs';

test('locomotion state machine covers grounded movement states',()=>{
  assert.equal(locomotionFor({alive:true,speed:0}), 'idle');
  assert.equal(locomotionFor({alive:true,speed:2,sprint:false}), 'walk');
  assert.equal(locomotionFor({alive:true,speed:7,sprint:true}), 'run');
  assert.equal(locomotionFor({alive:true,speed:0,crouch:true}), 'crouch');
  assert.equal(locomotionFor({alive:true,speed:2,crouch:true}), 'crouch_walk');
  assert.equal(locomotionFor({alive:true,airborne:true}), 'jump');
  assert.equal(locomotionFor({alive:false,speed:4}), 'dead');
});

test('animation cycle advances deterministically and wraps',()=>{
  const p={anim:'walk',animCycle:0};
  const a=advanceAnimation(p,0.1,0);
  assert.ok(a>0);
  advanceAnimation(p,10,0);
  assert.ok(p.animCycle>=0 && p.animCycle<Math.PI*2);
});

test('player movement produces authoritative animation telemetry',()=>{
  const p=makePlayer('anim',0,-4,'blue');
  applyMovement(p,{forward:true,yaw:0,pitch:0},1/60,1);
  assert.equal(p.anim,'walk');
  assert.ok(p.animCycle>0);
  applyMovement(p,{forward:true,sprint:true,yaw:0,pitch:0},1/60,1.1);
  assert.equal(p.anim,'run');
  applyMovement(p,{crouch:true,yaw:0,pitch:0},1/60,1.2);
  assert.ok(['crouch','crouch_walk'].includes(p.anim));
});

test('reload action has a bounded lifecycle',()=>{
  const p=makePlayer('reload',0,0);
  p.ammo=1;p.reserve=10;p.reloading=true;p.reloadAt=1;
  updateReload(p,0);
  assert.equal(p.action,'reload');
  assert.ok(p.actionUntil>=1);
  updateReload(p,1.01);
  assert.equal(p.reloading,false);
  assert.equal(p.action,'idle');
});

test('fire action is emitted with the authoritative shot',()=>{
  const a=makePlayer('a',0,-4,'blue'),b=makePlayer('b',0,-9,'red');
  a.yaw=0;a.pitch=-0.13;
  const map=new Map([[a.id,a],[b.id,b]]);
  const e=tryFire(a,map,0);
  assert.equal(e.type,'hit');
  assert.equal(a.action,'fire');
  assert.equal(a.actionUntil,0.1);
});

test('action state expires without affecting locomotion state',()=>{
  const p={alive:true,action:'idle'};
  triggerAction(p,'fire',2,0.1);
  assert.equal(p.action,'fire');
  updateAction(p,2.11);
  assert.equal(p.action,'idle');
  assert.equal(ANIMATION.idle.cycle,0);
});
