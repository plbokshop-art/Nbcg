import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const port=19000+(process.pid%1000);
const token='production-test-token-123456789';
const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-prod-'));
let child;

async function waitFor(pathname, expected=200){
  const deadline=Date.now()+5000;
  while(Date.now()<deadline){
    try{
      const r=await fetch(`http://127.0.0.1:${port}${pathname}`);
      if(r.status===expected)return r;
    }catch{}
    await new Promise(r=>setTimeout(r,50));
  }
  throw new Error(`server did not return ${expected} for ${pathname}`);
}

test('production exposes liveness/readiness but protects diagnostics and debug state',async()=>{
  child=spawn(process.execPath,['server/index.mjs'],{cwd:root,env:{...process.env,NODE_ENV:'production',PORT:String(port),VANGUARD_METRICS_TOKEN:token,VANGUARD_DATA_DIR:dataDir},stdio:'ignore'});
  const ready=await waitFor('/ready');
  assert.equal((await ready.json()).ready,true);
  const health=await waitFor('/health');
  assert.equal(health.headers.get('cache-control'),'no-store');
  assert.equal((await fetch(`http://127.0.0.1:${port}/api/state`)).status,404);
  assert.equal((await fetch(`http://127.0.0.1:${port}/metrics`)).status,401);
  assert.equal((await fetch(`http://127.0.0.1:${port}/metrics`,{headers:{authorization:`Bearer ${token}`}})).status,200);
  assert.equal((await fetch(`http://127.0.0.1:${port}/metrics`,{headers:{'x-metrics-token':token}})).status,200);
});

test('SIGTERM performs graceful shutdown and process exits cleanly',async()=>{
  assert.ok(child&&child.exitCode===null);
  const exited=new Promise(resolve=>child.once('exit',(code,signal)=>resolve({code,signal})));
  child.kill('SIGTERM');
  const result=await Promise.race([exited,new Promise((_,reject)=>setTimeout(()=>reject(new Error('shutdown timeout')),6000))]);
  assert.equal(result.code,0);
  assert.equal(result.signal,null);
  assert.equal(fs.existsSync(path.join(dataDir,'.server.lock')),false);
  fs.rmSync(dataDir,{recursive:true,force:true});
});
