import test from 'node:test';
import assert from 'node:assert/strict';
import {makeAccount} from '../shared/account.mjs';
import {buildIntegrityReport,COMPETITIVE,detectCompetitiveAbuse,ensureCompetitiveIntegrity,recordCompetitiveIntegrity} from '../shared/competitive.mjs';

test('competitive integrity detects repeated opponent pattern without blocking play',()=>{
 const a=makeAccount('a','Alpha');
 a.matchHistory=Array.from({length:5},(_,i)=>({matchId:`m${i}`,opponents:['enemy']}));
 const signal=detectCompetitiveAbuse(a,{opponents:['enemy'],opponentRatings:[1400],winner:true});
 assert.ok(signal.score>0); assert.ok(signal.reasons.includes('REPEATED_OPPONENTS_HIGH'));
});

test('competitive integrity remains bounded and decays between signals',()=>{
 const a=makeAccount('a','Alpha');
 ensureCompetitiveIntegrity(a);
 recordCompetitiveIntegrity(a,{score:90,reasons:['TEST']});
 const first=a.competitiveIntegrity.riskScore;
 recordCompetitiveIntegrity(a,{score:0,reasons:[]});
 assert.equal(a.competitiveIntegrity.riskScore,Math.max(0,first-COMPETITIVE.INTEGRITY_DECAY_PER_MATCH));
 assert.ok(a.competitiveIntegrity.riskScore<=COMPETITIVE.INTEGRITY_MAX);
});

test('integrity signal is not exposed through public account snapshot',async()=>{
 const {publicAccount}=await import('../shared/account.mjs');
 const a=makeAccount('a','Alpha');
 recordCompetitiveIntegrity(a,{score:50,reasons:['TEST']});
 const out=publicAccount(a);
 assert.equal('competitiveIntegrity' in out,false);
});



test('integrity report is bounded and ordered without exposing tokens',()=>{
  const accounts=[{id:'a',tokenHash:'secret',stats:{matchesAbandoned:0,matchesPlayed:4},competitiveIntegrity:{riskScore:60,flags:[{x:1}],updatedAt:1}},{id:'b',tokenHash:'secret2',stats:{matchesAbandoned:1,matchesPlayed:5},competitiveIntegrity:{riskScore:80,flags:[{x:1},{x:2}],updatedAt:1}}];
  const rows=buildIntegrityReport(accounts,10);
  assert.equal(rows[0].accountId,'b');
  assert.equal(rows.length,2);
  assert.equal('tokenHash' in rows[0],false);
});
