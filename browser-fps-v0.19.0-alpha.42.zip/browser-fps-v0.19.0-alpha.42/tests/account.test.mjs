import test from 'node:test';
import assert from 'node:assert/strict';
import {ACCOUNT,makeAccount,normalizeDisplayName,publicAccount,recordAccountEvent} from '../shared/account.mjs';

test('display names are normalized and bounded',()=>{
  assert.equal(normalizeDisplayName('  Alpha   Wolf  '),'Alpha Wolf');
  assert.equal(normalizeDisplayName('x'),'Vanguard');
  assert.equal(normalizeDisplayName('bad<script>'),'Vanguard');
  assert.ok(ACCOUNT.MAX_NAME>=16);
});

test('public account never exposes token material',()=>{
  const a=makeAccount('acct_test','Player One');a.tokenHash='secret';
  const out=publicAccount(a);
  assert.equal(out.id,'acct_test');assert.equal(out.displayName,'Player One');
  assert.equal('tokenHash' in out,false);assert.deepEqual(out.stats,{kills:0,deaths:0,shots:0,headshots:0,roundsPlayed:0,roundsWon:0,matchesPlayed:0,matchesWon:0,matchesAbandoned:0});
});

test('account stats update deterministically and history is bounded',()=>{
  const a=makeAccount('acct_stats');
  for(let i=0;i<105;i++)recordAccountEvent(a,{type:i%2?'kill':'shot'});
  recordAccountEvent(a,{type:'death'});recordAccountEvent(a,{type:'headshot'});recordAccountEvent(a,{type:'roundPlayed'});recordAccountEvent(a,{type:'roundWon'});
  assert.equal(a.stats.kills,52);assert.equal(a.stats.shots,53);assert.equal(a.stats.deaths,1);assert.equal(a.stats.headshots,1);assert.equal(a.stats.roundsPlayed,1);assert.equal(a.stats.roundsWon,1);assert.equal(a.history.length,100);
});

test('legacy accounts safely initialize abandonment stat',()=>{
 const a={id:'legacy',displayName:'Legacy',createdAt:0,rating:1000,placementGames:5,stats:{kills:0,deaths:0,shots:0,headshots:0,roundsPlayed:0,roundsWon:0,matchesPlayed:1,matchesWon:0},history:[],matchHistory:[]};
 recordAccountEvent(a,{type:'matchAbandoned'}); assert.equal(a.stats.matchesAbandoned,1);
});
