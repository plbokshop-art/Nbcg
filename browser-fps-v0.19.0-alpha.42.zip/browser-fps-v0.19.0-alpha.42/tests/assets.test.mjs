import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const names=['pistol','rifle','smg','shotgun'];
function readGLB(file){
 const b=fs.readFileSync(file);assert.equal(b.toString('ascii',0,4),'glTF');assert.equal(b.readUInt32LE(4),2);const total=b.readUInt32LE(8);assert.equal(total,b.length);
 let off=12,json=null,bin=null;while(off<total){const len=b.readUInt32LE(off),type=b.readUInt32LE(off+4);const data=b.subarray(off+8,off+8+len);if(type===0x4e4f534a)json=JSON.parse(data.toString('utf8').replace(/\0+$/,''));if(type===0x004e4942)bin=data;off+=8+len;}assert.ok(json);assert.ok(bin);return {json,bin};
}
function imageBytes(json,bin,index){const im=json.images[index];assert.ok(im?.bufferView!==undefined);const bv=json.bufferViews[im.bufferView];return bin.subarray(bv.byteOffset||0,(bv.byteOffset||0)+bv.byteLength);}

test('all weapon GLBs are valid glTF 2.0 and WebGL1 index-safe',()=>{
 for(const name of names){const {json,bin}=readGLB(path.join(root,`client/assets/weapons/vanguard_${name}.glb`));assert.equal(json.asset.version,'2.0');assert.ok(json.meshes?.length>=4);assert.ok(json.nodes?.length>=5);assert.ok(json.buffers[0].byteLength<=bin.length);assert.ok(json.accessors.every(a=>a.componentType!==5125));}
});

test('every weapon primitive has position, normal, UV and tangent attributes',()=>{
 for(const name of names){const {json}=readGLB(path.join(root,`client/assets/weapons/vanguard_${name}.glb`));for(const mesh of json.meshes)for(const p of mesh.primitives){assert.ok(p.attributes.POSITION!==undefined);assert.ok(p.attributes.NORMAL!==undefined);assert.ok(p.attributes.TEXCOORD_0!==undefined);assert.ok(p.attributes.TANGENT!==undefined);assert.equal(p.mode,4);}}
});

test('weapon materials contain complete PBR texture set',()=>{
 for(const name of names){const {json}=readGLB(path.join(root,`client/assets/weapons/vanguard_${name}.glb`));assert.equal(json.images.length,12);assert.equal(json.textures.length,12);for(const m of json.materials){const p=m.pbrMetallicRoughness;assert.ok(p?.baseColorTexture?.index!==undefined);assert.ok(p?.metallicRoughnessTexture?.index!==undefined);assert.ok(m.normalTexture?.index!==undefined);assert.ok(p.metallicFactor>=0&&p.metallicFactor<=1);assert.ok(p.roughnessFactor>=0&&p.roughnessFactor<=1);}}
});

test('embedded textures are valid PNGs at production baseline resolution',()=>{
 for(const name of names){const {json,bin}=readGLB(path.join(root,`client/assets/weapons/vanguard_${name}.glb`));for(let i=0;i<json.images.length;i++){const bytes=imageBytes(json,bin,i);assert.equal(json.images[i].mimeType,'image/png');assert.equal(bytes.toString('ascii',1,4),'PNG');assert.equal(bytes.readUInt32BE(16),64);assert.equal(bytes.readUInt32BE(20),64);}}
});

test('client renderer is wired for tangent-space PBR shading',()=>{
 const source=fs.readFileSync(path.join(root,'client/main.mjs'),'utf8');
 for(const token of ['D_GGX','G_Smith','F_Schlick','normalTex','mrTex','tangent','locNormalScale'])assert.ok(source.includes(token),`missing renderer token ${token}`);
});
