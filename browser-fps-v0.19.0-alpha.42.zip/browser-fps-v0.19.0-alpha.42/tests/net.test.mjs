import test from 'node:test';
import assert from 'node:assert/strict';
import { sanitizeInput, makeSnapshot, NET } from '../shared/net.mjs';

test('sanitizeInput normalizes booleans and numeric camera state',()=>{
  const i=sanitizeInput({seq:7,forward:1,yaw:2.5,pitch:-2});
  assert.equal(i.seq,7); assert.equal(i.forward,true); assert.equal(i.backward,false); assert.equal(i.yaw,2.5); assert.equal(i.pitch,-2);
});
test('invalid input falls back to safe defaults',()=>{
  const i=sanitizeInput({seq:'7',yaw:'bad',pitch:null});
  assert.equal(i.seq,0); assert.equal(i.yaw,0); assert.equal(i.pitch,0); assert.equal(i.sprint,false);
});
test('snapshot contains reconciliation acknowledgement',()=>{
  const p={id:'1',team:'blue',x:1,y:0,z:2,yaw:0,pitch:0,hp:100,alive:true,ammo:30,reserve:90,reloading:false,score:0};
  const s=makeSnapshot(p,42); assert.equal(s.lastInputSeq,42); assert.equal(s.reserve,90); assert.equal(s.id,'1');
});
test('network constants are bounded for browser FPS',()=>{ assert.equal(NET.INPUT_RATE,60); assert.equal(NET.SNAPSHOT_RATE,20); assert.ok(NET.MAX_INPUT_BUFFER>=60); });

test('snapshot exposes animation telemetry without breaking reconciliation',()=>{
  const p={id:'1',team:'blue',x:1,y:0,z:2,yaw:0,pitch:0,hp:100,alive:true,ammo:30,reserve:90,reloading:false,score:0,fireSeq:3,moveX:0,moveZ:-1,speed:5.2,anim:'walk'};
  const s=makeSnapshot(p,9);
  assert.equal(s.lastInputSeq,9);
  assert.equal(s.anim,'walk');
  assert.equal(s.speed,5.2);
  assert.equal(s.moveZ,-1);
});


test('snapshot carries fire sequence for remote muzzle feedback',()=>{ const p={id:'1',team:'blue',x:0,y:0,z:0,yaw:0,pitch:0,hp:100,alive:true,money:800,weapon:'pistol',ammo:11,reserve:48,reloading:false,inventory:{},score:0,deaths:0,fireSeq:4}; const s=makeSnapshot(p,2); assert.equal(s.fireSeq,4); });


test('snapshot exposes authoritative animation phase and action telemetry',()=>{ const p={id:'1',team:'blue',x:0,y:0,z:0,yaw:0,pitch:0,hp:100,alive:true,money:800,weapon:'pistol',ammo:12,reserve:48,reloading:false,inventory:{},score:0,deaths:0,anim:'run',animTime:1.2,animCycle:2.4,action:'fire',actionTime:1.3}; const s=makeSnapshot(p,7); assert.equal(s.anim,'run'); assert.equal(s.animTime,1.2); assert.equal(s.animCycle,2.4); assert.equal(s.action,'fire'); assert.equal(s.actionTime,1.3); });

test('network security limits are bounded',()=>{
  assert.ok(NET.MAX_WS_MESSAGE_BYTES>=4096&&NET.MAX_WS_MESSAGE_BYTES<=65536);
  assert.ok(NET.MAX_MESSAGES_PER_SECOND>=60&&NET.MAX_MESSAGES_PER_SECOND<=600);
  assert.ok(NET.MAX_REWIND_SECONDS>0&&NET.MAX_REWIND_SECONDS<=.25);
});
