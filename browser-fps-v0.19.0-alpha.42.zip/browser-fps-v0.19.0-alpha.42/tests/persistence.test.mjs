import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createJsonRepository} from '../shared/persistence.mjs';

function temp(){return fs.mkdtempSync(path.join(os.tmpdir(),'vanguard-persist-'));}
function cleanup(dir){fs.rmSync(dir,{recursive:true,force:true});}

test('json repository loads, validates, and atomically persists records',()=>{
  const dir=temp();
  try{
    const file=path.join(dir,'accounts.json');
    fs.writeFileSync(file,JSON.stringify([{id:'good',value:7},{id:'bad'}]));
    const repo=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'&&Number.isInteger(v.value)});
    repo.load();
    assert.equal(repo.get('good').value,7);
    assert.equal(repo.get('bad'),null);
    repo.set({id:'next',value:9});repo.save();
    const raw=JSON.parse(fs.readFileSync(file,'utf8'));
    assert.deepEqual(raw.map(v=>v.id).sort(),['good','next']);
    assert.equal(fs.existsSync(`${file}.tmp`),false);
    assert.equal(fs.existsSync(`${file}.bak`),true);
    assert.deepEqual(JSON.parse(fs.readFileSync(`${file}.bak`,'utf8')).map(v=>v.id).sort(),['bad','good']);
  } finally {cleanup(dir);}
});

test('repository creates a previous-version backup on replacement',()=>{
  const dir=temp();
  try{
    const file=path.join(dir,'accounts.json');
    const repo=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    repo.set({id:'a',value:1});repo.save();
    repo.set({id:'b',value:2});repo.save();
    assert.deepEqual(JSON.parse(fs.readFileSync(file,'utf8')).map(x=>x.id),['a','b']);
    assert.deepEqual(JSON.parse(fs.readFileSync(`${file}.bak`,'utf8')).map(x=>x.id),['a']);
  } finally {cleanup(dir);}
});

test('corrupt primary is recovered from backup and marked dirty for repair',()=>{
  const dir=temp();
  try{
    const file=path.join(dir,'accounts.json');
    const repo=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    repo.set({id:'a',value:1});repo.save();
    repo.set({id:'b',value:2});repo.save();
    fs.writeFileSync(file,'{corrupt');
    const recovered=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    recovered.load();
    assert.equal(recovered.recoveredFromBackup,true);
    assert.equal(recovered.dirty,true);
    assert.deepEqual([...recovered.all()].map(x=>x.id),['a']);
    recovered.save();
    assert.deepEqual(JSON.parse(fs.readFileSync(file,'utf8')).map(x=>x.id),['a']);
    assert.equal(recovered.recoveredFromBackup,false);
  } finally {cleanup(dir);}
});

test('missing primary and backup initialize an empty repository',()=>{
  const dir=temp();
  try{
    const file=path.join(dir,'accounts.json');
    const repo=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    assert.deepEqual([...repo.load()],[]);
  } finally {cleanup(dir);}
});

test('recovery repair preserves the known-good backup for a second recovery',()=>{
  const dir=temp();
  try{
    const file=path.join(dir,'accounts.json');
    const repo=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    repo.set({id:'a',value:1});repo.save();
    repo.set({id:'b',value:2});repo.save();
    fs.writeFileSync(file,'{corrupt-primary');
    const recovered=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    recovered.load();
    recovered.save();
    assert.deepEqual(JSON.parse(fs.readFileSync(file,'utf8')).map(x=>x.id),['a']);
    assert.deepEqual(JSON.parse(fs.readFileSync(`${file}.bak`,'utf8')).map(x=>x.id),['a']);
    fs.writeFileSync(file,'{corrupt-again');
    const recoveredAgain=createJsonRepository(file,{validate:v=>v&&typeof v.id==='string'});
    recoveredAgain.load();
    assert.equal(recoveredAgain.recoveredFromBackup,true);
    assert.deepEqual([...recoveredAgain.all()].map(x=>x.id),['a']);
  } finally {cleanup(dir);}
});
