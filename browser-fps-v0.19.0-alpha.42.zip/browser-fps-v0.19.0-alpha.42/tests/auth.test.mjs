import test from 'node:test';
import assert from 'node:assert/strict';
import {hashToken,tokenMatches,sanitizeToken} from '../shared/auth.mjs';

test('account tokens use one-way hashes and constant-time comparison',()=>{
  const token='vanguard-test-secret';
  const hash=hashToken(token);
  assert.notEqual(hash,token);
  assert.equal(tokenMatches(token,hash),true);
  assert.equal(tokenMatches('wrong',hash),false);
  assert.equal(tokenMatches(token,hash.slice(0,-2)),false);
});

test('token input is bounded and rejects non-string credentials',()=>{
  assert.equal(sanitizeToken('abc'),'abc');
  assert.equal(sanitizeToken(null),null);
  assert.equal(sanitizeToken('x'.repeat(129)),null);
});
