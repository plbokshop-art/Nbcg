export const MAX_CASINGS=40;
export const MAX_PARTICLES=96;
export function makeCasing({x,y,z,vx,vy,vz,life=1.2,size=.028}={}){return {x,y,z,vx,vy,vz,age:0,life,size,spin:Math.random()*6.28}}
export function makeImpact({x,y,z,normal=[0,1,0],life=.28,count=6}={}){const out=[];const [nx,ny,nz]=normal;for(let i=0;i<count;i++){const a=(i/count)*Math.PI*2;const speed=.7+Math.random()*.9;out.push({x,y,z,vx:nx*speed+Math.cos(a)*.35,vy:ny*speed+Math.sin(a)*.35,vz:nz*speed+Math.sin(a*1.7)*.35,age:0,life:life*(.75+Math.random()*.5),size:.018+Math.random()*.018});}return out;}
export function stepEffects(items,dt,gravity=-9.8){for(let i=items.length-1;i>=0;i--){const p=items[i];p.age+=dt;p.vy+=gravity*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;if(p.age>=p.life)items.splice(i,1);}return items;}
export function pushLimited(list,item,max){list.push(item);if(list.length>max)list.splice(0,list.length-max);return list;}
