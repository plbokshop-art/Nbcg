const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const WEAPON_AUDIO={
 pistol:{base:190,body:0.34,tail:0.08},
 rifle:{base:105,body:0.48,tail:0.11},
 smg:{base:145,body:0.38,tail:0.09},
 shotgun:{base:72,body:0.62,tail:0.16}
};
export function createAudioSystem(env=globalThis){
 let ctx=null, master=null;
 const get=()=>{try{if(!ctx){const C=env.AudioContext||env.webkitAudioContext;if(!C)return null;ctx=new C();master=ctx.createGain();master.gain.value=.34;master.connect(ctx.destination);}if(ctx.state==='suspended')ctx.resume();return ctx;}catch{return null}};
 const noise=(duration,gain,filterType,frequency)=>{const a=get();if(!a)return;const n=a.createBufferSource();const b=a.createBuffer(1,Math.max(1,Math.floor(a.sampleRate*duration)),a.sampleRate);const d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*(1-i/d.length);n.buffer=b;const f=a.createBiquadFilter();f.type=filterType;f.frequency.value=frequency;const g=a.createGain();g.gain.setValueAtTime(Math.max(.0001,gain),a.currentTime);g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+duration);n.connect(f).connect(g).connect(master);n.start();n.stop(a.currentTime+duration)};
 const tone=(freq,duration,gain,type='sine',detune=0)=>{const a=get();if(!a)return;const o=a.createOscillator(),g=a.createGain();o.type=type;o.frequency.value=freq;o.detune.value=detune;g.gain.setValueAtTime(Math.max(.0001,gain),a.currentTime);g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+duration);o.connect(g).connect(master);o.start();o.stop(a.currentTime+duration)};
 return {
  ensure:()=>!!get(),
  shot(id='rifle'){const w=WEAPON_AUDIO[id]||WEAPON_AUDIO.rifle;tone(w.base,.055,w.body,'triangle');tone(w.base*1.85,.028,w.body*.55,'square',-7);noise(w.tail,w.body*.42,'lowpass',900);noise(.035,w.body*.16,'highpass',1800)},
  reloadStart(){tone(170,.07,.035,'square');noise(.09,.045,'bandpass',1250)},
  reloadFinish(){tone(420,.045,.04,'square');tone(690,.055,.025,'triangle');},
  dryFire(){tone(105,.055,.045,'square');noise(.035,.025,'highpass',1400)},
  hit(head=false){tone(head?1040:760,.055,.035,'sine');tone(head?1440:980,.035,.018,'triangle')},
  hurt(){tone(78,.09,.045,'sawtooth');noise(.05,.018,'bandpass',800)},
  footstep(){noise(.045,.018,'bandpass',620)},
  ui(){tone(520,.035,.018,'sine')},
  objective(type='ui'){if(type==='plantStart'){tone(260,.12,.035,'square');tone(390,.16,.028,'triangle');return;}if(type==='planted'){tone(150,.12,.05,'square');tone(220,.22,.035,'sawtooth');return;}if(type==='defuseStart'){tone(620,.09,.028,'square');tone(820,.13,.022,'triangle');return;}if(type==='defuse'){tone(520,.08,.03,'triangle');tone(760,.16,.035,'sine');return;}if(type==='detonation'){tone(58,.42,.09,'sawtooth');noise(.38,.08,'lowpass',240);return;}if(type==='deviceDrop'){tone(180,.08,.028,'square');return;}if(type==='devicePickup'){tone(480,.06,.025,'square');tone(700,.08,.018,'triangle');return;}tone(320,.05,.018,'sine');}
 };
}
