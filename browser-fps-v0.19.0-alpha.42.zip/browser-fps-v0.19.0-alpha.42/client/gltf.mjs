function align4(n){return (n+3)&~3;}
function compCount(type){return ({SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16})[type]||0;}
const TYPES={5120:[Int8Array,1],5121:[Uint8Array,1],5122:[Int16Array,2],5123:[Uint16Array,2],5125:[Uint32Array,4],5126:[Float32Array,4]};
function identity(){return [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];}
function mul4(a,b){const o=new Float32Array(16);for(let r=0;r<4;r++)for(let c=0;c<4;c++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o;}
function trs(t=[0,0,0],r=[0,0,0,1],s=[1,1,1]){const[x,y,z,w]=r;const xx=x*x,yy=y*y,zz=z*z,xy=x*y,xz=x*z,yz=y*z,wx=w*x,wy=w*y,wz=w*z;return new Float32Array([(1-2*(yy+zz))*s[0],2*(xy+wz)*s[0],2*(xz-wy)*s[0],0,2*(xy-wz)*s[1],(1-2*(xx+zz))*s[1],2*(yz+wx)*s[1],0,2*(xz+wy)*s[2],2*(yz-wx)*s[2],(1-2*(xx+yy))*s[2],0,t[0],t[1],t[2],1]);}
export async function loadGLB(url){
 const res=await fetch(url);if(!res.ok)throw new Error(`GLB ${res.status}: ${url}`);
 const ab=await res.arrayBuffer(),dv=new DataView(ab);if(dv.getUint32(0,true)!==0x46546c67)throw new Error('Invalid GLB magic');if(dv.getUint32(4,true)!==2)throw new Error('Unsupported glTF version');
 const total=dv.getUint32(8,true);if(total>ab.byteLength)throw new Error('Invalid GLB length');let off=12,json=null,bin=null;
 while(off+8<=total){const len=dv.getUint32(off,true),type=dv.getUint32(off+4,true),start=off+8,end=start+len;if(end>total)throw new Error('Invalid GLB chunk');if(type===0x4e4f534a)json=JSON.parse(new TextDecoder().decode(new Uint8Array(ab,start,len)).replace(/\0+$/,''));else if(type===0x004e4942)bin=ab.slice(start,end);off=align4(end);}
 if(!json||!bin)throw new Error('GLB missing JSON/BIN');
 const readAccessor=(idx)=>{const a=json.accessors[idx],bv=json.bufferViews[a.bufferView];const [Ctor,bpe]=TYPES[a.componentType]||[];if(!Ctor)throw new Error(`Unsupported accessor component ${a.componentType}`);const comps=compCount(a.type),stride=bv.byteStride||comps*bpe,base=(bv.byteOffset||0)+(a.byteOffset||0),count=a.count;const out=new Ctor(count*comps),src=new Ctor(bin,base,Math.floor(((count-1)*stride)/bpe)+comps);for(let i=0;i<count;i++)for(let c=0;c<comps;c++)out[i*comps+c]=src[Math.floor(i*stride/bpe)+c];return {data:out,count,components:comps,normalized:!!a.normalized};};
 const images=(json.images||[]).map(im=>{if(im.bufferView===undefined)return null;const bv=json.bufferViews[im.bufferView];return {mime:im.mimeType||'application/octet-stream',data:bin.slice(bv.byteOffset||0,(bv.byteOffset||0)+bv.byteLength)};});
 const textures=(json.textures||[]).map(t=>t.source===undefined?null:images[t.source]);
 const materials=(json.materials||[]).map(m=>{const p=m.pbrMetallicRoughness||{},bc=p.baseColorTexture?.index,mr=p.metallicRoughnessTexture?.index,nm=m.normalTexture?.index;return {name:m.name||'material',baseColor:p.baseColorFactor||[1,1,1,1],metallic:p.metallicFactor??1,roughness:p.roughnessFactor??1,texture:bc===undefined?null:textures[bc],metallicRoughnessTexture:mr===undefined?null:textures[mr],normalTexture:nm===undefined?null:textures[nm],normalScale:m.normalTexture?.scale??1};});
 const meshes=(json.meshes||[]).map(mesh=>({name:mesh.name||'mesh',primitives:(mesh.primitives||[]).map(p=>{const attrs={};for(const[name,idx]of Object.entries(p.attributes))attrs[name]=readAccessor(idx);return {position:attrs.POSITION,normal:attrs.NORMAL||null,uv:attrs.TEXCOORD_0||null,tangent:attrs.TANGENT||null,index:p.indices!==undefined?readAccessor(p.indices):null,material:materials[p.material||0]||{baseColor:[1,1,1,1],metallic:0,roughness:1,texture:null,metallicRoughnessTexture:null,normalTexture:null}};})}));
 const nodes=(json.nodes||[]).map(n=>({mesh:n.mesh,children:n.children||[],matrix:n.matrix?new Float32Array(n.matrix):trs(n.translation,n.rotation,n.scale)}));
 const roots=(json.scenes?.[json.scene??0]?.nodes||[]);const instances=[];function visit(i,parent){const n=nodes[i],world=mul4(parent,n.matrix);if(n.mesh!==undefined)instances.push({mesh:n.mesh,matrix:world});for(const c of n.children)visit(c,world);}for(const r of roots)visit(r,new Float32Array(identity()));
 if(!instances.length)for(let i=0;i<meshes.length;i++)instances.push({mesh:i,matrix:new Float32Array(identity())});
 return {json,meshes,materials,images,instances};
}
export async function decodeGLTFTexture(image){if(!image)return null;const blob=new Blob([image.data],{type:image.mime});return await createImageBitmap(blob);}
