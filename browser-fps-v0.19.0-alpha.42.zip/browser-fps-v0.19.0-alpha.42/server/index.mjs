import http from 'node:http';import crypto from 'node:crypto';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {TICK_RATE,DT,makePlayer,applyMovement,updateReload,tryFire,resetPlayer,buyWeapon,buyGrenade,equipWeapon,detonateGrenade,aimDirection,WEAPONS,GRENADES,WORLD} from '../shared/game.mjs';
import {MAP,spawnPoints,isSpawnSafe,pointBlocked} from '../shared/map.mjs';
import {NET,sanitizeInput,makeSnapshot} from '../shared/net.mjs';
import {ROUND_PHASES,ROUND_TIMES,createRoundState,aliveTeams,resolveRoundWinner,nextPhase} from '../shared/round.mjs';
import {OBJECTIVE,objectiveState,siteAt,startPlant,cancelPlant,completePlant,startDefuse,cancelDefuse,resolveObjective,objectiveWinner,dropDevice,pickupDevice} from '../shared/objective.mjs';
import {walletCredit,ensureWallet} from '../shared/economy.mjs';
import {ensureInventory,consumeGrenade,inventorySnapshot} from '../shared/inventory.mjs';
import {makeAccount,publicAccount,normalizeDisplayName,recordAccountEvent,recordMatchHistory,hasSettlement} from '../shared/account.mjs';
import {AC,ensureAntiCheat,inspectInput,recordActionViolation} from '../shared/anticheat.mjs';
import {createPerformanceMetrics,recordTick,recordSnapshot,recordOutbound,performanceSnapshot} from '../shared/performance.mjs';
import {hashToken,tokenMatches,sanitizeToken} from '../shared/auth.mjs';
import {createJsonRepository} from '../shared/persistence.mjs';
import {createMatchmaker,validateTeamBalance,MATCHMAKING} from '../shared/matchmaking.mjs';
import {buildLeaderboard,buildIntegrityReport,applyCompetitiveRatings,integrityAdjustment,detectCompetitiveAbuse,recordCompetitiveIntegrity} from '../shared/competitive.mjs';
import {settlementKey,createSettlementGuard,settlementRecord,validateSettlementRecord} from '../shared/settlement.mjs';
import {acquireInstanceLock} from '../shared/instance-lock.mjs';
import {buildRecoverySnapshot,recoveryRecord,verifyRecoveryRecord,RECOVERY_MAX_BYTES} from '../shared/recovery.mjs';

const PERF_METRICS=createPerformanceMetrics();
let accountsDirty=false;
const ROOT=path.dirname(fileURLToPath(import.meta.url)),PROJECT_ROOT=path.resolve(ROOT,'..'),CLIENT_ROOT=path.join(PROJECT_ROOT,'client'),SHARED_ROOT=path.join(PROJECT_ROOT,'shared');
const NODE_ENV=process.env.NODE_ENV||'development';
const parsedPort=Number(process.env.PORT||8081);
if(!Number.isInteger(parsedPort)||parsedPort<1||parsedPort>65535)throw new Error('Invalid PORT');
const PORT=parsedPort;
const METRICS_TOKEN=typeof process.env.VANGUARD_METRICS_TOKEN==='string'&&process.env.VANGUARD_METRICS_TOKEN.length>=16?process.env.VANGUARD_METRICS_TOKEN:null;
let ready=false,shuttingDown=false;
const players=new Map(),sockets=new Map(),sessions=new Map(),grenades=new Map(),smokeZones=new Map();
const configuredTargetScore=Number(process.env.VANGUARD_TARGET_SCORE);
const matchmaker=createMatchmaker(Number.isInteger(configuredTargetScore)&&configuredTargetScore>0?{targetScore:Math.min(configuredTargetScore,99)}:{});
let activeMatch=null;
const DATA_ROOT=process.env.VANGUARD_DATA_DIR?path.resolve(process.env.VANGUARD_DATA_DIR):path.join(PROJECT_ROOT,'data');
let instanceLock;
try{instanceLock=acquireInstanceLock(DATA_ROOT);}catch(err){console.error(`[startup-lock] ${err.message}`);process.exit(1);}
const ACCOUNTS_FILE=path.join(DATA_ROOT,'accounts.json');
const accountRepo=createJsonRepository(ACCOUNTS_FILE,{validate:a=>a&&typeof a.id==='string'&&typeof a.tokenHash==='string'&&a.stats&&Array.isArray(a.history)});
const SETTLEMENTS_FILE=path.join(DATA_ROOT,'settlements.json');
const settlementRepo=createJsonRepository(SETTLEMENTS_FILE,{validate:validateSettlementRecord});
const settlementRecords=settlementRepo.load();
const settlementGuard=createSettlementGuard([...settlementRecords.values()].filter(r=>r.status==='COMPLETED').map(r=>r.id));
const accounts=accountRepo.load();
const RECOVERY_FILE=path.join(DATA_ROOT,'active-match.json');
const recoveryRepo=createJsonRepository(RECOVERY_FILE,{validate:r=>verifyRecoveryRecord(r)});
const recoveredRecords=recoveryRepo.load();
function saveAccounts(){if(!accountsDirty&&!accountRepo.dirty)return;for(const a of accounts.values())accountRepo.set(a);accountRepo.save();accountsDirty=false;}
function saveRecovery(){if(!activeMatch)return;const snap=buildRecoverySnapshot({activeMatch,phase,phaseEnds,round,score,gameTime,players,grenades,smokeZones,objective});if(!snap)return;const record=recoveryRecord(snap);if(Buffer.byteLength(JSON.stringify(record))>RECOVERY_MAX_BYTES)throw new Error('recovery snapshot too large');recoveryRepo.set(record);recoveryRepo.save();}
function clearRecovery(){if(recoveryRepo.delete('active')){recoveryRepo.save();try{fs.unlinkSync(RECOVERY_FILE);}catch{}}}
function persistSettlement(record){settlementRepo.set(record);settlementRepo.save();}
function completeSettlement(key){const r=settlementRepo.get(key);if(r&&r.status!=='COMPLETED'){r.status='COMPLETED';r.updatedAt=Date.now();settlementRepo.set(r);settlementRepo.save();}}
function reconcilePreparedSettlements(){
  let changed=false;
  for(const record of settlementRepo.all()){
    if(record.status!=='PREPARED')continue;
    if(activeMatch?.id===record.matchId)continue;
    const result=record.result||{};
    for(const jp of record.participants){
      const a=accounts.get(jp.accountId);
      if(!a)continue;
      a.rating=Math.max(100,Math.min(5000,Math.round(Number(jp.ratingAfter)||1000)));
      if(!settlementIntegrityApplied(a,record.id))recordCompetitiveIntegrity(a,{settlementId:record.id,score:Number(jp.integrityScore)||0,reasons:Array.isArray(jp.integrityReasons)?jp.integrityReasons:[]});
      const eventMeta={matchId:record.matchId,result,settlementId:record.id};
      if(!settlementEventExists(a,record.id,'matchPlayed'))recordAccountEvent(a,{type:'matchPlayed',meta:eventMeta});
      if(result.winner===jp.team&&!settlementEventExists(a,record.id,'matchWon'))recordAccountEvent(a,{type:'matchWon',meta:eventMeta});
      if(jp.abandoned&&!settlementEventExists(a,record.id,'matchAbandoned'))recordAccountEvent(a,{type:'matchAbandoned',meta:eventMeta});
      if(!hasSettlement(a,record.id))recordMatchHistory(a,{matchId:record.matchId,settlementId:record.id,at:record.updatedAt,result:result?.winner===null?'draw':result?.winner===jp.team?'win':'loss',winner:result?.winner??null,score:{...(result.score||{blue:0,red:0})},ratingBefore:jp.ratingBefore,ratingAfter:jp.ratingAfter,ratingK:jp.ratingK??32,abandoned:!!jp.abandoned,opponents:jp.opponents||[]});
      changed=true;
    }
    record.status='COMPLETED';record.updatedAt=Date.now();settlementRepo.set(record);
  }
  if(changed){accountsDirty=true;saveAccounts();settlementRepo.save();}
}
function markAccountsDirty(){accountsDirty=true;}
function accountByToken(t){for(const a of accountRepo.all())if(tokenMatches(t,a.tokenHash))return a;return null;}
function newAccount(){const id='acct_'+randomBytes(9).toString('base64url');const token=randomBytes(32).toString('base64url');const a=makeAccount(id,`Vanguard-${id.slice(-4)}`);a.tokenHash=hashToken(token);accountRepo.set(a);accountsDirty=true;return {account:a,token};}
let nextId=1,gameTime=0;let objective=objectiveState({round:1});const roundState=createRoundState();let {phase,phaseEnds,round,score}=roundState;let roundWinner=null;
const ROUND_RUNTIME={buy:Number.isFinite(Number(process.env.VANGUARD_BUY_SECONDS))&&Number(process.env.VANGUARD_BUY_SECONDS)>0?Number(process.env.VANGUARD_BUY_SECONDS):ROUND_TIMES.buy,live:Number.isFinite(Number(process.env.VANGUARD_LIVE_SECONDS))&&Number(process.env.VANGUARD_LIVE_SECONDS)>0?Number(process.env.VANGUARD_LIVE_SECONDS):ROUND_TIMES.live,post:Number.isFinite(Number(process.env.VANGUARD_POST_SECONDS))&&Number(process.env.VANGUARD_POST_SECONDS)>0?Number(process.env.VANGUARD_POST_SECONDS):ROUND_TIMES.post};phaseEnds=ROUND_RUNTIME.buy;
const RECOVERY_RECONNECT_GRACE_SECONDS=Number(process.env.VANGUARD_RECOVERY_RECONNECT_GRACE_SECONDS)>0?Number(process.env.VANGUARD_RECOVERY_RECONNECT_GRACE_SECONDS):120;
const HISTORY_SECONDS=NET.MAX_REWIND_SECONDS+.10,HISTORY_MAX=32,MAX_WS_BUFFER=NET.MAX_WS_MESSAGE_BYTES*2,MAX_GRENADE_ENTITIES=32,GRENADE_SPEED=13,GRENADE_GRAVITY=16,RECONNECT_GRACE_SECONDS=Number(process.env.VANGUARD_RECONNECT_GRACE_SECONDS)>0?Number(process.env.VANGUARD_RECONNECT_GRACE_SECONDS):15;
function recordHistory(p){if(!p._history)p._history=[];p._history.push({t:gameTime,x:p.x,y:p.y,z:p.z,yaw:p.yaw,pitch:p.pitch,crouched:p.crouched,alive:p.alive,team:p.team});while(p._history.length>HISTORY_MAX||gameTime-p._history[0].t>HISTORY_SECONDS)p._history.shift();}
function historicalState(p,targetTime){const h=p._history||[];if(!h.length)return null;if(targetTime<=h[0].t)return {...h[0]};if(targetTime>=h[h.length-1].t)return {...h[h.length-1]};let i=1;while(i<h.length&&h[i].t<targetTime)i++;const a=h[i-1],b=h[i],f=(targetTime-a.t)/Math.max(.000001,b.t-a.t);return {...a,x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,z:a.z+(b.z-a.z)*f,yaw:a.yaw+(b.yaw-a.yaw)*f,pitch:a.pitch+(b.pitch-a.pitch)*f};}
function rewindPlayers(shooter){const rewind=Math.min(NET.MAX_REWIND_SECONDS,Math.max(0,(shooter._rttMs||0)/2000));if(rewind<=0)return null;const targetTime=gameTime-rewind;const map=new Map();for(const p of players.values()){const h=historicalState(p,targetTime);if(h)map.set(p.id,h);}return map;}
function noteMessage(p){const now=Date.now();if(now-p._msgWindowStart>=1000){p._msgWindowStart=now;p._msgCount=0;}p._msgCount++;return p._msgCount<=NET.MAX_MESSAGES_PER_SECOND;}
function freshActionSeq(p,seq){if(!Number.isInteger(seq)||seq<=0||seq<=p._lastActionSeq)return false;p._lastActionSeq=seq;return true;}
function accountSnapshot(p){const a=p?.accountId?accountRepo.get(p.accountId):null;return a?publicAccount(a):null;}
function json(res,c,b,extra={}){res.writeHead(c,{'Content-Type':'application/json; charset=utf-8','X-Content-Type-Options':'nosniff','Cache-Control':'no-store',...extra});res.end(JSON.stringify(b));}
function metricsAuthorized(req){if(NODE_ENV!=='production')return true;if(!METRICS_TOKEN)return false;const bearer=String(req.headers.authorization||'');return bearer===`Bearer ${METRICS_TOKEN}`||req.headers['x-metrics-token']===METRICS_TOKEN;}
function shutdown(){if(shuttingDown)return;shuttingDown=true;ready=false;try{saveRecovery();}catch(err){console.error('[recovery-save]',err);} for(const ws of sockets.values()){ws.open=false;try{ws.socket.end();}catch{}}saveAccounts();server.close(()=>{try{instanceLock?.release();}catch(err){console.error('[startup-lock-release]',err);}process.exit(0);});setTimeout(()=>process.exit(1),5000).unref();}function send(ws,o){if(!ws.open)return;const text=typeof o==='string'?o:JSON.stringify(o);ws.send(text);recordOutbound(PERF_METRICS,Buffer.byteLength(text));}function snapshot(){return[...players.values()].filter(p=>p.status!=='DISCONNECTED').map(p=>makeSnapshot(p,p.lastInputSeq||0));}function broadcast(o){const text=typeof o==='string'?o:JSON.stringify(o);for(const ws of sockets.values())send(ws,text);}
function broadcastState(){const started=process.hrtime.bigint();const payload={type:'state',time:gameTime,phase,phaseEnds,round,score,objective,players:snapshot(),grenades:[...grenades.values()].map(g=>({id:g.id,type:g.type,x:g.x,y:g.y,z:g.z,vx:g.vx,vy:g.vy,vz:g.vz,detonateAt:g.detonateAt})),smokes:[...smokeZones.values()].map(s=>({id:s.id,x:s.x,y:s.y,z:s.z,radius:s.radius,expiresAt:s.expiresAt}))};const text=JSON.stringify(payload);recordSnapshot(PERF_METRICS,Number(process.hrtime.bigint()-started)/1e6,Buffer.byteLength(text));broadcast(text);}
function frame(data){const b=Buffer.from(data);if(b.length<2)return null;const b0=b[0],b1=b[1],fin=(b0&128)!==0,opcode=b0&15,masked=(b1&128)!==0;if(!fin||!masked)return null;let len=b1&127,i=2;if(len===126){if(b.length<4)return null;len=b.readUInt16BE(i);i+=2;}else if(len===127){if(b.length<10)return null;const n=b.readBigUInt64BE(i);if(n>BigInt(NET.MAX_WS_MESSAGE_BYTES))return null;len=Number(n);i+=8;}if(len>NET.MAX_WS_MESSAGE_BYTES)return null;const mask=masked?b.subarray(i,i+4):null;i+=masked?4:0;if(b.length<i+len)return null;let payload=b.subarray(i,i+len);if(mask){payload=Buffer.from(payload);for(let j=0;j<len;j++)payload[j]^=mask[j%4];}return{opcode,payload,next:i+len};}
function wsFrame(text){const p=Buffer.from(text);let h;if(p.length<126)h=Buffer.from([129,p.length]);else if(p.length<65536){h=Buffer.alloc(4);h[0]=129;h[1]=126;h.writeUInt16BE(p.length,2);}else{h=Buffer.alloc(10);h[0]=129;h[1]=127;h.writeBigUInt64BE(BigInt(p.length),2);}return Buffer.concat([h,p]);}
function wsControlFrame(opcode,payload=Buffer.alloc(0)){const p=Buffer.from(payload);if(p.length>=126)throw Error('control frame too large');return Buffer.concat([Buffer.from([128|opcode,p.length]),p]);}
function pickSpawn(team,index=0){const list=spawnPoints(team);for(let i=0;i<list.length;i++){const s=list[(index+i)%list.length];if(isSpawnSafe(s.x,s.z))return s;}return team==='blue'?{x:-18,z:0}:{x:18,z:0};}
function clearGrenades(){grenades.clear();smokeZones.clear();}
function matchPlayer(p){return activeMatch?.players.find(x=>x.accountId===p.accountId)||null;}
function matchParticipants(){if(!activeMatch)return [];return [...players.values()].filter(p=>!!matchPlayer(p));}
function activeMatchPlayerState(slot){return players.get(slot.playerId)||{id:slot.playerId,accountId:slot.accountId,team:slot.team,status:'DISCONNECTED',alive:false,abandoned:false};}
function formQueuedMatch(){if(activeMatch)return null;const m=matchmaker.popReady(Date.now());if(!m)return null;if(!validateTeamBalance(m.players,m.teamSize)){matchmaker.completeMatch(m.id,'invalid');return null;}activeMatch=m;round=1;score={blue:0,red:0};roundWinner=null;objective=objectiveState({round});clearGrenades();phase=ROUND_PHASES.BUY;phaseEnds=gameTime+ROUND_RUNTIME.buy;objective=objectiveState({round});for(const p of players.values()){const slot=matchPlayer(p);if(slot){slot.playerId=p.id;slot.abandoned=false;p.matchId=m.id;p.team=slot.team;p.status='ALIVE';p.alive=true;p.round=round;}else{p.matchId=null;p.status='SPECTATOR';p.alive=false;}}m.status='READY';broadcast({type:'matchFound',matchId:m.id,targetScore:m.targetScore,teams:{blue:m.players.filter(x=>x.team==='blue').map(x=>x.accountId),red:m.players.filter(x=>x.team==='red').map(x=>x.accountId)}});for(const p of matchParticipants()){const spawn=pickSpawn(p.team,Number(p.id));resetPlayer(p,spawn.x,spawn.z);p.spawn={x:spawn.x,z:spawn.z};p.round=round;}const firstAttacker=matchParticipants().find(p=>p.team===objective.attacker);if(firstAttacker)objective.carrierId=firstAttacker.id;broadcast({type:'round',round,phase,endsAt:phaseEnds,score,map:MAP.name,winner:null});return m;}
function settlementEventExists(account,settlementId,type){return !!account&&Array.isArray(account.history)&&account.history.some(e=>e?.type===type&&e?.meta?.settlementId===settlementId);}
function settlementIntegrityApplied(account,settlementId){return !!account?.competitiveIntegrity?.flags?.some(f=>f?.settlementId===settlementId);}
function prepareSettlement(finished,result,settlement){
  const existing=settlementRepo.get(settlement);
  if(existing?.status==='PREPARED')return existing;
  const ratingPlayers=finished.players.map(x=>({accountId:x.accountId,team:x.team,rating:Number(accounts.get(x.accountId)?.rating)||1000,abandoned:!!x.abandoned}));
  const ratingBefore=new Map(ratingPlayers.map(x=>[x.accountId,x.rating]));
  applyCompetitiveRatings(ratingPlayers,accounts,result?.winner??null);
  const participants=ratingPlayers.map(rp=>{
    const a=accounts.get(rp.accountId);
    const opponents=finished.players.filter(x=>x.team!==rp.team).map(x=>x.accountId);
    const opponentRatings=finished.players.filter(x=>x.team!==rp.team).map(x=>Number(accounts.get(x.accountId)?.rating)||1000);
    const signal=detectCompetitiveAbuse(a,{opponents,opponentRatings,winner:result?.winner===rp.team,abandoned:!!rp.abandoned});
    return {accountId:rp.accountId,team:rp.team,ratingBefore:ratingBefore.get(rp.accountId)||1000,ratingAfter:Math.max(100,Math.min(5000,Math.round(rp.rating+integrityAdjustment(rp)))),ratingK:rp.ratingK??32,integrityScore:signal.score,integrityReasons:signal.reasons,opponents};
  });
  const journal=settlementRecord(settlement,{matchId:finished.id,result,status:'PREPARED',participants});
  persistSettlement(journal);
  return journal;
}
function commitSettlement(finished,result,settlement,journal,participants){
  for(const p of participants){
    const a=accounts.get(p.accountId); if(!a)continue;
    const jp=journal.participants.find(x=>x.accountId===p.accountId);
    if(jp)a.rating=Math.max(100,Math.min(5000,Math.round(Number(jp.ratingAfter)||1000)));
    if(!settlementIntegrityApplied(a,settlement)){
      const signal={settlementId:settlement,score:Number(jp?.integrityScore)||0,reasons:Array.isArray(jp?.integrityReasons)?jp.integrityReasons:[]};
      recordCompetitiveIntegrity(a,signal);
    }
    const opponents=Array.isArray(jp?.opponents)&&jp.opponents.length?jp.opponents:finished.players.filter(x=>x.team!==p.team).map(x=>x.accountId);
    const eventMeta={matchId:finished.id,result,settlementId:settlement};
    if(!settlementEventExists(a,settlement,'matchPlayed'))recordAccountEvent(a,{type:'matchPlayed',meta:eventMeta});
    if(result&&result.winner===p.team&&!settlementEventExists(a,settlement,'matchWon'))recordAccountEvent(a,{type:'matchWon',meta:eventMeta});
    if(p.abandoned&&!settlementEventExists(a,settlement,'matchAbandoned'))recordAccountEvent(a,{type:'matchAbandoned',meta:eventMeta});
    if(!hasSettlement(a,settlement))recordMatchHistory(a,{matchId:finished.id,settlementId:settlement,at:Date.now(),result:result?.winner===null?'draw':result?.winner===p.team?'win':'loss',winner:result?.winner??null,score:{...finished.score},ratingBefore:jp?.ratingBefore,ratingAfter:jp?.ratingAfter,ratingK:jp?.ratingK??32,abandoned:!!p.abandoned,opponents});
  }
  markAccountsDirty();saveAccounts();completeSettlement(settlement);settlementGuard.mark(settlement);
}
function finishMatch(result){
  if(!activeMatch)return false;
  const settlement=settlementKey(activeMatch.id,result);
  const existing=settlementRepo.get(settlement);
  if(existing?.status==='COMPLETED'){settlementGuard.mark(settlement);return false;}
  const finished=activeMatch;
  finished.settlementId=settlement;
  finished.status='COMPLETED';
  finished.result=result;
  const journal=prepareSettlement(finished,result,settlement);
  const participants=finished.players.map(activeMatchPlayerState);
  commitSettlement(finished,journal.result||result,settlement,journal,participants);
  for(const p of participants){p.matchId=null;p.status='SPECTATOR';p.alive=false;p._roundReady=false;}
  matchmaker.completeMatch(finished.id,'completed');
  activeMatch=null;clearGrenades();clearRecovery();phase='LOBBY';phaseEnds=Number.POSITIVE_INFINITY;roundWinner=null;
  for(const p of participants){const ws=sockets.get(p.id);if(ws)send(ws,{type:'matchEnd',matchId:finished.id,settlementId:finished.settlementId,result:journal.result||result,account:accountSnapshot(p)});}
  broadcast({type:'lobby'});return true;
}
function syncRoundState(next){phase=next.phase;phaseEnds=next.phaseEnds;round=next.round;roundWinner=next.winner??null;}
function startRound(){if(!activeMatch)return false;clearGrenades();objective=objectiveState({round});const firstAttacker=matchParticipants().find(p=>p.team===objective.attacker);if(firstAttacker)objective.carrierId=firstAttacker.id;syncRoundState(nextPhase({phase:ROUND_PHASES.POST,round,phaseEnds,score},gameTime,null,ROUND_RUNTIME));const teamSlots={blue:0,red:0};for(const p of players.values()){const inMatch=!!matchPlayer(p);if(activeMatch&&!inMatch){p.status='SPECTATOR';p.alive=false;continue;}if(p.status==='SPECTATOR'){p.status='ALIVE';p.alive=true;}else if(p.status==='DISCONNECTED'){p.status='DISCONNECTED';p.alive=false;p._roundReady=true;}const spawn=pickSpawn(p.team,teamSlots[p.team]++);resetPlayer(p,spawn.x,spawn.z);p.spawn={x:spawn.x,z:spawn.z};p.round=round;}broadcast({type:'round',round,phase,endsAt:phaseEnds,score,map:MAP.name,winner:null});}
function beginLive(){syncRoundState(nextPhase({phase:ROUND_PHASES.BUY,round,phaseEnds,score},gameTime,null,ROUND_RUNTIME));for(const p of players.values())if((!activeMatch||matchPlayer(p))&&p.status!=='SPECTATOR'){p.alive=true;p.status='ALIVE';}
if(activeMatch){activeMatch.status='LIVE';broadcast({type:'matchStart',matchId:activeMatch.id,round,score});}broadcast({type:'round',round,phase,endsAt:phaseEnds,score});}
function rewardRoundParticipants(winner){for(const p of players.values()){if(p.status==='SPECTATOR'||p.status==='DISCONNECTED'&&p.abandoned)continue;const a=accounts.get(p.accountId);if(!a)continue;recordAccountEvent(a,{type:'roundPlayed'});if(winner&&winner===p.team)recordAccountEvent(a,{type:'roundWon'});ensureWallet(p);walletCredit(p,winner&&winner===p.team?3200:1400,{id:`round:${round}:reward:${p.id}`,reason:'ROUND_REWARD',item:winner||'draw'});}markAccountsDirty();saveAccounts();}
function finishRound(winner){if(phase!==ROUND_PHASES.LIVE||!activeMatch)return false;roundWinner=winner;if(winner&&score[winner]!==undefined)score[winner]++;activeMatch.score={...score};rewardRoundParticipants(winner);if((winner&&score[winner]>=activeMatch.targetScore)||score.blue>=activeMatch.targetScore||score.red>=activeMatch.targetScore){finishMatch({winner,score:{...score},round});return true;}syncRoundState(nextPhase({phase:ROUND_PHASES.LIVE,round,phaseEnds,score},gameTime,winner,ROUND_RUNTIME));broadcast({type:'round',round,phase,winner,endsAt:phaseEnds,score});return true;}
function launchGrenade(p,type){
 const g=GRENADES[type];if(!g||grenades.size>=MAX_GRENADE_ENTITIES)return false;
 const dir=aimDirection(p.yaw,p.pitch);const id=`${p.id}:${p.fireSeq||0}:${gameTime.toFixed(4)}`;
 grenades.set(id,{id,owner:p.id,type,x:p.x,y:p.y+(p.crouched?.95:1.25),z:p.z,vx:dir.x*GRENADE_SPEED,vy:dir.y*GRENADE_SPEED,vz:dir.z*GRENADE_SPEED,spawnAt:gameTime,detonateAt:gameTime+g.fuse});
 broadcast({type:'event',event:{type:'grenadeSpawn',id,owner:p.id,grenade:type,x:p.x,y:p.y+(p.crouched?.95:1.25),z:p.z,vx:dir.x*GRENADE_SPEED,vy:dir.y*GRENADE_SPEED,vz:dir.z*GRENADE_SPEED,detonateAt:gameTime+g.fuse,time:gameTime}});return true;
}
function stepGrenades(){
 for(const [id,g] of grenades){
  const dt=DT;
  const nx=g.x+g.vx*dt,nz=g.z+g.vz*dt;
  if(pointBlocked(nx,g.z,.12)){g.vx*=-.48;g.vx*=.82;}else g.x=nx;
  if(pointBlocked(g.x,nz,.12)){g.vz*=-.48;g.vz*=.82;}else g.z=nz;
  g.vy-=GRENADE_GRAVITY*dt;g.y+=g.vy*dt;
  if(g.y<=.12){g.y=.12;g.vy=Math.abs(g.vy)*.42;g.vx*=.82;g.vz*=.82;if(Math.hypot(g.vx,g.vz)<1.0)g.vx=g.vz=0;}
  if(gameTime>=g.detonateAt){
   const owner=players.get(g.owner);
   if(owner){
    for(const ev of detonateGrenade(owner,g.type,players,{x:g.x,y:g.y,z:g.z},{smokeZones:[...smokeZones.values()]})){
     broadcast({type:'event',event:{...ev,grenade:g.type,position:{x:g.x,y:g.y,z:g.z},time:gameTime}});
     if(ev.type==='grenadeKill')broadcast({type:'death',victim:ev.target,killer:owner.id,weapon:g.type,headshot:false,round,time:gameTime});
    }
    if(g.type==='smoke'){
     const cfg=GRENADES.smoke,sid=`smoke:${id}`;
     smokeZones.set(sid,{id:sid,x:g.x,y:g.y,z:g.z,radius:cfg.radius,expiresAt:gameTime+cfg.life});
     broadcast({type:'event',event:{type:'smokeDeploy',id:sid,x:g.x,y:g.y,z:g.z,radius:cfg.radius,expiresAt:gameTime+cfg.life,time:gameTime}});
    }
    const winner=resolveRoundWinner(players,{includeDisconnected:!!activeMatch});
    if(winner!==null)finishRound(winner==='draw'?null:winner);
   }
   broadcast({type:'event',event:{type:'grenadeExplode',id,grenade:g.type,x:g.x,y:g.y,z:g.z,time:gameTime}});
   grenades.delete(id);
  }
 }
 for(const [sid,s] of smokeZones){
  if(gameTime>=s.expiresAt){smokeZones.delete(sid);broadcast({type:'event',event:{type:'smokeExpire',id:sid,time:gameTime}});}
 }
}

function staticTarget(pathname){let decoded;try{decoded=decodeURIComponent(pathname);}catch{return null;}if(decoded.includes('\0'))return null;const normalized=path.posix.normalize(decoded);if(normalized==='/'||normalized==='.')return path.join(CLIENT_ROOT,'index.html');if(normalized.split('/').includes('..'))return null;const root=normalized.startsWith('/shared/')?SHARED_ROOT:CLIENT_ROOT;const rel=normalized.startsWith('/shared/')?normalized.slice('/shared/'.length):normalized.replace(/^\/+/, '');const target=path.resolve(root,rel);const rootResolved=path.resolve(root);if(target!==rootResolved&&!target.startsWith(rootResolved+path.sep))return null;return target;}
const MIME={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.glb':'model/gltf-binary','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.ico':'image/x-icon'};
const server=http.createServer((req,res)=>{const url=new URL(req.url,'http://localhost');if(url.pathname==='/health')return json(res,200,{ok:true,ready,shuttingDown,players:players.size,tickRate:TICK_RATE,phase,round,score});if(url.pathname==='/ready')return json(res,ready&&!shuttingDown?200:503,{ok:ready&&!shuttingDown,ready,shuttingDown});if(url.pathname==='/api/leaderboard'){const limit=Math.min(100,Math.max(1,Number(url.searchParams.get('limit')||50)));return json(res,200,{ok:true,leaderboard:buildLeaderboard(accounts.values(),limit)});}if(url.pathname==='/metrics'){if(!metricsAuthorized(req))return json(res,NODE_ENV==='production'&&!METRICS_TOKEN?404:401,{error:'unauthorized'});return json(res,200,{ok:true,players:players.size,performance:performanceSnapshot(PERF_METRICS),competitiveIntegrity:buildIntegrityReport(accounts.values(),50)});}if(url.pathname==='/api/state'){if(NODE_ENV==='production')return json(res,404,{error:'not found'});return json(res,200,{world:WORLD,phase,round,score,players:snapshot()});}const full=staticTarget(url.pathname);if(!full)return json(res,400,{error:'invalid path'});fs.stat(full,(statErr,st)=>{if(statErr||!st.isFile())return json(res,404,{error:'not found'});fs.readFile(full,(err,data)=>{if(err)return json(res,404,{error:'not found'});const type=MIME[path.extname(full).toLowerCase()]||'application/octet-stream';res.writeHead(200,{'Content-Type':type,'X-Content-Type-Options':'nosniff','Cache-Control':'no-cache'});res.end(data);});});});
server.on('upgrade',(req,socket)=>{
 if(req.headers.upgrade?.toLowerCase()!=='websocket')return socket.destroy();
 const key=req.headers['sec-websocket-key'];if(!key)return socket.destroy();
 const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
 const query=new URL(req.url,'http://localhost').searchParams;const requestedToken=query.get('resume');
 let p=requestedToken?sessions.get(requestedToken):null;
 const nowMs=Date.now();const isResume=!!p && !p._socket && ((p._recoveryUntil&&nowMs<=p._recoveryUntil)||(p._disconnectedAt&&nowMs-p._disconnectedAt<=RECONNECT_GRACE_SECONDS*1000));
 if(p && !p._disconnectedAt && p._socket)return socket.destroy();
 if(!isResume)p=null;
 const id=p?.id||String(nextId++),team=p?.team||(Number(id)%2?'blue':'red'),spawn=p?.spawn||pickSpawn(team,Number(id));
 if(!p){p=makePlayer(id,spawn.x,spawn.z,team);if(phase!==ROUND_PHASES.BUY){p.alive=false;p.status='SPECTATOR';p.spawn={x:spawn.x,z:spawn.z};}p._input=sanitizeInput({yaw:p.yaw});p._inputQueue=[];p.lastInputSeq=0;p._lastSnapshotAt=0;p._fire=false;p._reload=false;p._history=[];p._rttMs=0;p._pingSentAt=0;p._pingNonce=0;p._pingLastAt=0;p._msgWindowStart=Date.now();p._msgCount=0;p._lastActionSeq=0;p._lastGrenadeAt=-999;ensureAntiCheat(p);p.wallet={balance:p.money,version:0,ledger:[]};p._disconnectedAt=0;p._preDisconnectAlive=p.alive;p._preDisconnectStatus=p.status;p._connection=null;p._authenticated=false;p.accountId=null;p.accountToken=null;p.sessionToken=crypto.randomBytes(32).toString('base64url');players.set(id,p);sessions.set(p.sessionToken,p);recordHistory(p);}
 else {p._authenticated=true;p._disconnectedAt=0;p._recoveryUntil=0;p._connection=null;const sameRound=p.round===round;if(sameRound&&p._roundReady){p.alive=true;p.status='ALIVE';p._roundReady=false;}else if(sameRound){p.alive=p._preDisconnectAlive;p.status=p._preDisconnectStatus;}else if(phase!==ROUND_PHASES.BUY){p.alive=false;p.status='SPECTATOR';}}
 const old=sockets.get(id);if(old&&old!==p._socket){old.open=false;try{old.socket.destroy();}catch{}}
 const ws={socket,open:true,send(t){if(ws.open&&!socket.destroyed)socket.write(wsFrame(t));}};p._socket=ws;sockets.set(id,ws);
 send(ws,{type:'welcome',id,player:makeSnapshot(p),sessionToken:p.sessionToken,account:accountSnapshot(p),authRequired:!p._authenticated,resumed:isResume,world:WORLD,map:MAP,phase,round,score,matchId:p.matchId||null,weapons:WEAPONS,grenades:GRENADES});
 broadcast({type:isResume?'reconnect':'join',id,players:snapshot()});
 let buf=Buffer.alloc(0);
 socket.on('data',chunk=>{buf=Buffer.concat([buf,chunk]);if(buf.length>MAX_WS_BUFFER){socket.destroy();return;}while(true){const f=frame(buf);if(!f)break;buf=buf.subarray(f.next);if(f.opcode===8){socket.end();break;}if(f.opcode===9){if(!socket.destroyed)socket.write(wsControlFrame(10,f.payload));continue;}if(f.opcode===10)continue;if(f.opcode===1){try{if(!noteMessage(p)){socket.destroy();return;}const msg=JSON.parse(f.payload.toString());if(!msg||typeof msg!=='object'||Array.isArray(msg))continue;if(msg.pong===p._pingNonce&&p._pingSentAt){p._rttMs=Math.min(1000,Math.max(0,Date.now()-p._pingSentAt));p._pingSentAt=0;}
if(msg.authAccountToken!==undefined){const supplied=sanitizeToken(msg.authAccountToken);if(supplied){const found=accountByToken(supplied);if(!found){send(ws,{type:'auth',ok:false,error:'INVALID_ACCOUNT_TOKEN'});socket.destroy();return;}for(const q of players.values())if(q!==p&&q.accountId===found.id&&q._socket){send(ws,{type:'auth',ok:false,error:'ACCOUNT_IN_USE'});socket.destroy();return;}p.accountId=found.id;p.accountToken=supplied;p._authenticated=true;send(ws,{type:'auth',ok:true,account:publicAccount(found)});}else{const created=newAccount();p.accountId=created.account.id;p.accountToken=created.token;p._authenticated=true;send(ws,{type:'auth',ok:true,newAccount:true,accountToken:created.token,account:publicAccount(created.account)});}return;}
if(!p._authenticated)return;
const acCheck=inspectInput(p,msg,gameTime);if(!acCheck.ok&&acCheck.violations.includes('PITCH_RANGE'))continue;if(acCheck.quarantine){socket.destroy();return;}const input=sanitizeInput(msg);if(msg.clientTime&&!Number.isFinite(msg.clientTime))continue;if(input.seq>p.lastInputSeq){p._inputQueue.push(input);if(p._inputQueue.length>NET.MAX_INPUT_BUFFER)p._inputQueue.splice(0,p._inputQueue.length-NET.MAX_INPUT_BUFFER);}const actionFresh=freshActionSeq(p,msg.seq);if(msg.seq!==undefined&&!actionFresh)recordActionViolation(p,'ACTION_REPLAY',gameTime,1);
if(actionFresh&&msg.joinMatchmaking){if(!p.accountId){send(ws,{type:'matchmaking',ok:false,error:'AUTH_REQUIRED'});}else{const a=accounts.get(p.accountId);const r=matchmaker.enqueue(p.accountId,String(msg.partyId||p.accountId),Date.now(),Number(a?.rating)||1000);send(ws,{type:'matchmaking',...r,queueSize:matchmaker.queueSize});if(r.ok)formQueuedMatch();}}
if(actionFresh&&msg.leaveMatchmaking){const ok=!!p.accountId&&matchmaker.remove(p.accountId);send(ws,{type:'matchmaking',ok,queueSize:matchmaker.queueSize});}
if(actionFresh&&msg.profileName!==undefined){const a=accounts.get(p.accountId);const name=normalizeDisplayName(msg.profileName,'');if(a&&name){a.displayName=name;markAccountsDirty();send(ws,{type:'profile',account:publicAccount(a)});}}
if(actionFresh&&msg.requestProfile){send(ws,{type:'profile',account:accountSnapshot(p)}); }if(actionFresh&&msg.fire===true&&phase===ROUND_PHASES.LIVE&&p.status==='ALIVE'&&p.alive&&(!activeMatch||matchPlayer(p)))p._fire=true;else if(msg.fire===true&&phase===ROUND_PHASES.LIVE)recordActionViolation(p,'ILLEGAL_FIRE_STATE',gameTime,2);if(actionFresh&&msg.reload===true&&phase===ROUND_PHASES.LIVE&&p.status==='ALIVE'&&p.alive)p._reload=true;else if(msg.reload===true&&phase===ROUND_PHASES.LIVE)recordActionViolation(p,'ILLEGAL_RELOAD_STATE',gameTime,2);if(actionFresh&&msg.buyWeapon&&phase===ROUND_PHASES.BUY&&p.status==='ALIVE'&&p.alive)broadcast({type:'buyResult',id,ok:buyWeapon(p,msg.buyWeapon,`${p.id}:buy:${msg.seq}:weapon`),player:makeSnapshot(p)});if(actionFresh&&msg.buyGrenade&&phase===ROUND_PHASES.BUY&&p.status==='ALIVE'&&p.alive)broadcast({type:'buyResult',id,ok:buyGrenade(p,msg.buyGrenade,`${p.id}:buy:${msg.seq}:grenade`),player:makeSnapshot(p)});if(actionFresh&&msg.equip&&phase===ROUND_PHASES.BUY&&p.status==='ALIVE'&&p.alive&&equipWeapon(p,msg.equip))broadcast({type:'equip',id,weapon:p.weapon});if(actionFresh&&msg.equip&&phase===ROUND_PHASES.LIVE&&p.status==='ALIVE'&&p.alive&&equipWeapon(p,msg.equip))broadcast({type:'equip',id,weapon:p.weapon});if(actionFresh&&msg.throwGrenade&&phase===ROUND_PHASES.LIVE&&p.status==='ALIVE'&&p.alive&&gameTime-(p._lastGrenadeAt||-999)>=.25&&p.inventory.grenades.includes(msg.throwGrenade)){if(launchGrenade(p,msg.throwGrenade)){p._lastGrenadeAt=gameTime;consumeGrenade(p,msg.throwGrenade);}}if(actionFresh&&msg.objective==='plant'&&phase===ROUND_PHASES.LIVE&&startPlant(objective,p,gameTime))broadcast({type:'objective',event:'plantStart',by:p.id,site:objective.site,endsAt:gameTime+OBJECTIVE.PLANT_TIME});if(actionFresh&&msg.objective==='defuse'&&phase===ROUND_PHASES.LIVE&&startDefuse(objective,p,gameTime))broadcast({type:'objective',event:'defuseStart',by:p.id,endsAt:objective.defuseAt});if(actionFresh&&msg.objective==='cancelPlant')cancelPlant(objective,p);if(actionFresh&&msg.objective==='cancelDefuse')cancelDefuse(objective,p);if(actionFresh&&msg.objective==='pickup'&&pickupDevice(objective,p))broadcast({type:'objective',event:'devicePickup',by:p.id});}catch{}}}});
 const cleanup=()=>{if(p._socket!==ws)return;ws.open=false;sockets.delete(id);p._socket=null;p._disconnectedAt=Date.now();p._recoveryUntil=0;p._preDisconnectAlive=p.alive;p._preDisconnectStatus=p.status;p._roundReady=false;if(activeMatch&&objective.status==='NONE'&&objective.carrierId===p.id&&dropDevice(objective,p))broadcast({type:'objective',event:'deviceDrop',x:objective.dropX,z:objective.dropZ});p.alive=false;p.status='DISCONNECTED';p._fire=false;p._reload=false;p._inputQueue=[];broadcast({type:'disconnect',id,grace:RECONNECT_GRACE_SECONDS});};
 socket.on('close',cleanup);socket.on('error',cleanup);
});
const recovered=recoveryRepo.get('active');
if(recovered&&verifyRecoveryRecord(recovered)){
  const snap=recovered; if(matchmaker.restoreMatch(snap.activeMatch)){activeMatch=matchmaker.getMatch(snap.activeMatch.id);phase=snap.phase;phaseEnds=snap.phaseEnds;round=snap.round;score={...snap.score};gameTime=snap.gameTime;objective=snap.objective||objectiveState({round});
    for(const saved of snap.players){const p=makePlayer(saved.id,saved.x,saved.z,saved.team);Object.assign(p,saved,{_preDisconnectAlive:saved.preDisconnectAlive,_preDisconnectStatus:saved.preDisconnectStatus,_disconnectedAt:Date.now(),_recoveryUntil:Date.now()+RECOVERY_RECONNECT_GRACE_SECONDS*1000,_socket:null,_connection:null,_authenticated:false,_inputQueue:[],_input:sanitizeInput({yaw:saved.yaw,pitch:saved.pitch}),_history:[],_rttMs:0,_pingSentAt:0,_pingNonce:0,_pingLastAt:gameTime,_msgWindowStart:Date.now(),_msgCount:0,_lastActionSeq:saved.fireSeq||0,_lastGrenadeAt:-999});p.accountToken=null;ensureAntiCheat(p);players.set(p.id,p);sessions.set(saved.sessionToken,p);recordHistory(p);nextId=Math.max(nextId,Number(p.id)+1||nextId);}
    if(objective.status==='NONE'&&!objective.dropped&&!objective.carrierId){const fallback=[...players.values()].find(p=>p.team===objective.attacker&&p.status!=='SPECTATOR');if(fallback)objective.carrierId=fallback.id;}
    for(const g of snap.grenades)grenades.set(g.id,{...g});
    for(const sm of (snap.smokeZones||[]))if(sm.expiresAt>gameTime)smokeZones.set(sm.id,{...sm});
    console.log(`[recovery] restored active match ${activeMatch.id}`);
    if(activeMatch.status==='COMPLETED'&&activeMatch.result){setImmediate(()=>finishMatch(activeMatch.result));}
  }else clearRecovery();
}else if(recovered)clearRecovery();
setImmediate(reconcilePreparedSettlements);
process.on('SIGTERM',shutdown);
process.on('SIGINT',shutdown);
process.on('uncaughtException',err=>{console.error('[fatal]',err);shutdown();});
process.on('unhandledRejection',err=>{console.error('[unhandled-rejection]',err);});
setInterval(()=>{const tickStarted=process.hrtime.bigint();gameTime+=DT;for(const [token,p] of sessions){if(p._disconnectedAt&&Date.now()-p._disconnectedAt>RECONNECT_GRACE_SECONDS*1000){sessions.delete(token);if(activeMatch){const slot=activeMatch.players.find(x=>x.playerId===p.id);if(slot)slot.abandoned=true;}players.delete(p.id);broadcast({type:'leave',id:p.id});}}if(gameTime>=phaseEnds){if(activeMatch&&phase===ROUND_PHASES.BUY)beginLive();else if(activeMatch&&phase===ROUND_PHASES.POST)startRound();else if(activeMatch&&phase===ROUND_PHASES.LIVE){const timedWinner=objectiveTimeWinner(objective);finishRound(timedWinner||resolveRoundWinner(players,{includeDisconnected:true}));}}stepGrenades();if(phase==='LIVE'&&objective.status==='PLANTING'){const planter=players.get(objective.plantBy);if(!planter||!planter.alive||planter.status!=='ALIVE'||siteAt(planter.x,planter.z)?.id!==objective.site){if(planter)interruptPlant(objective,planter);else{objective.status='NONE';objective.plantBy=null;objective.site=null;objective.plantedAt=0;objective.dropped=true;objective.carrierId=null;}broadcast({type:'objective',event:'plantCancel',x:objective.dropX,z:objective.dropZ});if(objective.dropped)broadcast({type:'objective',event:'deviceDrop',x:objective.dropX,z:objective.dropZ});}else if(gameTime>=objective.plantedAt+OBJECTIVE.PLANT_TIME){completePlant(objective,gameTime);phaseEnds=Math.max(phaseEnds,objective.detonateAt+0.1);broadcast({type:'objective',event:'planted',site:objective.site,detonateAt:objective.detonateAt});}}const objectiveEvent=resolveObjective(objective,players,gameTime);if(objectiveEvent){const winner=objectiveWinner(objective);broadcast({type:'objective',event:objectiveEvent,winner});if(winner)finishRound(winner);}for(const p of players.values()){if(p.status==='DISCONNECTED')continue;const input=p._inputQueue?.shift()||p._input||{};if(input.seq>(p.lastInputSeq||0))p.lastInputSeq=input.seq;p._input=input;applyMovement(p,input,DT,gameTime);updateReload(p,gameTime);recordHistory(p);p.round=round;if(p._reload&&!p.reloading&&p.ammo<WEAPONS[p.weapon].magazine&&p.reserve>0){p.reloading=true;p.reloadAt=gameTime+WEAPONS[p.weapon].reloadTime;}p._reload=false;if(p._fire&&phase==='LIVE'){const ev=tryFire(p,players,gameTime,{rewoundPlayers:rewindPlayers(p),smokeZones:[...smokeZones.values()]});if(ev){const shooterAcc=accounts.get(p.accountId);recordAccountEvent(shooterAcc,{type:'shot',meta:{weapon:ev.weapon}});if(ev.headshot)recordAccountEvent(shooterAcc,{type:'headshot'});if(ev.killed){recordAccountEvent(shooterAcc,{type:'kill',meta:{target:ev.target}});const victim=players.get(ev.target);if(victim)recordAccountEvent(accounts.get(victim.accountId),{type:'death',meta:{killer:p.id}});}markAccountsDirty();broadcast({type:'event',event:{...ev,time:gameTime}});if(ev.killed){if(objective.status==='NONE'&&objective.carrierId===ev.target&&dropDevice(objective,players.get(ev.target)))broadcast({type:'objective',event:'deviceDrop',x:objective.dropX,z:objective.dropZ});else if(objective.status==='PLANTING'&&objective.plantBy===ev.target&&interruptPlant(objective,players.get(ev.target)))broadcast({type:'objective',event:'deviceDrop',x:objective.dropX,z:objective.dropZ});broadcast({type:'death',victim:ev.target,killer:ev.shooter,weapon:ev.weapon,headshot:!!ev.headshot,round,time:gameTime});if(objective.status!=='PLANTED'&&objective.status!=='PLANTING'){if(objective.status!=='PLANTED'&&objective.status!=='PLANTING'){const winner=resolveRoundWinner(players,{includeDisconnected:!!activeMatch});if(winner!==null)finishRound(winner==='draw'?null:winner);}}}}p._fire=false;}}
for(const p of players.values()){if(gameTime-p._pingLastAt>=NET.PING_INTERVAL_SECONDS){p._pingLastAt=gameTime;p._pingNonce++;p._pingSentAt=Date.now();const ws=sockets.get(p.id);if(ws)send(ws,{type:'ping',nonce:p._pingNonce});}}
if(gameTime-(players.values().next().value?._lastSnapshotAt||0)>=1/NET.SNAPSHOT_RATE){for(const p of players.values())p._lastSnapshotAt=gameTime;broadcastState();}const tickMs=Number(process.hrtime.bigint()-tickStarted)/1e6;recordTick(PERF_METRICS,tickMs);},1000/TICK_RATE);
setInterval(()=>{if(accountsDirty)saveAccounts();if(activeMatch){try{saveRecovery();}catch(err){console.error('[recovery-save]',err);}}},1000);
server.on('error',err=>{console.error('[server-error]',err);process.exitCode=1;});
server.listen(PORT,()=>{ready=true;console.log(`Browser FPS server running on http://localhost:${PORT}`);});
