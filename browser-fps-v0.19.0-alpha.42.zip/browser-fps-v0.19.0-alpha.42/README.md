# Project Vanguard v0.19.0-alpha.26

## Cel
v0.18 porządkuje system animacji i synchronizacji postaci. Najważniejsza zmiana nie jest kosmetyczna: klient nie zgaduje już fazy ruchu z samej prędkości, tylko otrzymuje z serwera autorytatywny stan locomotion/action oraz fazę cyklu.

## Zmiany
- wspólny `shared/animation.mjs` z deterministyczną maszyną stanów,
- stany locomotion: idle / walk / run / crouch / crouch_walk / jump / reload / dead,
- osobny kanał akcji: idle / fire / reload / hurt / dead,
- autorytatywne `animCycle`, `animTime` i `actionTime` w snapshotach,
- synchronizacja fazy animacji z serwera do klientów,
- interpolacja fazy cyklu remote playerów z uwzględnieniem zawijania 2π,
- reload i fire wyzwalają jawne akcje zamiast ukrytych efektów w rendererze,
- reset rundy czyści stan animacji/akcji,
- istniejący GLB/PBR, audio, efekty, ekonomia, mapa, hitboxy i networking pozostają kompatybilne.

## QA / weryfikacja
- `npm test`: **42/42 PASS**
- `npm run check`: **PASS**
- serwer HTTP `/health`: **PASS**
- `/api/state`: **PASS**
- dostarczenie GLB przez HTTP: **200 OK**
- WebSocket upgrade: **PASS**
- WebSocket welcome payload: **PASS**
- pełna walidacja istniejących assetów GLB/PBR: **PASS**

Nie raportujemy testu wizualnego GPU jako zaliczonego, jeśli środowisko nie udostępnia wiarygodnego WebGL/EGL. W takim przypadku pozostaje on testem do wykonania w docelowej przeglądarce.

## v0.18.2 — Browser delivery hardening
- Fixed production-critical ES module serving: `.mjs` is now served with a JavaScript MIME type.
- Fixed `/shared/*` module delivery so browser imports from the client can resolve shared game modules.
- GLB assets now use `model/gltf-binary`; static responses include `nosniff`.
- Static path handling rejects encoded traversal attempts and restricts files to client/shared roots.
- WebSocket cleanup now closes the logical socket state before broadcasting disconnects.
- Added HTTP integration regression tests for module MIME, shared-module resolution, GLB delivery and traversal protection.
- Added runtime error/unhandled-rejection capture to browser QA telemetry and an opt-in `?qa=1` telemetry overlay.

## v0.18.1 — QA instrumentation & HUD correctness
- Added browser runtime QA telemetry at `window.__VANGUARD_QA__` for WebGL version/renderer, shader compilation/linking, asset load status, FPS, draw-call telemetry and GL errors.
- Weapon asset loading now records per-weapon failures instead of hiding them inside a single aggregate promise.
- HUD round score now uses authoritative server round score rather than counting currently alive remote players.
- Regression suite and server/WebSocket smoke tests verified after changes.

### Browser QA policy
A local Node test suite does **not** count as GPU/rendering verification. A release-grade browser rendering test requires a real browser session against a reachable deployment, with WebGL context creation, shader compilation, GLB/texture loading, runtime errors and visual screenshot inspection recorded separately.


## v0.19.0-alpha.1 — Combat/Networking Security Sprint

- Server-observed RTT and bounded hit-registration rewind (maximum 200 ms).
- Historical player state buffer for lag-compensated hit validation.
- Server-side fire/action sequence replay protection.
- WebSocket message size and rate limits; masked-frame enforcement.
- Authoritative grenade entities with trajectory, gravity, wall/floor collision, fuse and server-side explosion.
- Grenade damage falloff and line-of-sight validation.
- Authoritative grenade state synchronization to clients.
- Client QA telemetry extended with network/runtime state.
- Regression/security suite expanded to 54 tests.

This is an alpha sprint checkpoint, not a production-release claim.


## v0.19.0-alpha.3 — Reconnect / Connection Lifecycle

- Cryptographically random reconnect session tokens with bounded 15-second grace by default.
- Reconnect restores the authoritative player ID/team/state instead of creating a duplicate player.
- Duplicate use of an active session token is rejected.
- Disconnected players immediately stop movement/combat simulation and are excluded from active round elimination.
- Expired reconnect sessions are removed server-side.
- Round transitions prepare disconnected players without counting them as alive until they actually reconnect.
- Client persists the reconnect token and automatically attempts session recovery after connection loss.
- Added raw TCP/WebSocket integration regression tests for restore, duplicate-session rejection and token expiry.
- Regression suite: 61 tests.

This remains an alpha checkpoint; browser/GPU visual QA still requires a real browser session.


## v0.19.0-alpha.4 — Economy / Wallet Foundation

- Added server-authoritative wallet ledger with bounded transaction history.
- Purchases use deterministic server-side transaction IDs tied to player action sequence.
- Debit operations reject invalid amounts and insufficient funds.
- Credits reject overflow and are recorded with reason/item metadata.
- Round rewards now pass through the wallet ledger instead of directly mutating money.
- Existing client money remains a read-only snapshot of the authoritative server wallet.
- Added regression coverage for overspending, ledger bounds and purchase accounting.

This is the economy foundation; persistent database storage and real-money payment integration are intentionally not enabled yet.


## v0.19.0-alpha.5 — Inventory Foundation

- Added server-authoritative inventory normalization and ownership helpers.
- Weapon ownership is unique and bounded; the starter pistol is always retained.
- Grenades are represented as bounded consumable inventory entries with exact server-side consumption.
- Purchase flow validates inventory capacity before wallet debit to prevent currency loss on grant failure.
- Welcome payload exposes a sanitized inventory snapshot, never the wallet ledger.
- Added regression tests for inventory normalization, unique ownership and exact consumable removal.

This remains an alpha checkpoint; persistent player storage, cosmetics, crates, shop UI and real-money payments are not enabled yet.


## v0.19.0-alpha.16 — Matchmaking skill + MMR
- Server-authoritative Elo-style MMR, bounded 100–5000, default 1000.
- Match result updates MMR using team-average opponent rating.
- Match history is persisted per account (bounded to 50 entries).
- Matchmaking uses rating proximity with queue-time expansion and preserves parties.
- Team assignment minimizes average MMR difference while keeping parties intact.
- Profile exposes MMR and recent match history.
- Regression: 93/93 tests PASS; syntax check PASS.

## v0.19.0-alpha.22
- Match settlement now has a deterministic SHA-256 settlement ID.
- Server settlement is guarded against duplicate application within a process.
- Match history and `matchEnd` carry the settlement ID for audit correlation.
- Added deterministic settlement/idempotency tests.


## v0.19.0-alpha.23 — Match Crash Recovery
- Active 5v5 match state is snapshotted to `data/active-match.json` with atomic persistence.
- Recovery records include an integrity digest and are schema-validated before restore.
- Player combat/economy state, match phase/score, participant roster and grenade state are recovered after a hard process restart.
- Recovered session tokens remain resumable for a bounded recovery grace period (120s by default).
- Recovery state is cleared only after authoritative match settlement.
- Hard-restart integration test verifies a live 5v5 survives process termination and restart.


## v0.19.0-alpha.24
- Persistent settlement journal (`PREPARED` / `COMPLETED`).
- Settlement records survive process restart.
- Completed settlements are loaded into the idempotency guard on boot.
- Account match-history settlement IDs prevent duplicate match settlement side effects.
- Added persistent settlement-state regression coverage.


## v0.19.0-alpha.26 — Crash-safe settlement hardening
- Two-phase persistent settlement: `PREPARED → COMPLETED`.
- Deterministic rating targets are persisted before account commit.
- Settlement commit is restart-safe and event-idempotent.
- Competitive integrity is settlement-idempotent.
- Account persistence now explicitly marks mutated records dirty before atomic save.
- Added integration test for automatic completion of a prepared settlement after process recovery.
- Recovery file is removed after successful finalization.
- Full regression: 114/114 tests PASS.


## Runtime safety
The server uses a single-writer data-directory lock (`.server.lock`) to prevent concurrent server instances from sharing the same persistent JSON state. A second live process using the same `VANGUARD_DATA_DIR` exits instead of risking last-writer-wins corruption.

## Persistence recovery
Persistent JSON repositories use atomic writes plus a previous-version `.bak` backup. If an existing primary file is corrupted, the server restores the last known valid backup and repairs the primary file. If both the primary and backup are unavailable or invalid, startup fails closed instead of silently replacing existing state with an empty database. Runtime backup/temp files are excluded from release artifacts.

## Gameplay — weapon switching
Owned weapons can be switched during LIVE rounds. Each weapon keeps its own authoritative magazine and reserve state, so switching weapons cannot grant free ammunition. Weapon state is included in crash recovery.


## Combat update — alpha.31
Flash grenades now use server-authoritative distance, line-of-sight and facing calculations. Affected clients receive a bounded flash intensity/duration overlay; friendly and enemy players are both evaluated by the same authoritative rule.

## Alpha 0.19.0-alpha.32 — gameplay smoke grenade
Smoke grenade is server-authoritative and persists through recovery snapshots. Active smoke zones block weapon line-of-sight and flash effects, while fragmentation damage remains independent of smoke visibility.

## Gameplay UX
Alpha.33 adds an authoritative-feeling death/spectator presentation: eliminated players receive a death overlay and can cycle through living teammates with Space until the next round.

## Gameplay
The live combat loop supports selecting owned grenade types (frag, flash, smoke) client-side while the server remains authoritative for inventory and grenade deployment.

## Alpha 35 gameplay fixes
Round rewards are applied consistently to the final round, and lethal death events are broadcast before match-end/lobby transitions so the client can render the final elimination correctly.

## Tactical objective mode
The round loop includes a server-authoritative plant/defuse objective on Site A and Site B. Attackers alternate by round; the objective device has a server-assigned carrier, drops on carrier death/disconnect, can be picked up by an attacking teammate, and planting, detonation and defuse state are included in recovery.

## Alpha 0.19.0-alpha.38
Objective interaction now supports explicit server-authoritative plant cancellation with separate client actions for plant and defuse cancellation.


## v0.19.0-alpha.41 — Objective timeout correctness
- Fixed tactical round timeout: when the live round expires without a planted device, the defending team wins instead of comparing remaining player counts.
- Preserved planted-device resolution so a planted objective remains an attacker win on detonation.
- Added regression coverage for both alternating attack sides and planted-objective timeout semantics.
- Full regression: 144/144 tests PASS; syntax check and server readiness smoke test PASS.
