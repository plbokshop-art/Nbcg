import {RATING} from './rating.mjs';
import {partyEffectiveRating} from './competitive.mjs';

export const MATCHMAKING=Object.freeze({MIN_PLAYERS:10,TEAM_SIZE:5,MAX_QUEUE:64,MAX_PARTY_SIZE:5,TARGET_SCORE:13});
export const QUEUE_STATES=Object.freeze({IDLE:'IDLE',QUEUED:'QUEUED',MATCHED:'MATCHED'});

export function createMatchmaker({teamSize=MATCHMAKING.TEAM_SIZE,maxQueue=MATCHMAKING.MAX_QUEUE,targetScore=MATCHMAKING.TARGET_SCORE}={}){
  const queue=[]; const entries=new Map(); const matches=new Map(); const activeAccounts=new Set(); let nextMatch=1;
  function enqueue(accountId,partyId=accountId,now=Date.now(),rating=1000){
    if(typeof accountId!=='string'||!accountId||typeof partyId!=='string'||!partyId)return {ok:false,error:'INVALID_ID'};
    if(entries.has(accountId))return {ok:false,error:'ALREADY_QUEUED'};
    if(activeAccounts.has(accountId))return {ok:false,error:'IN_MATCH'};
    if(queue.length>=maxQueue)return {ok:false,error:'QUEUE_FULL'};
    const partySize=queue.filter(x=>x.partyId===partyId).length;
    if(partySize>=MATCHMAKING.MAX_PARTY_SIZE)return {ok:false,error:'PARTY_FULL'};
    const e={accountId,partyId,enqueuedAt:now,rating:Number.isFinite(Number(rating))?Number(rating):1000}; entries.set(accountId,e); queue.push(e); return {ok:true,entry:e};
  }
  function remove(accountId){const e=entries.get(accountId);if(!e)return false;entries.delete(accountId);const i=queue.indexOf(e);if(i>=0)queue.splice(i,1);return true;}
  function popReady(now=Date.now()){
    const parties=[]; const seen=new Set();
    for(const e of queue){if(seen.has(e.partyId))continue;const party=queue.filter(x=>x.partyId===e.partyId);if(party.length>0&&party.length<=teamSize){parties.push(party);seen.add(e.partyId);}}
    const anchor=queue[0]; if(!anchor)return null;
    const waited=Math.max(0,(now-anchor.enqueuedAt)/1000);
    for(const party of parties) party.effectiveRating=partyEffectiveRating(party);
    const anchorParty=parties.find(p=>p.some(e=>e.accountId===anchor.accountId));
    const anchorSkill=anchorParty?.effectiveRating??anchor.rating;
    const maxDiff=Math.min(RATING.MAX_SEARCH_DIFF, MATCHMAKING.TEAM_SIZE*50+waited*RATING.SEARCH_EXPAND_PER_SECOND);
    const candidates=parties.filter(p=>Math.abs(p.effectiveRating-anchorSkill)<=maxDiff);
    function pick(i,chosen,count){if(count===teamSize*2)return chosen;if(i>=candidates.length||count>teamSize*2)return null;const party=candidates[i];if(count+party.length<=teamSize*2){const withParty=pick(i+1,[...chosen,...party],count+party.length);if(withParty)return withParty;}return pick(i+1,chosen,count);}
    let selected=pick(0,[],0); if(!selected||selected.length!==teamSize*2)return null;
    if(new Set(selected.map(e=>e.accountId)).size!==teamSize*2)return null;
    const grouped=[...new Set(selected.map(e=>e.partyId))].map(id=>selected.filter(e=>e.partyId===id)); const assignments=[]; function assign(i,blue,red){if(i===grouped.length){if(blue.length===teamSize&&red.length===teamSize)assignments.push({blue:[...blue],red:[...red]});return;}const party=grouped[i];if(blue.length+party.length<=teamSize)assign(i+1,[...blue,...party],red);if(red.length+party.length<=teamSize)assign(i+1,blue,[...red,...party]);} assign(0,[],[]); if(!assignments.length)return null; const best=assignments.sort((a,b)=>Math.abs(avg(a.blue)-avg(a.red))-Math.abs(avg(b.blue)-avg(b.red)))[0]; function avg(xs){return xs.reduce((n,e)=>n+e.rating,0)/Math.max(1,xs.length);} selected=[...best.blue.map(e=>({...e,team:'blue'})),...best.red.map(e=>({...e,team:'red'}))]; for(const e of selected)remove(e.accountId); const match={id:`match_${String(nextMatch++).padStart(6,'0')}`,createdAt:now,teamSize,targetScore,players:selected,status:'READY',score:{blue:0,red:0}};
    for(const p of match.players)activeAccounts.add(p.accountId); matches.set(match.id,match); return match;
  }
  function restoreMatch(match){if(!match||typeof match.id!=='string'||matches.has(match.id))return false;const copy=JSON.parse(JSON.stringify(match));matches.set(copy.id,copy);for(const p of copy.players||[])activeAccounts.add(p.accountId);const n=Number(String(copy.id).replace('match_',''));if(Number.isInteger(n))nextMatch=Math.max(nextMatch,n+1);return true;}
  function completeMatch(id,result='completed'){const m=matches.get(id);if(!m)return false;m.status=result;for(const p of m.players)activeAccounts.delete(p.accountId);return true;}
  function getActiveMatchFor(accountId){for(const m of matches.values())if(m.status==='READY'||m.status==='LIVE')if(m.players.some(p=>p.accountId===accountId))return m;return null;}
  return {enqueue,remove,popReady,restoreMatch,completeMatch,getActiveMatchFor,get queueSize(){return queue.length;},getMatch:id=>matches.get(id)||null,snapshot:()=>({queued:queue.length,matches:matches.size,active:activeAccounts.size})};
}

export function validateTeamBalance(players,teamSize=MATCHMAKING.TEAM_SIZE){
  if(!Array.isArray(players)||players.length!==teamSize*2)return false;
  const counts={blue:0,red:0};for(const p of players)if(p&&counts[p.team]!==undefined)counts[p.team]++;else return false;
  return counts.blue===teamSize&&counts.red===teamSize;
}
