import {createHash, timingSafeEqual} from 'node:crypto';

export const AUTH={TOKEN_BYTES:32,MAX_TOKEN_LENGTH:128};
export function hashToken(token){
  return createHash('sha256').update(String(token)).digest('hex');
}
export function tokenMatches(token,storedHash){
  if(typeof token!=='string'||typeof storedHash!=='string'||token.length===0||token.length>AUTH.MAX_TOKEN_LENGTH)return false;
  const actual=Buffer.from(hashToken(token),'hex');
  const expected=Buffer.from(storedHash,'hex');
  return actual.length===expected.length&&timingSafeEqual(actual,expected);
}
export function sanitizeToken(token){
  return typeof token==='string'&&token.length<=AUTH.MAX_TOKEN_LENGTH?token:null;
}
