export const PERF = {
  HISTORY_SIZE: 120,
  TARGET_TICK_MS: 1000 / 60,
  SNAPSHOT_TARGET_MS: 1000 / 20,
};

export function createPerformanceMetrics() {
  return {
    startedAt: Date.now(),
    ticks: 0,
    tickOverruns: 0,
    tickTotalMs: 0,
    tickMaxMs: 0,
    snapshotCount: 0,
    snapshotTotalMs: 0,
    snapshotMaxMs: 0,
    snapshotBytes: 0,
    outboundMessages: 0,
    outboundBytes: 0,
    samples: [],
  };
}

function pushSample(m, value) {
  m.samples.push(value);
  if (m.samples.length > PERF.HISTORY_SIZE) m.samples.shift();
}

export function recordTick(m, durationMs) {
  m.ticks++;
  m.tickTotalMs += durationMs;
  m.tickMaxMs = Math.max(m.tickMaxMs, durationMs);
  if (durationMs > PERF.TARGET_TICK_MS * 1.5) m.tickOverruns++;
  pushSample(m, durationMs);
}

export function recordSnapshot(m, durationMs, bytes) {
  m.snapshotCount++;
  m.snapshotTotalMs += durationMs;
  m.snapshotMaxMs = Math.max(m.snapshotMaxMs, durationMs);
  m.snapshotBytes += bytes;
}

export function recordOutbound(m, bytes) {
  m.outboundMessages++;
  m.outboundBytes += bytes;
}

export function performanceSnapshot(m, now = Date.now()) {
  const elapsed = Math.max(0.001, (now - m.startedAt) / 1000);
  const avgTick = m.ticks ? m.tickTotalMs / m.ticks : 0;
  const avgSnapshot = m.snapshotCount ? m.snapshotTotalMs / m.snapshotCount : 0;
  return {
    uptimeSeconds: Math.round(elapsed * 10) / 10,
    ticks: m.ticks,
    tick: { avgMs: Number(avgTick.toFixed(3)), maxMs: Number(m.tickMaxMs.toFixed(3)), overruns: m.tickOverruns },
    snapshots: {
      count: m.snapshotCount,
      avgMs: Number(avgSnapshot.toFixed(3)),
      maxMs: Number(m.snapshotMaxMs.toFixed(3)),
      totalBytes: m.snapshotBytes,
    },
    outbound: {
      messages: m.outboundMessages,
      bytes: m.outboundBytes,
      bytesPerSecond: Math.round(m.outboundBytes / elapsed),
    },
  };
}
