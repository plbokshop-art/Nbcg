import { MAP, MAP_WALLS, pointBlocked, segmentBlocked } from './map.mjs';
import { locomotionFor, setAnimationState, advanceAnimation, triggerAction, updateAction } from './animation.mjs';
import {ensureWallet,walletDebit} from './economy.mjs';
import {ensureInventory,ownsWeapon,grantWeapon,addGrenade,consumeGrenade} from './inventory.mjs';
export const TICK_RATE = 60;
export const DT = 1 / TICK_RATE;
export const WORLD = { minX: -24, maxX: 24, minZ: -18, maxZ: 18 };
export const PLAYER = { radius: 0.35, height: 1.7, eye: 1.55, speed: 5.2, sprint: 1.35, jump: 5.6, gravity: 16, crouchSpeed: .62, headHeight: 1.42, headRadius: .22, bodyHeight: 1.25 };
export const WEAPONS = {
  pistol: { id:'pistol', name:'Pistol', damage:28, fireInterval:.18, magazine:12, reserve:48, reloadTime:1.45, range:55, price:0 },
  rifle: { id:'rifle', name:'Rifle', damage:34, fireInterval:.105, magazine:30, reserve:90, reloadTime:1.8, range:70, price:2700 },
  smg: { id:'smg', name:'SMG', damage:24, fireInterval:.075, magazine:30, reserve:90, reloadTime:1.65, range:48, price:1600 },
  shotgun: { id:'shotgun', name:'Shotgun', damage:18, pellets:8, fireInterval:.9, magazine:6, reserve:30, reloadTime:2.2, range:28, price:2200 }
};
export { MAP, MAP_WALLS };
export const GRENADES = {
  frag:{id:'frag',name:'Frag',price:300,damage:70,radius:5, fuse:1.6},
  flash:{id:'flash',name:'Flash',price:200,radius:7,fuse:1.4},
  smoke:{id:'smoke',name:'Smoke',price:300,radius:4.2,fuse:1.2,life:12}
};
export const START_MONEY=800;
export function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
export function normalize2(x,z){const l=Math.hypot(x,z);return l>1e-6?[x/l,z/l]:[0,0];}
export function makePlayer(id,x,z,team='blue'){
 const weapon=WEAPONS.pistol;
 return {id,team,x,y:0,z,yaw:team==='blue'?0:Math.PI,pitch:0,vy:0,hp:100,alive:true,crouched:false,money:START_MONEY,
  inventory:{weapons:['pistol'],grenades:[]},wallet:{balance:START_MONEY,version:0,ledger:[]},weapon:'pistol',weaponState:{pistol:{ammo:weapon.magazine,reserve:weapon.reserve}},ammo:weapon.magazine,reserve:weapon.reserve,reloading:false,reloadAt:0,nextShot:0,score:0,deaths:0,shotCount:0,fireSeq:0,moveX:0,moveZ:0,speed:0,anim:'idle',animTime:0,animCycle:0,action:'idle',actionTime:0,actionUntil:0};
}
export function equipWeapon(p,id){if(!ownsWeapon(p,id)||!WEAPONS[id]||p.reloading)return false;p.weaponState??={};for(const owned of ensureInventory(p).weapons){const w=WEAPONS[owned];if(w&&!p.weaponState[owned])p.weaponState[owned]={ammo:w.magazine,reserve:w.reserve};}p.weaponState[p.weapon]={ammo:Math.max(0,Math.floor(p.ammo||0)),reserve:Math.max(0,Math.floor(p.reserve||0))};p.weapon=id;const next=p.weaponState[id];p.ammo=Math.max(0,Math.floor(next.ammo));p.reserve=Math.max(0,Math.floor(next.reserve));p.reloading=false;return true;}
export function buyWeapon(p,id,transactionId){const w=WEAPONS[id];if(!w||ownsWeapon(p,id)||!ensureInventory(p)||p.inventory.weapons.length>=128)return false;ensureWallet(p);const tx=walletDebit(p,w.price,{id:transactionId,reason:'WEAPON_PURCHASE',item:id});if(!tx.ok)return false;if(!grantWeapon(p,id))return false;p.weaponState??={};p.weaponState[id]={ammo:w.magazine,reserve:w.reserve};return equipWeapon(p,id);}
export function buyGrenade(p,id,transactionId){const g=GRENADES[id];if(!g||ensureInventory(p).grenades.length>=4)return false;ensureWallet(p);const tx=walletDebit(p,g.price,{id:transactionId,reason:'GRENADE_PURCHASE',item:id});if(!tx.ok)return false;return addGrenade(p,id,1);}
export function resetPlayer(p,x,z){const pistol=WEAPONS.pistol;p.weaponState??={};for(const id of ensureInventory(p).weapons){const w=WEAPONS[id];if(w)p.weaponState[id]={ammo:w.magazine,reserve:w.reserve};}p.weaponState.pistol={ammo:pistol.magazine,reserve:pistol.reserve};Object.assign(p,{x,y:0,z,vy:0,hp:100,alive:true,status:'ALIVE',lastKillerId:null,lastDeathAt:0,deathRound:0,crouched:false,weapon:'pistol',ammo:p.inventory.weapons.includes('pistol')?pistol.magazine:0,reserve:pistol.reserve,reloading:false,reloadAt:0,nextShot:0,action:'idle',actionTime:0,actionUntil:0,anim:'idle',animTime:0,animCycle:0});}
export function applyMovement(p,input,dt,now=0){if(!p.alive){p.moveX=0;p.moveZ=0;p.speed=0;setAnimationState(p,'dead',now);updateAction(p,now);return;}let[mx,mz]=normalize2((input.right?1:0)-(input.left?1:0),(input.backward?1:0)-(input.forward?1:0));const sprinting=input.sprint&&input.forward&&!input.crouch;const sprint=sprinting?PLAYER.sprint:1;const speedMul=(input.crouch?PLAYER.crouchSpeed:1);const c=Math.cos(p.yaw),s=Math.sin(p.yaw);const vx=(mx*c-mz*s)*PLAYER.speed*sprint*speedMul,dzv=(mx*s+mz*c)*PLAYER.speed*sprint*speedMul;const dx=vx*dt,dz=dzv*dt;const nx=clamp(p.x+dx,WORLD.minX+PLAYER.radius,WORLD.maxX-PLAYER.radius),nz=clamp(p.z+dz,WORLD.minZ+PLAYER.radius,WORLD.maxZ-PLAYER.radius);if(!pointBlocked(nx,p.z,PLAYER.radius))p.x=nx;if(!pointBlocked(p.x,nz,PLAYER.radius))p.z=nz;p.moveX=mx;p.moveZ=mz;p.speed=Math.hypot(vx,dzv);const wasAirborne=p.y>0.001||p.vy>0.001;if(input.jump&&p.y<=.001&&!input.crouch){p.vy=PLAYER.jump;}p.vy-=PLAYER.gravity*dt;p.y+=p.vy*dt;if(p.y<0){p.y=0;p.vy=0;}p.crouched=!!input.crouch;p.yaw=input.yaw;p.pitch=clamp(input.pitch,-1.45,1.45);const airborne=p.y>0.001||p.vy>0.001;setAnimationState(p,locomotionFor({alive:p.alive,speed:p.speed,sprint:sprinting,crouch:p.crouched,airborne}),now);advanceAnimation(p,dt,now);updateAction(p,now);}
export function updateReload(p,now){if(p.reloading&&now>=p.reloadAt){const w=WEAPONS[p.weapon],need=w.magazine-p.ammo,take=Math.min(need,p.reserve);p.ammo+=take;p.reserve-=take;syncWeaponState(p);p.reloading=false;updateAction(p,now);}if(p.alive&&p.reloading){setAnimationState(p,'reload',now);if(p.action!=='reload')triggerAction(p,'reload',now,Math.max(0,p.reloadAt-now));}else updateAction(p,now);}

export function segmentSmokeBlocked(x1,z1,x2,z2,smokeZones=[]){
 for(const s of smokeZones){
  if(!s||!Number.isFinite(s.x)||!Number.isFinite(s.z)||!Number.isFinite(s.radius)) continue;
  const dx=x2-x1,dz=z2-z1,len2=dx*dx+dz*dz;
  const t=len2>1e-9?clamp(((s.x-x1)*dx+(s.z-z1)*dz)/len2,0,1):0;
  const px=x1+dx*t,pz=z1+dz*t;
  if(Math.hypot(s.x-px,s.z-pz)<=s.radius)return true;
 }
 return false;
}

export function aimDirection(yaw,pitch){const cp=Math.cos(pitch);return {x:-Math.sin(yaw)*cp,y:Math.sin(pitch),z:-Math.cos(yaw)*cp};}
function raySphere(origin,dir,center,radius,maxDist){const ox=origin.x-center.x,oy=origin.y-center.y,oz=origin.z-center.z;const b=ox*dir.x+oy*dir.y+oz*dir.z;const c=ox*ox+oy*oy+oz*oz-radius*radius;const disc=b*b-c;if(disc<0)return null;const q=-b-Math.sqrt(disc);if(q>=0&&q<=maxDist)return q;const q2=-b+Math.sqrt(disc);return q2>=0&&q2<=maxDist?q2:null;}
function hitboxes(target){const crouch=target.crouched;return [
 {part:'head',center:{x:target.x,y:target.y+(crouch?1.15:1.47),z:target.z},radius:.23,mult:2},
 {part:'body',center:{x:target.x,y:target.y+(crouch?.68:.82),z:target.z},radius:.42,mult:1}
];}
function traceTarget(shooter,target,maxDist){const origin={x:shooter.x,y:shooter.y+(shooter.crouched?.95:PLAYER.eye),z:shooter.z};const dir=aimDirection(shooter.yaw,shooter.pitch);let best=null;for(const h of hitboxes(target)){const t=raySphere(origin,dir,h.center,h.radius,maxDist);if(t!==null&&(!best||t<best.t))best={...h,t};}return best;}
function syncWeaponState(p){p.weaponState??={};p.weaponState[p.weapon]??={ammo:p.ammo||0,reserve:p.reserve||0};p.weaponState[p.weapon].ammo=Math.max(0,Math.floor(p.ammo||0));p.weaponState[p.weapon].reserve=Math.max(0,Math.floor(p.reserve||0));}
function shotState(p){return {id:p.id,team:p.team,x:p.x,y:p.y,z:p.z,yaw:p.yaw,pitch:p.pitch,crouched:p.crouched,alive:p.alive,hp:p.hp,weapon:p.weapon,ammo:p.ammo,reserve:p.reserve,reloading:p.reloading,nextShot:p.nextShot};}
export function tryFire(shooter,players,now,{rewoundPlayers=null,smokeZones=[]}={}){
 if(!shooter.alive||shooter.reloading||now<shooter.nextShot||shooter.ammo<=0)return null;
 const w=WEAPONS[shooter.weapon];if(!w)return null;
 shooter.nextShot=now+w.fireInterval;shooter.ammo--;syncWeaponState(shooter);shooter.shotCount=(shooter.shotCount||0)+1;shooter.fireSeq=(shooter.fireSeq||0)+1;triggerAction(shooter,'fire',now,0.10);
 const aimShooter=rewoundPlayers?.get(shooter.id)||shooter;
 const dir=aimDirection(aimShooter.yaw,aimShooter.pitch),origin={x:aimShooter.x,y:aimShooter.y+(aimShooter.crouched?.95:PLAYER.eye),z:aimShooter.z};
 const baseSpread=w.id==='shotgun'?.055:w.id==='smg'?.012:w.id==='rifle'?.007:.01;let best=null;
 for(const liveTarget of players.values()){
  if(!liveTarget.alive||liveTarget.id===shooter.id||liveTarget.team===shooter.team)continue;
  const target=rewoundPlayers?.get(liveTarget.id)||liveTarget;
  if(!target.alive)continue;
  const dx=target.x-aimShooter.x,dz=target.z-aimShooter.z,dist=Math.hypot(dx,dz);if(dist>w.range)continue;
  if(segmentBlocked(aimShooter.x,aimShooter.z,target.x,target.z))continue;
  if(segmentSmokeBlocked(aimShooter.x,aimShooter.z,target.x,target.z,smokeZones))continue;
  const hit=traceTarget(aimShooter,target,w.range);if(!hit)continue;
  const lateral=Math.abs(dx*dir.z-dz*dir.x);if(lateral>PLAYER.radius+dist*Math.tan(baseSpread))continue;
  if(!best||hit.t<best.hit.t)best={target,liveTarget,hit};
 }
 const end={x:origin.x+dir.x*w.range,y:origin.y+dir.y*w.range,z:origin.z+dir.z*w.range};
 if(!best)return{type:'shot',shooter:shooter.id,weapon:w.id,spread:baseSpread,from:origin,to:end,fireSeq:shooter.fireSeq};
 const damage=w.damage*best.hit.mult;best.liveTarget.hp=Math.max(0,best.liveTarget.hp-damage);let killed=false;
 if(best.liveTarget.hp<=0){best.liveTarget.alive=false;best.liveTarget.status='DEAD';best.liveTarget.deaths++;best.liveTarget.lastKillerId=shooter.id;best.liveTarget.lastDeathAt=now;best.liveTarget.deathRound=0;shooter.score++;killed=true;}
 const to={x:origin.x+dir.x*best.hit.t,y:origin.y+dir.y*best.hit.t,z:origin.z+dir.z*best.hit.t};
 return{type:'hit',shooter:shooter.id,target:best.liveTarget.id,damage,part:best.hit.part,headshot:best.hit.part==='head',killed,weapon:w.id,spread:baseSpread,from:origin,to,fireSeq:shooter.fireSeq};
}
export function detonateGrenade(p,grenade,players,position={x:p.x,y:p.y+1.1,z:p.z},{smokeZones=[]}={}){
 const g=GRENADES[grenade];if(!g)return[];const events=[];
 if(grenade==='frag'){
  for(const t of players.values()){
   if(!t.alive||t.team===p.team)continue;
   const dx=t.x-position.x,dz=t.z-position.z,d=Math.hypot(dx,dz);if(d>g.radius)continue;
   if(segmentBlocked(position.x,position.z,t.x,t.z))continue;
   const damage=Math.max(0,Math.round(g.damage*(1-d/g.radius)));if(!damage)continue;
   t.hp=Math.max(0,t.hp-damage);let killed=false;
   if(t.hp<=0){t.alive=false;t.status='DEAD';t.deaths++;t.lastKillerId=p.id;t.lastDeathAt=Date.now()/1000;t.deathRound=0;p.score++;killed=true;events.push({type:'grenadeKill',target:t.id});}
   events.push({type:'grenadeDamage',target:t.id,damage,killed});
  }
 } else if(grenade==='flash'){
   for(const t of players.values()){
    if(!t.alive)continue;
    const dx=position.x-t.x,dz=position.z-t.z,d=Math.hypot(dx,dz);
    if(d>g.radius)continue;
    if(segmentBlocked(position.x,position.z,t.x,t.z))continue;
    if(segmentSmokeBlocked(position.x,position.z,t.x,t.z,smokeZones))continue;
    const inv=d>1e-6?1/d:0;
    const fx=-Math.sin(t.yaw),fz=-Math.cos(t.yaw);
    const facing=clamp((dx*fx+dz*fz)*inv,-1,1);
    const directional=0.35+0.65*Math.max(0,facing);
    const distance=Math.max(0,1-d/g.radius);
    const intensity=clamp(Math.round(100*distance*distance*directional)/100,0,1);
    if(intensity<=0)continue;
    events.push({type:'flash',owner:p.id,target:t.id,radius:g.radius,duration:Number((2.5*intensity).toFixed(2)),intensity});
   }
 }
 return events;
}
