export const AC = {
  MAX_SEQ_JUMP: 180,
  MAX_AIM_DELTA_PER_PACKET: Math.PI * 1.75,
  MAX_PITCH: 1.45,
  STRIKE_DECAY_SECONDS: 8,
  QUARANTINE_SCORE: 10,
  MAX_AUDIT_EVENTS: 64,
};

export function ensureAntiCheat(p) {
  if (!p._ac) p._ac = { score: 0, lastAt: 0, lastSeq: 0, lastYaw: null, lastPitch: null, events: [] };
  return p._ac;
}

function normalizeAngle(a) {
  let v = a % (Math.PI * 2);
  if (v > Math.PI) v -= Math.PI * 2;
  if (v < -Math.PI) v += Math.PI * 2;
  return v;
}

function strike(p, code, weight, now) {
  const ac = ensureAntiCheat(p);
  const elapsed = Math.max(0, now - ac.lastAt);
  ac.score = Math.max(0, ac.score - (elapsed / AC.STRIKE_DECAY_SECONDS) * 1);
  ac.score += weight;
  ac.lastAt = now;
  ac.events.push({ code, weight, at: now });
  if (ac.events.length > AC.MAX_AUDIT_EVENTS) ac.events.shift();
  return ac.score;
}

export function inspectInput(p, raw, now) {
  const ac = ensureAntiCheat(p);
  const result = { ok: true, score: ac.score, violations: [] };
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    result.ok = false; result.violations.push('INVALID_PACKET');
    result.score = strike(p, 'INVALID_PACKET', 5, now); return result;
  }
  if (Number.isInteger(raw.seq)) {
    if (raw.seq > ac.lastSeq && raw.seq - ac.lastSeq > AC.MAX_SEQ_JUMP) {
      result.ok = false; result.violations.push('SEQ_JUMP');
      result.score = strike(p, 'SEQ_JUMP', 3, now);
    }
    if (raw.seq > ac.lastSeq) ac.lastSeq = raw.seq;
  }
  if (Number.isFinite(raw.yaw)) {
    if (ac.lastYaw !== null && Math.abs(normalizeAngle(raw.yaw - ac.lastYaw)) > AC.MAX_AIM_DELTA_PER_PACKET) {
      result.violations.push('AIM_DELTA');
      result.score = strike(p, 'AIM_DELTA', 2, now);
    }
    ac.lastYaw = normalizeAngle(raw.yaw);
  }
  if (Number.isFinite(raw.pitch)) {
    if (Math.abs(raw.pitch) > AC.MAX_PITCH + 0.001) {
      result.ok = false; result.violations.push('PITCH_RANGE');
      result.score = strike(p, 'PITCH_RANGE', 3, now);
    }
    ac.lastPitch = raw.pitch;
  }
  result.quarantine = ac.score >= AC.QUARANTINE_SCORE;
  return result;
}

export function recordActionViolation(p, code, now, weight = 2) {
  const score = strike(p, code, weight, now);
  return { score, quarantine: score >= AC.QUARANTINE_SCORE };
}

export function antiCheatSnapshot(p) {
  const ac = ensureAntiCheat(p);
  return { score: Math.round(ac.score * 100) / 100, recentEvents: ac.events.slice(-8).map(e => ({ code: e.code, at: e.at })) };
}
