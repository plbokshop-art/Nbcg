import fs from 'node:fs';
import path from 'node:path';

export function acquireInstanceLock(dataRoot,{pid=process.pid}={}){
  fs.mkdirSync(dataRoot,{recursive:true});
  const file=path.join(dataRoot,'.server.lock');
  const payload=JSON.stringify({pid,startedAt:new Date().toISOString()});
  for(let attempt=0;attempt<2;attempt++){
    try{
      const fd=fs.openSync(file,'wx');
      fs.writeFileSync(fd,payload,{encoding:'utf8'});
      fs.closeSync(fd);
      let released=false;
      return {file,release(){if(released)return;released=true;try{fs.unlinkSync(file);}catch(err){if(err.code!=='ENOENT')throw err;}}};
    }catch(err){
      if(err.code!=='EEXIST')throw err;
      let owner=null;
      try{owner=JSON.parse(fs.readFileSync(file,'utf8'));}catch{}
      const ownerPid=Number(owner?.pid);
      let alive=false;
      if(Number.isInteger(ownerPid)&&ownerPid>0){if(ownerPid===process.pid)alive=true;else{try{process.kill(ownerPid,0);alive=true;}catch(e){alive=e.code==='EPERM';}}}
      if(alive)throw new Error(`data directory already locked by server pid ${ownerPid}`);
      try{fs.unlinkSync(file);}catch(e){if(e.code!=='ENOENT')throw e;}
    }
  }
  throw new Error('unable to acquire data directory lock');
}
