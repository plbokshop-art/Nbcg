export const ECONOMY={MAX_LEDGER:128,MAX_AMOUNT:1000000};
function normalizeAmount(amount){return Number.isSafeInteger(amount)&&amount>0&&amount<=ECONOMY.MAX_AMOUNT?amount:null;}
export function ensureWallet(p){
  if(!p.wallet||typeof p.wallet!=='object')p.wallet={balance:Number.isSafeInteger(p.money)&&p.money>=0?p.money:0,version:0,ledger:[]};
  if(!Array.isArray(p.wallet.ledger))p.wallet.ledger=[];
  if(!Number.isSafeInteger(p.wallet.version)||p.wallet.version<0)p.wallet.version=0;
  if(p.wallet.version===0&&p.wallet.ledger.length===0&&Number.isSafeInteger(p.money)&&p.money>=0)p.wallet.balance=p.money;
  if(p.money!==p.wallet.balance)p.money=p.wallet.balance;
  return p.wallet;
}
function findTx(wallet,id){return id?wallet.ledger.find(t=>t.id===id):null;}
function append(wallet,tx){wallet.version++;wallet.ledger.push({...tx,version:wallet.version});if(wallet.ledger.length>ECONOMY.MAX_LEDGER)wallet.ledger.splice(0,wallet.ledger.length-ECONOMY.MAX_LEDGER);return wallet.ledger.at(-1);}
export function walletDebit(p,amount,{id,reason='debit',item=null}={}){
  const value=normalizeAmount(amount);if(!value)return {ok:false,error:'INVALID_AMOUNT'};
  const wallet=ensureWallet(p);const existing=findTx(wallet,id);if(existing)return existing;
  if(wallet.balance<value)return {ok:false,error:'INSUFFICIENT_FUNDS'};
  wallet.balance-=value;p.money=wallet.balance;
  return {ok:true,...append(wallet,{id:id||`${p.id}:tx:${wallet.version+1}`,type:'DEBIT',amount:value,balance:wallet.balance,reason,item})};
}
export function walletCredit(p,amount,{id,reason='credit',item=null}={}){
  const value=normalizeAmount(amount);if(!value)return {ok:false,error:'INVALID_AMOUNT'};
  const wallet=ensureWallet(p);const existing=findTx(wallet,id);if(existing)return existing;
  if(wallet.balance+value>Number.MAX_SAFE_INTEGER)return {ok:false,error:'BALANCE_OVERFLOW'};
  wallet.balance+=value;p.money=wallet.balance;
  return {ok:true,...append(wallet,{id:id||`${p.id}:tx:${wallet.version+1}`,type:'CREDIT',amount:value,balance:wallet.balance,reason,item})};
}
export function walletTransactions(p){return [...ensureWallet(p).ledger];}
