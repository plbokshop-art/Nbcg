export const INVENTORY={MAX_ENTRIES:128,MAX_GRANT:16,MAX_STACK:999};

function validId(id){return typeof id==='string'&&/^[a-z0-9._:-]{1,96}$/i.test(id);}
function ensureShape(p){
  if(!p.inventory||typeof p.inventory!=='object')p.inventory={weapons:['pistol'],grenades:[]};
  if(!Array.isArray(p.inventory.weapons))p.inventory.weapons=[];
  if(!Array.isArray(p.inventory.grenades))p.inventory.grenades=[];
  return p.inventory;
}
export function ensureInventory(p){
  const inv=ensureShape(p);
  inv.weapons=[...new Set(inv.weapons.filter(validId))].slice(0,INVENTORY.MAX_ENTRIES);
  inv.grenades=inv.grenades.filter(validId).slice(0,INVENTORY.MAX_ENTRIES);
  if(!inv.weapons.includes('pistol'))inv.weapons.unshift('pistol');
  return inv;
}
export function ownsWeapon(p,id){return validId(id)&&ensureInventory(p).weapons.includes(id);}
export function grantWeapon(p,id){if(!validId(id))return false;const inv=ensureInventory(p);if(inv.weapons.includes(id))return false;if(inv.weapons.length>=INVENTORY.MAX_ENTRIES)return false;inv.weapons.push(id);return true;}
export function addGrenade(p,id,count=1){if(!validId(id)||!Number.isSafeInteger(count)||count<1||count>INVENTORY.MAX_GRANT)return false;const inv=ensureInventory(p);if(inv.grenades.length+count>INVENTORY.MAX_STACK)return false;for(let i=0;i<count;i++)inv.grenades.push(id);return true;}
export function consumeGrenade(p,id){const inv=ensureInventory(p);const i=inv.grenades.indexOf(id);if(i<0)return false;inv.grenades.splice(i,1);return true;}
export function grenadeCount(p,id){return ensureInventory(p).grenades.reduce((n,x)=>n+(x===id?1:0),0);}
export function inventorySnapshot(p){const inv=ensureInventory(p);return {weapons:[...inv.weapons],grenades:[...inv.grenades]};}
