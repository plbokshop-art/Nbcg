import fs from 'node:fs';
import path from 'node:path';

function readRecords(file,validate){
  const raw=JSON.parse(fs.readFileSync(file,'utf8'));
  if(!Array.isArray(raw))throw new Error('persistence root must be an array');
  return new Map(raw.filter(validate).map(value=>[value.id,value]));
}

export function createJsonRepository(file,{validate=()=>true}={}){
  let records=new Map();
  let dirty=false;
  let recoveredFromBackup=false;
  const backup=`${file}.bak`;
  function load(){
    recoveredFromBackup=false;
    if(!fs.existsSync(file)){
      if(fs.existsSync(backup)){
        try{records=readRecords(backup,validate);recoveredFromBackup=true;dirty=true;return records;}catch(backupError){throw new Error(`persistence recovery failed for ${file}: primary=missing; backup=${backupError.message}`);}}
      records=new Map();
      dirty=false;
      return records;
    }
    try{
      records=readRecords(file,validate);
      return records;
    }catch(primaryError){
      try{
        records=readRecords(backup,validate);
        recoveredFromBackup=true;
        dirty=true;
        return records;
      }catch(backupError){
        records=new Map();
        dirty=false;
        throw new Error(`persistence recovery failed for ${file}: primary=${primaryError.message}; backup=${backupError.message}`);
      }
    }
  }
  function all(){return records.values();}
  function get(id){return records.get(id)||null;}
  function set(value){if(!value||!value.id)throw new Error('invalid persistence record');records.set(value.id,value);dirty=true;}
  function deleteRecord(id){const removed=records.delete(id);if(removed)dirty=true;return removed;}
  function save(){
    if(!dirty&&fs.existsSync(file))return;
    fs.mkdirSync(path.dirname(file),{recursive:true});
    const tmp=`${file}.tmp`;
    const data=JSON.stringify([...records.values()]);
    const fd=fs.openSync(tmp,'w');
    try{
      fs.writeFileSync(fd,data,{encoding:'utf8'});
      fs.fsyncSync(fd);
    }finally{fs.closeSync(fd);}
    if(fs.existsSync(file) && !recoveredFromBackup)fs.copyFileSync(file,backup);
    fs.renameSync(tmp,file);
    try{const dirFd=fs.openSync(path.dirname(file),'r');try{fs.fsyncSync(dirFd);}finally{fs.closeSync(dirFd);}}catch{}
    dirty=false;
    recoveredFromBackup=false;
  }
  return {load,all,get,set,delete:deleteRecord,save,get dirty(){return dirty;},get recoveredFromBackup(){return recoveredFromBackup;},backupFile:backup};
}
