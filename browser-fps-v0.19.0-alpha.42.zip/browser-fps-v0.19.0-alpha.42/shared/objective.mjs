import { zoneAt } from './map.mjs';

export const OBJECTIVE = Object.freeze({
  PLANT_TIME: 3,
  DETONATION_TIME: 35,
  DEFUSE_TIME: 5,
  INTERACT_RADIUS: 2.25,
  PICKUP_RADIUS: 1.75,
  BOMB_ID: 'vanguard-device'
});

export function objectiveState({round=1,carrierId=null}={}){
  return { attacker: round%2 ? 'blue' : 'red', carrierId, dropped:false, dropX:0, dropZ:0, site:null, status:'NONE', plantedAt:0, detonateAt:0, defuseAt:0, plantBy:null, defuseBy:null, x:0, z:0 };
}
export function isAttacker(player,obj){return !!player&&player.team===obj.attacker;}
export function siteAt(x,z){const zone=zoneAt(x,z);return zone?.objective?zone:null;}
export function carrierHasDevice(player,obj){return isAttacker(player,obj)&&obj.carrierId===player.id&&!obj.dropped;}
export function canPlant(player,obj,now){
  const site=siteAt(player.x,player.z);
  return carrierHasDevice(player,obj)&&obj.status==='NONE'&&!!site&&player.alive&&player.status==='ALIVE'&&now>=0;
}
export function canDefuse(player,obj){
  return !isAttacker(player,obj)&&obj.status==='PLANTED'&&player.alive&&player.status==='ALIVE'&&obj.site&&siteAt(player.x,player.z)?.id===obj.site&&Math.hypot(player.x-(obj.x??player.x),player.z-(obj.z??player.z))<=OBJECTIVE.INTERACT_RADIUS;
}
export function startPlant(obj,player,now){if(!canPlant(player,obj,now))return false;obj.status='PLANTING';obj.site=siteAt(player.x,player.z).id;obj.plantedAt=now;obj.plantBy=player.id;obj.defuseBy=null;obj.x=player.x;obj.z=player.z;return true;}
export function cancelPlant(obj,player){if(obj.status!=='PLANTING'||obj.plantBy!==player.id)return false;obj.status='NONE';obj.plantBy=null;obj.site=null;obj.plantedAt=0;return true;}
export function interruptPlant(obj,player){if(obj.status!=='PLANTING'||obj.plantBy!==player.id)return false;obj.status='NONE';obj.plantBy=null;obj.site=null;obj.plantedAt=0;obj.dropped=true;obj.dropX=Number.isFinite(player.x)?player.x:obj.x;obj.dropZ=Number.isFinite(player.z)?player.z:obj.z;obj.carrierId=null;return true;}
export function completePlant(obj,now){if(obj.status!=='PLANTING')return false;obj.status='PLANTED';obj.plantedAt=now;obj.detonateAt=now+OBJECTIVE.DETONATION_TIME;obj.plantBy=null;obj.carrierId=null;obj.dropped=false;return true;}
export function startDefuse(obj,player,now){if(!canDefuse(player,obj))return false;obj.defuseBy=player.id;obj.defuseAt=now+OBJECTIVE.DEFUSE_TIME;return true;}
export function cancelDefuse(obj,player){if(obj.defuseBy!==player.id)return false;obj.defuseBy=null;obj.defuseAt=0;return true;}
export function dropDevice(obj,player){if(obj.status!=='NONE'||obj.carrierId!==player.id)return false;obj.dropped=true;obj.dropX=player.x;obj.dropZ=player.z;obj.carrierId=null;return true;}
export function canPickup(player,obj){return isAttacker(player,obj)&&obj.status==='NONE'&&obj.dropped&&player.alive&&player.status==='ALIVE'&&Math.hypot(player.x-obj.dropX,player.z-obj.dropZ)<=OBJECTIVE.PICKUP_RADIUS;}
export function pickupDevice(obj,player){if(!canPickup(player,obj))return false;obj.carrierId=player.id;obj.dropped=false;return true;}
export function resolveObjective(obj,players,now){
  if(obj.status==='PLANTED'&&now>=obj.detonateAt){obj.status='DETONATED';return 'detonation';}
  if(obj.status==='PLANTED'&&obj.defuseBy){const p=players.get(obj.defuseBy);if(!p||!canDefuse(p,obj)){obj.defuseBy=null;obj.defuseAt=0;}else if(now>=obj.defuseAt){obj.status='DEFUSED';obj.defuseBy=null;return 'defuse';}}
  return null;
}
export function objectiveWinner(obj){if(obj.status==='DETONATED')return obj.attacker;if(obj.status==='DEFUSED')return obj.attacker==='blue'?'red':'blue';return null;}
export function objectiveTimeWinner(obj){if(obj.status==='PLANTED'||obj.status==='DETONATED')return obj.attacker;if(obj.status==='DEFUSED')return obj.attacker==='blue'?'red':'blue';return obj.attacker==='blue'?'red':'blue';}
