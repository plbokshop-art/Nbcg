import { MATERIALS } from './materials.mjs';
export const MAP = {
  name: 'Vanguard District',
  bounds: { minX: -24, maxX: 24, minZ: -18, maxZ: 18 },
  zones: [
    {id:'spawn_blue',name:'Blue Spawn',minX:-22,maxX:-12,minZ:-5,maxZ:5,team:'blue'},
    {id:'spawn_red',name:'Red Spawn',minX:12,maxX:22,minZ:-5,maxZ:5,team:'red'},
    {id:'mid',name:'Mid',minX:-7,maxX:7,minZ:-8,maxZ:8},
    {id:'site_a',name:'Site A',minX:-18,maxX:-7,minZ:-14,maxZ:-4,objective:true},
    {id:'site_b',name:'Site B',minX:7,maxX:18,minZ:4,maxZ:14,objective:true}
  ],
  spawns: {
    blue: [{x:-20,z:-3},{x:-20,z:0},{x:-20,z:3},{x:-18,z:-3},{x:-18,z:3}],
    red: [{x:20,z:-3},{x:20,z:0},{x:20,z:3},{x:18,z:-3},{x:18,z:3}]
  },
  cover: [
    {id:'mid_wall',x:0,z:0,w:5,d:.8,h:2.8,material:'concrete'},
    {id:'a_left',x:-9,z:-7,w:3.5,d:3.5,h:2.4,material:'concrete'},
    {id:'a_right',x:9,z:-7,w:3.5,d:3.5,h:2.4,material:'concrete'},
    {id:'b_left',x:-9,z:7,w:3.5,d:3.5,h:2.4,material:'concrete'},
    {id:'b_right',x:9,z:7,w:3.5,d:3.5,h:2.4,material:'concrete'},
    {id:'north_lane',x:-15,z:0,w:2.2,d:7,h:2.2,material:'metal'},
    {id:'south_lane',x:15,z:0,w:2.2,d:7,h:2.2,material:'metal'}
  ],
  doors: [
    {id:'a_gate',x:-7,z:-1,w:1.0,d:4.0,h:2.8,open:false,material:'metal'},
    {id:'b_gate',x:7,z:1,w:1.0,d:4.0,h:2.8,open:false,material:'metal'}
  ],
  lighting: {ambient:[0.16,0.19,0.23],sun:[0.78,0.84,1.0],direction:[-0.45,-0.9,-0.35]},
  materials: {
    floor:[0.10,0.13,0.15,1], concrete:[0.27,0.29,0.31,1], metal:[0.20,0.24,0.28,1], door:[0.12,0.16,0.20,1], siteA:[0.24,0.18,0.10,1], siteB:[0.10,0.18,0.24,1]
  }
};
export const MAP_WALLS = [
  {id:'north',x:0,z:-18,w:48,d:.5,h:4,material:'concrete'}, {id:'south',x:0,z:18,w:48,d:.5,h:4,material:'concrete'},
  {id:'west',x:-24,z:0,w:.5,d:36,h:4,material:'concrete'}, {id:'east',x:24,z:0,w:.5,d:36,h:4,material:'concrete'},
  ...MAP.cover,
  ...MAP.doors.filter(d=>!d.open)
];
export function aabb(o){return {minX:o.x-o.w/2,maxX:o.x+o.w/2,minZ:o.z-o.d/2,maxZ:o.z+o.d/2};}
export function pointBlocked(x,z,r=.35,walls=MAP_WALLS){for(const o of walls){const b=aabb(o);const cx=Math.max(b.minX,Math.min(x,b.maxX)),cz=Math.max(b.minZ,Math.min(z,b.maxZ));if(Math.hypot(x-cx,z-cz)<r)return o;}return null;}
export function segmentBlocked(x1,z1,x2,z2,walls=MAP_WALLS){const steps=Math.max(1,Math.ceil(Math.hypot(x2-x1,z2-z1)*12));for(let i=1;i<=steps;i++){const t=i/steps;if(pointBlocked(x1+(x2-x1)*t,z1+(z2-z1)*t,.02,walls))return true;}return false;}
export function zoneAt(x,zPos){return MAP.zones.find(zone=>x>=zone.minX&&x<=zone.maxX&&zPos>=zone.minZ&&zPos<=zone.maxZ)||null;}
export function spawnPoints(team){return MAP.spawns[team]||[];}
export function isSpawnSafe(x,z,r=.35){return !pointBlocked(x,z,r);}
