import {RATING,updateRating,teamAverage} from './rating.mjs';

export const COMPETITIVE=Object.freeze({LEADERBOARD_LIMIT:100,RECENT_MATCH_WINDOW:10,REPEAT_SOFT_CAP:3,REPEAT_HARD_CAP:5,SOFT_K:16,HARD_K:8,PLACEMENT_K:48,PLACEMENT_MATCHES:5,PARTY_MIX_LIMIT:800,ABANDON_GRACE_MS:15000,ABANDON_PENALTY:16,INTEGRITY_MAX:100,INTEGRITY_DECAY_PER_MATCH:4,INTEGRITY_FLAG_CAP:20});

export function recentOpponentCount(account,opponentIds,limit=COMPETITIVE.RECENT_MATCH_WINDOW){
  if(!account||!Array.isArray(account.matchHistory)||!opponentIds?.size)return 0;
  const ids=new Set(opponentIds); let count=0;
  for(const match of account.matchHistory.slice(0,limit)){
    if(Array.isArray(match.opponents)&&match.opponents.some(id=>ids.has(id)))count++;
  }
  return count;
}

export function ratingKForMatch(account,opponentIds,baseK=RATING.K){
  const placement=account&&Number.isFinite(Number(account.placementGames))?Number(account.placementGames):(account?.stats&&Number.isFinite(Number(account.stats.matchesPlayed))?Number(account.stats.matchesPlayed):COMPETITIVE.PLACEMENT_MATCHES);
  const provisionalK=placement<COMPETITIVE.PLACEMENT_MATCHES?Math.max(baseK,COMPETITIVE.PLACEMENT_K):baseK;
  const repeats=recentOpponentCount(account,opponentIds);
  if(repeats>=COMPETITIVE.REPEAT_HARD_CAP)return Math.min(provisionalK,COMPETITIVE.HARD_K);
  if(repeats>=COMPETITIVE.REPEAT_SOFT_CAP)return Math.min(provisionalK,COMPETITIVE.SOFT_K);
  return provisionalK;
}

export function applyCompetitiveRatings(players,accounts,winner,k=RATING.K){
  const blue=players.filter(p=>p.team==='blue'),red=players.filter(p=>p.team==='red');
  const br=teamAverage(blue),rr=teamAverage(red);
  for(const p of players){
    const account=accounts?.get(p.accountId);
    const opponents=new Set(players.filter(x=>x.team!==p.team).map(x=>x.accountId));
    const effectiveK=ratingKForMatch(account,opponents,k);
    const score=winner===null?.5:winner===p.team?1:0;
    p.rating=updateRating(p.rating,p.team==='blue'?rr:br,score,effectiveK);
    p.ratingK=effectiveK;
  }
  return {blue:Math.round(teamAverage(blue)),red:Math.round(teamAverage(red))};
}

export function buildLeaderboard(accounts,limit=COMPETITIVE.LEADERBOARD_LIMIT){
  const rows=[...accounts].filter(a=>a&&typeof a.id==='string').map(a=>({
    id:a.id,displayName:a.displayName,rating:Number.isFinite(a.rating)?a.rating:RATING.DEFAULT,
    matchesPlayed:Number(a.stats?.matchesPlayed)||0,matchesWon:Number(a.stats?.matchesWon)||0
  }));
  rows.sort((a,b)=>b.rating-a.rating||b.matchesWon-a.matchesWon||b.matchesPlayed-a.matchesPlayed||a.id.localeCompare(b.id));
  return rows.slice(0,Math.max(1,Math.min(COMPETITIVE.LEADERBOARD_LIMIT,Number(limit)||COMPETITIVE.LEADERBOARD_LIMIT)))
    .map((row,index)=>({...row,rank:index+1}));
}

export function partyEffectiveRating(entries){
  if(!Array.isArray(entries)||!entries.length)return RATING.DEFAULT;
  const ratings=entries.map(e=>Math.max(RATING.MIN,Math.min(RATING.MAX,Number(e.rating)||RATING.DEFAULT)));
  const avg=ratings.reduce((a,b)=>a+b,0)/ratings.length;
  const max=Math.max(...ratings);
  const min=Math.min(...ratings);
  const spread=max-min;
  if(spread>=COMPETITIVE.PARTY_MIX_LIMIT)return max;
  return Math.round(avg+spread*0.5);
}

export function isPlacementAccount(account){
  return (Number(account?.placementGames)||Number(account?.stats?.matchesPlayed)||0)<COMPETITIVE.PLACEMENT_MATCHES;
}

export function isConfirmedAbandonment(player){return !!player?.abandoned;}
export function integrityAdjustment(player){return isConfirmedAbandonment(player)?-COMPETITIVE.ABANDON_PENALTY:0;}


export function ensureCompetitiveIntegrity(account){
  if(!account) return null;
  if(!account.competitiveIntegrity||typeof account.competitiveIntegrity!=='object') account.competitiveIntegrity={riskScore:0,flags:[],updatedAt:0};
  const c=account.competitiveIntegrity;
  c.riskScore=Math.max(0,Math.min(COMPETITIVE.INTEGRITY_MAX,Number(c.riskScore)||0));
  c.flags=Array.isArray(c.flags)?c.flags.slice(0,COMPETITIVE.INTEGRITY_FLAG_CAP):[];
  c.updatedAt=Number(c.updatedAt)||0;
  return c;
}

export function detectCompetitiveAbuse(account,{opponents=[],teamRatings=[],opponentRatings=[],winner=false,abandoned=false}={}){
  const reasons=[]; let score=0;
  const ids=new Set(Array.isArray(opponents)?opponents.filter(x=>typeof x==='string'):[]);
  const repeats=recentOpponentCount(account,ids);
  if(repeats>=COMPETITIVE.REPEAT_HARD_CAP){score+=35;reasons.push('REPEATED_OPPONENTS_HIGH');}
  else if(repeats>=COMPETITIVE.REPEAT_SOFT_CAP){score+=15;reasons.push('REPEATED_OPPONENTS');}
  const my=Number(account?.rating)||RATING.DEFAULT;
  const enemyAvg=Array.isArray(opponentRatings)&&opponentRatings.length?opponentRatings.reduce((a,b)=>a+(Number(b)||RATING.DEFAULT),0)/opponentRatings.length:my;
  const gap=Math.abs(my-enemyAvg);
  if(gap>=500){score+=15;reasons.push('LARGE_RATING_GAP');}
  if(abandoned){score+=20;reasons.push('ABANDONED_MATCH');}
  if(repeats>=COMPETITIVE.REPEAT_SOFT_CAP && winner && gap>=300){score+=15;reasons.push('REPEATED_UPSET_PATTERN');}
  return {score:Math.min(COMPETITIVE.INTEGRITY_MAX,score),reasons};
}

export function recordCompetitiveIntegrity(account,signal){
  const c=ensureCompetitiveIntegrity(account); if(!c)return null;
  c.riskScore=Math.max(0,Math.min(COMPETITIVE.INTEGRITY_MAX,c.riskScore-COMPETITIVE.INTEGRITY_DECAY_PER_MATCH+(Number(signal?.score)||0)));
  if(Array.isArray(signal?.reasons)&&signal.reasons.length){c.flags.unshift({at:Date.now(),settlementId:typeof signal?.settlementId==='string'?signal.settlementId:null,score:Number(signal.score)||0,reasons:signal.reasons.slice(0,8)});if(c.flags.length>COMPETITIVE.INTEGRITY_FLAG_CAP)c.flags.length=COMPETITIVE.INTEGRITY_FLAG_CAP;}
  c.updatedAt=Date.now();
  return c;
}

export function competitiveIntegritySnapshot(account){const c=ensureCompetitiveIntegrity(account);return c?{riskScore:c.riskScore,flags:c.flags.length,updatedAt:c.updatedAt}:null;}

export function buildIntegrityReport(accounts,limit=50){
  const rows=[];
  for(const a of accounts||[]){
    const c=ensureCompetitiveIntegrity(a);
    if(!c||c.riskScore<=0) continue;
    rows.push({accountId:a.id,riskScore:c.riskScore,flags:c.flags.length,matchesAbandoned:Number(a.stats?.matchesAbandoned)||0,matchesPlayed:Number(a.stats?.matchesPlayed)||0});
  }
  rows.sort((a,b)=>b.riskScore-a.riskScore||b.flags-a.flags||a.accountId.localeCompare(b.accountId));
  return rows.slice(0,Math.max(1,Math.min(100,Number(limit)||limit)));
}
