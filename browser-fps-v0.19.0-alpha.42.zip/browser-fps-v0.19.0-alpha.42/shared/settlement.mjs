import crypto from 'node:crypto';

export function settlementKey(matchId,result){
  if(typeof matchId!=='string'||!matchId) throw new Error('invalid match id');
  const canonical=JSON.stringify({matchId,winner:result?.winner??null,score:{blue:Number(result?.score?.blue)||0,red:Number(result?.score?.red)||0},round:Number(result?.round)||0});
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

export function createSettlementGuard(records=[]){
  const settled=new Set(records.map(r=>typeof r==='string'?r:r?.id).filter(Boolean));
  return {
    has(key){return settled.has(String(key));},
    mark(key){const k=String(key);if(settled.has(k))return false;settled.add(k);return true;},
    size(){return settled.size;},
    clear(){settled.clear();}
  };
}

export function settlementRecord(key,{matchId,result,status='PREPARED',participants=[]}={}){
  return {id:String(key),matchId:String(matchId),result:result||null,status,participants:Array.isArray(participants)?participants.map(p=>({accountId:String(p.accountId),team:p.team==='red'?'red':'blue',ratingBefore:Number(p.ratingBefore)||1000,ratingAfter:Number(p.ratingAfter)||1000,ratingK:Number(p.ratingK)||32,abandoned:!!p.abandoned,integrityScore:Number(p.integrityScore)||0,integrityReasons:Array.isArray(p.integrityReasons)?p.integrityReasons.slice(0,8):[],opponents:Array.isArray(p.opponents)?p.opponents.map(String).slice(0,16):[]})):[],updatedAt:Date.now()};
}

export function validateSettlementRecord(r){
  return !!r&&typeof r.id==='string'&&/^[a-f0-9]{64}$/.test(r.id)&&typeof r.matchId==='string'&&['PREPARED','COMPLETED'].includes(r.status)&&Array.isArray(r.participants)&&r.participants.length<=10&&r.participants.every(p=>p&&typeof p.accountId==='string'&&Number.isFinite(Number(p.ratingBefore))&&Number.isFinite(Number(p.ratingAfter)));
}
