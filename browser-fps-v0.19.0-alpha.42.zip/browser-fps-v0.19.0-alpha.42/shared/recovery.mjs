import crypto from 'node:crypto';

export const RECOVERY_VERSION = 1;
export const RECOVERY_MAX_BYTES = 1024 * 1024;

function finite(n,fallback=0){return Number.isFinite(Number(n))?Number(n):fallback;}
function safePlayer(p){
  return {
    id:String(p.id),accountId:typeof p.accountId==='string'?p.accountId:null,team:p.team,
    x:finite(p.x),y:finite(p.y),z:finite(p.z),yaw:finite(p.yaw),pitch:finite(p.pitch),vy:finite(p.vy),
    hp:finite(p.hp,100),alive:!!p.alive,status:p.status||'ALIVE',crouched:!!p.crouched,
    money:Math.max(0,Math.floor(finite(p.money))),inventory:p.inventory||{weapons:['pistol'],grenades:[]},
    wallet:p.wallet||{balance:Math.max(0,Math.floor(finite(p.money))),version:0,ledger:[]},weapon:p.weapon||'pistol',weaponState:p.weaponState||{},
    ammo:Math.max(0,Math.floor(finite(p.ammo))),reserve:Math.max(0,Math.floor(finite(p.reserve))),
    reloading:!!p.reloading,reloadAt:finite(p.reloadAt),nextShot:finite(p.nextShot),score:Math.max(0,Math.floor(finite(p.score))),
    deaths:Math.max(0,Math.floor(finite(p.deaths))),shotCount:Math.max(0,Math.floor(finite(p.shotCount))),fireSeq:Math.max(0,Math.floor(finite(p.fireSeq))),
    moveX:finite(p.moveX),moveZ:finite(p.moveZ),speed:Math.max(0,finite(p.speed)),matchId:p.matchId||null,round:Math.max(1,Math.floor(finite(p.round,1))),
    abandoned:!!p.abandoned,preDisconnectAlive:!!p._preDisconnectAlive,preDisconnectStatus:p._preDisconnectStatus||'ALIVE',sessionToken:typeof p.sessionToken==='string'?p.sessionToken:null
  };
}
export function buildRecoverySnapshot({activeMatch,phase,phaseEnds,round,score,gameTime,players,grenades,smokeZones=new Map(),objective=null}){
  if(!activeMatch)return null;
  return {
    version:RECOVERY_VERSION,savedAt:Date.now(),gameTime:finite(gameTime),phase,phaseEnds:finite(phaseEnds),round:Math.max(1,Math.floor(finite(round,1))),score:{blue:Math.max(0,Math.floor(finite(score?.blue))),red:Math.max(0,Math.floor(finite(score?.red)))},
    activeMatch:JSON.parse(JSON.stringify(activeMatch)),players:[...players.values()].filter(p=>p.matchId===activeMatch.id).map(safePlayer),
    grenades:[...grenades.values()].map(g=>({id:String(g.id),owner:String(g.owner),type:String(g.type),x:finite(g.x),y:finite(g.y),z:finite(g.z),vx:finite(g.vx),vy:finite(g.vy),vz:finite(g.vz),detonateAt:finite(g.detonateAt)})),
    smokeZones:[...smokeZones.values()].map(s=>({id:String(s.id),x:finite(s.x),y:finite(s.y),z:finite(s.z),radius:Math.max(0,finite(s.radius)),expiresAt:finite(s.expiresAt)})),
    objective:objective?JSON.parse(JSON.stringify(objective)):null
  };
}
export function validateRecoverySnapshot(s){
  if(!s||s.version!==RECOVERY_VERSION||typeof s.activeMatch?.id!=='string')return false;
  if(!['BUY','LIVE','POST','LOBBY'].includes(s.phase)||!Array.isArray(s.activeMatch.players)||!Array.isArray(s.players)||!Array.isArray(s.grenades))return false;
  if(s.smokeZones!==undefined&&!Array.isArray(s.smokeZones))return false;if(s.objective!==undefined&&s.objective!==null&&typeof s.objective!=='object')return false;
  if(s.players.length>10||s.grenades.length>32||((s.smokeZones||[]).length>16))return false;
  if(!s.players.every(p=>typeof p.id==='string'&&typeof p.accountId==='string'&&typeof p.sessionToken==='string'&&p.sessionToken.length>=16&&['blue','red'].includes(p.team)))return false;
  const ids=new Set(s.players.map(p=>p.id));
  if(ids.size!==s.players.length)return false;
  return Number.isFinite(s.gameTime)&&Number.isFinite(s.phaseEnds)&&Number.isFinite(s.round)&&s.round>=1&&Number.isFinite(s.score?.blue)&&Number.isFinite(s.score?.red);
}
export function recoveryDigest(snapshot){return crypto.createHash('sha256').update(JSON.stringify(snapshot)).digest('hex');}
export function recoveryRecord(snapshot){if(!snapshot)return null;const base={...snapshot,id:'active'};return {...base,digest:recoveryDigest(base)};}
export function verifyRecoveryRecord(record){if(!record||typeof record.digest!=='string')return false;const {digest,...snapshot}=record;return recoveryDigest(snapshot)===digest&&validateRecoverySnapshot(snapshot);}
