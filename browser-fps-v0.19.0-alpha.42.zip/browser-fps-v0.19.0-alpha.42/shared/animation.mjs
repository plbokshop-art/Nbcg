export const ANIMATION = Object.freeze({
  idle: { cycle: 0, amplitude: 0 },
  walk: { cycle: 7.5, amplitude: 0.55 },
  run: { cycle: 10.0, amplitude: 0.82 },
  crouch: { cycle: 0, amplitude: 0 },
  crouch_walk: { cycle: 6.0, amplitude: 0.38 },
  jump: { cycle: 0, amplitude: 0 },
  reload: { cycle: 0, amplitude: 0 },
  dead: { cycle: 0, amplitude: 0 }
});

export const ACTIONS = Object.freeze({ idle:'idle', fire:'fire', reload:'reload', hurt:'hurt', dead:'dead' });

export function locomotionFor({alive=true, speed=0, sprint=false, crouch=false, airborne=false}={}) {
  if (!alive) return 'dead';
  if (airborne) return 'jump';
  if (crouch) return speed > 0.1 ? 'crouch_walk' : 'crouch';
  if (speed > 0.1) return sprint ? 'run' : 'walk';
  return 'idle';
}

export function setAnimationState(p, state, now=0) {
  const next = ANIMATION[state] ? state : 'idle';
  if (p.anim !== next) {
    p.anim = next;
    p.animTime = now;
    p.animCycle = 0;
  }
  return p.anim;
}

export function advanceAnimation(p, dt=0, now=0) {
  const state = ANIMATION[p.anim] ? p.anim : 'idle';
  if (p.animTime === undefined) p.animTime = now;
  if (p.animCycle === undefined) p.animCycle = 0;
  const cycle = ANIMATION[state].cycle;
  p.animCycle = cycle > 0 ? (p.animCycle + dt * cycle) % (Math.PI * 2) : 0;
  return p.animCycle;
}

export function triggerAction(p, action, now=0, duration=0.12) {
  p.action = ACTIONS[action] ? action : 'idle';
  p.actionTime = now;
  p.actionUntil = now + Math.max(0, duration);
  return p.action;
}

export function updateAction(p, now=0) {
  if (!p.alive) { p.action='dead'; return p.action; }
  if (p.action && p.action !== 'idle' && now >= (p.actionUntil ?? 0)) p.action='idle';
  return p.action || 'idle';
}
