// Central material library. Values are linear-ish display-space constants for the lightweight WebGL renderer.
export const MATERIALS = Object.freeze({
  floor:     { baseColor:[0.095,0.115,0.135,1], roughness:.92, metallic:.02, emissive:[0,0,0], pattern:1 },
  concrete:  { baseColor:[0.25,0.27,0.29,1], roughness:.86, metallic:.04, emissive:[0,0,0], pattern:2 },
  metal:     { baseColor:[0.18,0.22,0.26,1], roughness:.34, metallic:.72, emissive:[0,0,0], pattern:3 },
  door:      { baseColor:[0.10,0.14,0.18,1], roughness:.28, metallic:.78, emissive:[0,0,0], pattern:3 },
  siteA:     { baseColor:[0.30,0.18,0.075,1], roughness:.55, metallic:.08, emissive:[0.09,0.025,0], pattern:4 },
  siteB:     { baseColor:[0.055,0.16,0.29,1], roughness:.50, metallic:.10, emissive:[0,0.035,0.11], pattern:4 },
  teamBlue:  { baseColor:[0.07,0.32,0.82,1], roughness:.46, metallic:.24, emissive:[0,0.01,0.04], pattern:0 },
  teamRed:   { baseColor:[0.74,0.075,0.055,1], roughness:.46, metallic:.24, emissive:[0.035,0,0], pattern:0 },
  skin:      { baseColor:[0.48,0.29,0.20,1], roughness:.78, metallic:0, emissive:[0,0,0], pattern:0 },
  weapon:    { baseColor:[0.08,0.095,0.11,1], roughness:.30, metallic:.78, emissive:[0,0,0], pattern:3 },
  glove:     { baseColor:[0.055,0.07,0.085,1], roughness:.72, metallic:.08, emissive:[0,0,0], pattern:0 },
  flash:     { baseColor:[1,.50,.06,1], roughness:.12, metallic:0, emissive:[1,.22,.02], pattern:0 }
});

export function getMaterial(name){ return MATERIALS[name] || MATERIALS.concrete; }
