export const ACCOUNT={MIN_NAME:3,MAX_NAME:20,MAX_HISTORY:100,MAX_MATCH_HISTORY:50,PLACEMENT_MATCHES:5,NAME_RE:/^[A-Za-z0-9 _-]+$/};
export function normalizeDisplayName(value,fallback='Vanguard'){
  if(typeof value!=='string') return fallback;
  const name=value.trim().replace(/\s+/g,' ');
  if(name.length<ACCOUNT.MIN_NAME||name.length>ACCOUNT.MAX_NAME||!ACCOUNT.NAME_RE.test(name)) return fallback;
  return name;
}
export function makeAccount(id,name='Vanguard'){
  return {id,displayName:normalizeDisplayName(name),createdAt:Date.now(),stats:{kills:0,deaths:0,shots:0,headshots:0,roundsPlayed:0,roundsWon:0,matchesPlayed:0,matchesWon:0,matchesAbandoned:0},rating:1000,placementGames:0,matchHistory:[],history:[],competitiveIntegrity:{riskScore:0,flags:[],updatedAt:0}};
}
export function publicAccount(a){if(!a)return null;return {id:a.id,displayName:a.displayName,createdAt:a.createdAt,rating:Number.isFinite(a.rating)?a.rating:1000,placementGames:Number(a.placementGames)||0,stats:{...a.stats},matchHistory:Array.isArray(a.matchHistory)?a.matchHistory.slice(0,ACCOUNT.MAX_MATCH_HISTORY):[]};}
export function hasSettlement(a,settlementId){return !!a&&typeof settlementId==='string'&&Array.isArray(a.matchHistory)&&a.matchHistory.some(m=>m&&m.settlementId===settlementId);}
export function recordMatchHistory(a,match){if(!a||!match)return;if(match.settlementId&&hasSettlement(a,match.settlementId))return;const entry={...match};a.matchHistory=Array.isArray(a.matchHistory)?a.matchHistory:[];a.matchHistory.unshift(entry);if(a.matchHistory.length>ACCOUNT.MAX_MATCH_HISTORY)a.matchHistory.length=ACCOUNT.MAX_MATCH_HISTORY;}
export function recordAccountEvent(a,event){if(!a||!event)return;if(event.type==='kill')a.stats.kills++;if(event.type==='death')a.stats.deaths++;if(event.type==='shot')a.stats.shots++;if(event.type==='headshot')a.stats.headshots++;if(event.type==='roundPlayed')a.stats.roundsPlayed++;if(event.type==='roundWon')a.stats.roundsWon++;if(event.type==='matchPlayed'){a.stats.matchesPlayed++;a.placementGames=Math.min(ACCOUNT.PLACEMENT_MATCHES,(Number(a.placementGames)||0)+1);}if(event.type==='matchWon')a.stats.matchesWon++;if(event.type==='matchAbandoned')a.stats.matchesAbandoned=(Number(a.stats.matchesAbandoned)||0)+1;a.history.push({type:event.type,time:Date.now(),meta:event.meta||null});if(a.history.length>ACCOUNT.MAX_HISTORY)a.history.splice(0,a.history.length-ACCOUNT.MAX_HISTORY);}
